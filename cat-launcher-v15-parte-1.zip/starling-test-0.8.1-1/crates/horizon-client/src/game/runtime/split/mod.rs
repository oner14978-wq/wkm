//! Splitscreen (in parts; #3541): more players on this computer in P1's world, each its own `Game`
//! in this process that joins P1's server thread through memory. Every player renders offscreen
//! on one device and the window's compositor copies their frames into their views (halves for
//! two, `split_layout`). Keyboard and mouse drive the player whose view was clicked last (Esc
//! frees the mouse first). A player who leaves its world (pause menu, Disconnect) drops out;
//! when P1 leaves, all do. Alone, P1 plays exactly as without splitscreen: no compositor.
//!
//! Each player plays in a window: Window 1 (the game's), Window 2, 3... (opened for the players
//! put there, closed with their last player), or one filling a monitor, borderless over it.
//! Players in one window share it. Closing a player's own window drops its players; the game's
//! window hides while nobody plays in it (`windows`). `HORIZON_SPLIT_WINDOWS` (testing, until
//! the Setup screen): each seat's window in order, `1,1,2` (P1 and P2 in Window 1, P3 in Window
//! 2), `m2` for a window filling monitor 2 (left to right).
//!
//! Design: one process, one `Game` per player, one wgpu device. The players share the game's
//! data (`Resources`, the packs), one audio output and P1's server. Not one game process per
//! player: that needs GPU textures, input and audio shared across processes.
//!
//! Controllers: P1's is the first used in a menu. In P1's world a controller it isn't using
//! pressing a button is offered to join, on every view (A joins, Y gives it to P1, B says no); a
//! controller that disconnects leaves its player waiting, its view dimmed, until it comes back
//! or another takes over (`pads`).
//!
//! Horizon Settings > Splitscreen... enables joining (off by default).
//! `HORIZON_SPLIT=N` (testing) enables it too, and
//! N-1 players without one join once P1 is in its world, as P2, P3... (`HORIZON_SPLIT=1`: only
//! the controllers). The player in seat N takes `horizon-ctl` on P1's socket path + "N".

use super::{
    Game, UiResources, build_renderer,
    pad::{PadId, PadRouter},
    start_game,
};
use horizon_client::gamepad::Button;
use horizon_client::split_layout::{self as layout, MAX_PLAYERS, Placement, Spot, View};
use horizon_client::{Result, gfx::compositor::Compositor, widgets};
use std::{
    cell::RefCell,
    path::{Path, PathBuf},
    sync::Arc,
    time::{Duration, Instant},
};
use winit::{
    application::ApplicationHandler,
    dpi::{LogicalPosition, LogicalSize, PhysicalPosition, PhysicalSize},
    event::{DeviceEvent, DeviceId, ElementState, WindowEvent},
    event_loop::ActiveEventLoop,
    monitor::MonitorHandle,
    window::WindowId,
};

mod frames;
mod hud;
pub(super) mod launcher;
mod pads;
mod players;
mod setup;
mod windows;

pub(super) use hud::Hud;
use hud::*;
use windows::*;

thread_local! {
    /// The options file of the player whose turn it is (none for P1, whose is the game's own):
    /// every player runs on this thread, one after another.
    static OPTIONS: RefCell<Option<PathBuf>> = const { RefCell::new(None) };
}

/// The `options.txt` of the player whose turn it is; `None` for P1.
pub(super) fn options_path() -> Option<PathBuf> {
    OPTIONS.with_borrow(Clone::clone)
}

impl Game<'_> {
    /// An error stops the event loop, as ever, but not in another splitscreen player's game:
    /// that player drops out (`Split::drop_out`), the others play on.
    pub(in crate::game) fn exit_on_error(&self, event_loop: &dyn super::event_loop::EventLoopCtl) {
        if !self.options.split_guest {
            event_loop.exit();
        }
    }
}

const WINDOW_1: &str = "Window 1";
const NEW_WINDOW: &str = "New window";

struct Guest<'a> {
    game: Box<Game<'a>>,
    /// The profile it plays as; `None` while it picks one.
    name: Option<String>,
    /// Its seat (2 to `MAX_PLAYERS`): its number (P2...), its control socket, its sounds.
    seat: usize,
    options: PathBuf,
    /// The controller it plays with.
    pad: Option<PadId>,
    /// The window it plays in, by number.
    window: u8,
    /// Its buttons and focus targets while another player's game runs.
    widgets: widgets::Saved,
    /// Its profile got into the world: turned away after that (a kick), it leaves; before, it
    /// picks again.
    entered: bool,
    bumpers: [bool; 2],
}

pub(super) struct Split<'a> {
    pub(super) host: Game<'a>,
    guests: Vec<Guest<'a>>,
    /// The run's `--offscreen`: no window is shown, splitscreen's included, and P1 draws
    /// offscreen again when it is alone (`options.offscreen` is set while others play).
    offscreen: bool,
    /// `HORIZON_SPLIT=N`: players still to add once P1 is in a world.
    test_players: usize,
    /// `HORIZON_SPLIT` is set: splitscreen is on for this run, without touching the saved switch.
    forced: bool,
    /// While another player is in, the windows players play in, each with its compositor: the
    /// game's first, then the others (else P1 draws on its window).
    surfaces: Vec<Surface>,
    /// The windows players play in (Window 1, the game's, always first), each free or filling a
    /// monitor, and P1's.
    windows: Vec<layout::Window>,
    p1_window: u8,
    /// Seats in the order their views fill a shared window.
    order: Vec<usize>,
    /// Seats represented by the open Setup draft, to detect join/leave changes.
    setup_seats: Vec<usize>,
    /// Whether Window 1 is shown (hidden while nobody plays in it): set once per change, since
    /// Wayland can't say whether a window is visible.
    window1_shown: bool,
    /// Where each numbered window was when it closed, to open there again (this session).
    window_rects: std::collections::HashMap<u8, (LogicalPosition<f64>, LogicalSize<f64>)>,
    /// The monitors with their names, left to right, and the one Window 1 is on: read while
    /// splitscreen is on, once a second (`refresh_monitors`), and when it last read them.
    screens: Vec<(String, MonitorHandle)>,
    main_screen: Option<String>,
    screens_read: Option<Instant>,
    /// `HORIZON_SPLIT_WINDOWS`: each seat's window, `1`, `2`... or `m<monitor>`.
    window_plan: Vec<String>,
    /// The views the players were last fitted to.
    applied: Vec<View>,
    /// The player keyboard and mouse drive (0 = P1), and the pointer in the window.
    focus: usize,
    cursor: PhysicalPosition<f64>,
    limiter: horizon_client::window::FramerateLimiter,
    clock: horizon_client::window::SystemClock,
    /// P1's resources, shared by the other players' games for the process's lifetime.
    res: Option<&'static Arc<super::Resources>>,
    /// Whose game runs now (0 = P1), and P1's buttons while another's does.
    turn: usize,
    host_widgets: widgets::Saved,
    /// The launcher's other Microsoft accounts' sessions, for splitscreen players to sign in
    /// with (`launcher::accounts`).
    accounts: Vec<Arc<horizon_client::auth::AuthSession>>,
    /// `HORIZON_SPLIT_STATS`: when the frame times were last printed.
    stats: Option<Instant>,
    /// For the readout: where a frame's wall time goes (the turns with their renders, presents,
    /// the GPU wait, outside `about_to_wait`), summed since the last print, and when this frame
    /// started.
    spent: [Duration; 4],
    spent_frames: u32,
    frame_started: Option<Instant>,
    /// The controllers while several play (`pads`), and P1's.
    pads: PadRouter,
    p1_pad: pads::P1Pad<PadId>,
    /// Pads whose buttons still count as the press that gave them: released first.
    fresh: Vec<PadId>,
    /// Controllers offered to join, each since when: several may join at once.
    offers: Vec<(PadId, Instant)>,
    /// Players whose controller disconnected, longest waiting first.
    lost: Vec<pads::Lost<PadId>>,
}

impl<'a> Split<'a> {
    pub(super) fn new(host: Game<'a>) -> Self {
        let split = std::env::var("HORIZON_SPLIT").ok();
        let test_players = split
            .as_ref()
            .and_then(|n| n.parse::<usize>().ok())
            .map_or(0, |n| n.clamp(1, MAX_PLAYERS) - 1);
        let offscreen = host.options.offscreen;
        Self {
            host,
            guests: Vec::new(),
            offscreen,
            test_players,
            forced: split.is_some(),
            surfaces: Vec::new(),
            windows: vec![layout::Window {
                number: 1,
                placement: Placement::Free(None),
            }],
            p1_window: 1,
            order: Vec::new(),
            setup_seats: Vec::new(),
            window1_shown: true,
            window_rects: Default::default(),
            screens: Vec::new(),
            main_screen: None,
            screens_read: None,
            window_plan: std::env::var("HORIZON_SPLIT_WINDOWS")
                .map(|w| w.split(',').map(|s| s.trim().to_owned()).collect())
                .unwrap_or_default(),
            applied: Vec::new(),
            focus: 0,
            cursor: PhysicalPosition::new(0.0, 0.0),
            limiter: horizon_client::window::FramerateLimiter::new(0),
            clock: Default::default(),
            res: None,
            turn: 0,
            host_widgets: Default::default(),
            accounts: launcher::accounts(),
            stats: std::env::var_os("HORIZON_SPLIT_STATS").map(|_| Instant::now()),
            spent: Default::default(),
            spent_frames: 0,
            frame_started: None,
            pads: Default::default(),
            p1_pad: Default::default(),
            fresh: Vec::new(),
            offers: Vec::new(),
            lost: Vec::new(),
        }
    }

    fn players(&self) -> usize {
        1 + self.guests.len()
    }

    /// Player `i`'s turn (0 = P1): its options file, and its own buttons and focus targets, which
    /// screens record while drawing and the control socket and the controller's cursor read.
    fn turn(&mut self, i: usize) {
        if i == self.turn {
            return;
        }
        let current = widgets::take();
        match self.turn {
            0 => self.host_widgets = current,
            t => {
                if let Some(g) = self.guests.get_mut(t - 1) {
                    g.widgets = current;
                }
            }
        }
        let next = match i {
            0 => std::mem::take(&mut self.host_widgets),
            _ => self
                .guests
                .get_mut(i - 1)
                .map(|g| std::mem::take(&mut g.widgets))
                .unwrap_or_default(),
        };
        widgets::put(next);
        OPTIONS.set(
            self.guests
                .get(i.wrapping_sub(1))
                .map(|g| g.options.clone()),
        );
        let seat = self.guests.get(i.wrapping_sub(1)).map_or(1, |g| g.seat);
        horizon_hooks::engine::set_seat(seat - 1);
        self.turn = i;
    }

    /// Player `i`'s game (0 = P1).
    fn game(&self, i: usize) -> Option<&Game<'a>> {
        match i {
            0 => Some(&self.host),
            _ => self.guests.get(i - 1).map(|g| &*g.game),
        }
    }

    fn game_mut(&mut self, i: usize) -> Option<&mut Game<'a>> {
        match i {
            0 => Some(&mut self.host),
            _ => self.guests.get_mut(i - 1).map(|g| &mut *g.game),
        }
    }

    /// Player `i`'s game, in its turn, and its window's id.
    fn player(&mut self, i: usize) -> Option<(&mut dyn ApplicationHandler, WindowId)> {
        self.turn(i);
        let focus = self.focus;
        let game = self.game_mut(i)?;
        game.keyboard_mouse = i == focus;
        let id = game.window.as_ref()?.id();
        Some((game, id))
    }

    /// Give keyboard and mouse to one player, releasing the previous owner's held controls.
    fn handoff(&mut self, next: usize) {
        if next != self.focus {
            self.turn(self.focus);
            if let Some(game) = self.game_mut(self.focus) {
                game.release_keyboard_mouse();
            }
        }
        self.focus = next;
        for i in 0..self.players() {
            if let Some(game) = self.game_mut(i) {
                game.keyboard_mouse = i == next;
            }
        }
    }

    /// The pointer as the focused player sees it: from its view's corner.
    fn cursor_in_focus(&self) -> PhysicalPosition<f64> {
        let [x, y] = self.views().get(self.focus).map_or([0, 0], |v| v.1);
        let at = self.cursor;
        PhysicalPosition::new(at.x - f64::from(x), at.y - f64::from(y))
    }

    /// Player `i`'s name (0 = P1).
    fn name(&self, i: usize) -> String {
        match i {
            0 => "P1".into(),
            _ => self.guests[i - 1]
                .name
                .clone()
                .unwrap_or_else(|| "New player".into()),
        }
    }

    /// Where `HORIZON_SPLIT_WINDOWS` puts the player in `seat`: a window by number, or a new
    /// one filling a monitor.
    fn planned_window(&mut self, i: usize, seat: usize) {
        let Some(plan) = self.window_plan.get(seat - 1).cloned() else {
            return;
        };
        if let Some(k) = plan.strip_prefix('m') {
            let monitor = k
                .parse::<usize>()
                .ok()
                .and_then(|k| self.screens.get(k.checked_sub(1)?));
            let Some(name) = monitor.map(|(name, _)| name.clone()) else {
                log::warn!("Horizon: splitscreen: no monitor {k}");
                return;
            };
            let number = (2..=u8::MAX)
                .find(|n| self.windows.iter().all(|w| w.number != *n))
                .unwrap_or(u8::MAX);
            self.windows.push(layout::Window {
                number,
                placement: Placement::Fill(name),
            });
            return self.set_window(i, number);
        }
        let Ok(number) = plan.parse::<u8>() else {
            return;
        };
        if !self.windows.iter().any(|w| w.number == number) {
            self.windows.push(layout::Window {
                number,
                placement: Placement::Free(None),
            });
        }
        self.set_window(i, number);
    }

    /// Another player joins: P1 renders offscreen on the same device and a compositor presents
    /// on its window; the world is meshed again for the new renderer.
    #[inline(never)]
    fn enable(&mut self) -> Result<()> {
        let window = self.host.window.clone().ok_or("no window")?;
        let mut old = self.host.renderer.take().ok_or("no renderer")?;
        old.release_surface();
        let api = self.host.settings.horizon.api;
        let batching = self.host.settings.horizon.translucent_batching;
        let shader_pack = super::shader_packs::picked_pack_shape(&self.host.settings);
        let built = build_renderer(
            window.clone(),
            true,
            &self.host.pack,
            &self.host.gui,
            Some(&old),
            None,
            api,
            batching,
            &self.host.settings.horizon,
            shader_pack,
            old.display_reading(),
            (
                self.host.settings.file.int("textureFiltering"),
                self.host.settings.file.int("maxAnisotropyBit"),
            ),
        );
        let renderer = match built {
            Ok(r) => r,
            Err(e) => {
                old.recreate_surface()?;
                self.host.renderer = Some(old);
                return Err(e);
            }
        };
        // A window it can't present on: P1 keeps drawing on it as before.
        let compositor = match old.compositor(window.clone()) {
            Ok(c) => c,
            Err(e) => {
                drop(renderer);
                old.recreate_surface()?;
                self.host.renderer = Some(old);
                return Err(e);
            }
        };
        self.host.renderer = Some(renderer);
        self.host.forget_atlas_slots();
        self.host.split_window = !self.offscreen;
        self.host.options.offscreen = true;
        self.host.options.paced_by_split = true;
        // The new renderer takes the old one's present mode, settings and all: P1's again.
        self.host.apply_settings();
        self.host.clear_lod();
        self.host.all_sections_changed();
        self.surfaces = vec![Surface {
            key: 1,
            placement: Placement::Free(None),
            size: window.inner_size(),
            window,
            compositor,
            focused: true,
            title: String::new(),
        }];
        self.planned_window(0, 1);
        Ok(())
    }

    /// Splitscreen off or P1 alone again: it draws on its window again.
    #[inline(never)]
    fn disable(&mut self, event_loop: &ActiveEventLoop, watching: bool) -> Result<()> {
        for k in (0..self.guests.len()).rev() {
            self.remove_guest(k);
        }
        self.applied.clear();
        self.order.clear();
        self.setup_seats.clear();
        if !watching {
            self.stop_routing();
        }
        self.p1_window = 1;
        self.windows.truncate(1);
        self.surfaces.truncate(1);
        let Some(main) = self.surfaces.pop() else {
            return Ok(());
        };
        let window = main.window.clone();
        window.set_visible(windows::window_shown(true, self.offscreen));
        self.window1_shown = true;
        self.host.window = Some(window.clone());
        let old = self.host.renderer.take().ok_or("no renderer")?;
        old.take_back(main.compositor);
        let api = self.host.settings.horizon.api;
        let batching = self.host.settings.horizon.translucent_batching;
        let shader_pack = super::shader_packs::picked_pack_shape(&self.host.settings);
        let built = build_renderer(
            window.clone(),
            self.offscreen,
            &self.host.pack,
            &self.host.gui,
            Some(&old),
            None,
            api,
            batching,
            &self.host.settings.horizon,
            shader_pack,
            old.display_reading(),
            (
                self.host.settings.file.int("textureFiltering"),
                self.host.settings.file.int("maxAnisotropyBit"),
            ),
        );
        let renderer = match built {
            Ok(r) => r,
            Err(e) => {
                // P1 stays offscreen, presented as before (alone now).
                let compositor = old.compositor(window)?;
                self.surfaces.push(Surface { compositor, ..main });
                self.host.renderer = Some(old);
                return Err(e);
            }
        };
        drop(old);
        self.host.renderer = Some(renderer);
        self.host.forget_atlas_slots();
        self.host.options.offscreen = self.offscreen;
        self.host.split_window = false;
        self.host.options.paced_by_split = false;
        // Alone again: the pointer is P1's, its view the whole window.
        self.focus = 0;
        self.host.keyboard_mouse = true;
        self.host.view_at = [0, 0];
        // From the offscreen renderer it took no vsync: P1's settings again.
        self.host.apply_settings();
        self.host.clear_lod();
        self.host.all_sections_changed();
        let id = window.id();
        self.host
            .window_event(event_loop, id, WindowEvent::Resized(window.inner_size()));
        Ok(())
    }

    /// P1 is playing in a world others can join: its own (its server thread) or a server's.
    fn in_world(&self) -> bool {
        self.host.title.is_none()
            && self.host.player.is_some()
            && (self.host.integrated.is_some() || self.p1_server().is_some())
    }

    /// The server P1 joined over the network (a dedicated server, another computer's LAN
    /// world, a friend's invite): the others join it too, each as its own profile.
    fn p1_server(&self) -> Option<String> {
        if self.host.integrated.is_some() || self.host.remote.is_none() {
            return None;
        }
        self.host.server_address().map(str::to_owned)
    }

    /// The pads' players who accepted, and the testing players (`HORIZON_SPLIT`, one a frame),
    /// join: whether anyone did.
    fn admit(&mut self, _event_loop: &ActiveEventLoop, pad_joins: Vec<PadId>) -> bool {
        let mut changed = false;
        for pad in pad_joins {
            match self.join(Some(pad), None) {
                Ok(()) => changed = true,
                Err(e) => {
                    self.restore_given_up_pad(pad);
                    log::warn!("Horizon: splitscreen: a player could not join: {e}");
                }
            }
        }
        if self.in_world() && self.test_players > 0 {
            // HORIZON_SPLIT_PICK: they pick a profile like a controller's player, else P2...
            let name = std::env::var_os("HORIZON_SPLIT_PICK")
                .is_none()
                .then(|| format!("P{}", self.free_seat().unwrap_or(0)));
            match self.join(None, name) {
                Ok(()) => {
                    self.test_players -= 1;
                    changed = true;
                }
                Err(e) => {
                    // One player failing doesn't stop the others: P1 keeps playing.
                    log::warn!("Horizon: splitscreen player couldn't join: {e}");
                    self.test_players = 0;
                }
            }
        }
        changed
    }

    /// Each window shows its players' frames, then the GPU wait, once, for all of them. Only
    /// the game's window waits for the display (vsync): windows each waiting would divide the rate.
    /// When the windows had presented (before the GPU wait), for the frame-time readout.
    fn present(&mut self) -> Instant {
        let views = self.views();
        let vsync = self.host.settings.vsync;
        let paced = windows::paced_surface(self.window1_shown, self.surfaces.len());
        // A present mode switch reconfigures a surface, and an Outdated or Lost texture
        // may: a reconfigure waits for the GPU to come idle and reports an error when a
        // frame is submitted while it waits. Land this turn's frames on the submit
        // threads first (the compositor then copies views already submitted, too).
        self.wait_queues();
        let renderers: Vec<_> = std::iter::once(&self.host.renderer)
            .chain(self.guests.iter().map(|g| &g.game.renderer))
            .collect();
        for (k, surface) in self.surfaces.iter_mut().enumerate() {
            let frames: Vec<_> = renderers
                .iter()
                .zip(&views)
                .filter(|(_, v)| v.0 == k)
                .filter_map(|(r, v)| Some((r.as_ref()?.offscreen_frame()?, v.1)))
                .collect();
            surface.compositor.set_vsync(vsync && k == paced);
            // Wayland shows a window once something is presented on it.
            if windows::presents(self.offscreen) {
                surface.compositor.present(&frames);
            }
        }
        let presented = Instant::now();
        // One player's CPU work overlapped the GPU drawing another's.
        let renderers = std::iter::once(&mut self.host.renderer)
            .chain(self.guests.iter_mut().map(|g| &mut g.game.renderer));
        for renderer in renderers.flatten() {
            renderer.paced_elsewhere = true;
            renderer.wait_in_flight();
        }
        presented
    }
    /// Every player's frame submitted by its submit thread, no device wait: before
    /// anything reconfigures a surface, whose wait for the GPU breaks on a submission
    /// made while it waits.
    fn wait_queues(&mut self) {
        let renderers = std::iter::once(&mut self.host.renderer)
            .chain(self.guests.iter_mut().map(|g| &mut g.game.renderer));
        for renderer in renderers.flatten() {
            renderer.wait_submissions();
        }
    }
}

impl ApplicationHandler for Split<'_> {
    fn resumed(&mut self, event_loop: &ActiveEventLoop) {
        self.host.resumed(event_loop);
        if !self.surfaces.is_empty() {
            self.relayout(event_loop);
        }
    }

    fn window_event(&mut self, event_loop: &ActiveEventLoop, id: WindowId, event: WindowEvent) {
        if self.surfaces.is_empty() {
            return self.host.window_event(event_loop, id, event);
        }
        let Some(surface) = self.surfaces.iter().position(|s| s.window.id() == id) else {
            return;
        };
        match event {
            WindowEvent::Resized(size) => {
                let s = &mut self.surfaces[surface];
                s.size = size;
                s.compositor.resize(size.width, size.height);
                self.relayout(event_loop);
            }
            // The views draw themselves offscreen; the compositors present in about_to_wait.
            WindowEvent::RedrawRequested => {}
            // The game's window: P1's to handle (it saves the world, then quits). Another
            // window: its players leave.
            WindowEvent::CloseRequested if surface == 0 => {
                if let Some((host, id)) = self.player(0) {
                    host.window_event(event_loop, id, WindowEvent::CloseRequested);
                }
            }
            WindowEvent::CloseRequested => {
                if let Err(e) = self.close_window(surface) {
                    log::warn!("Horizon: splitscreen: {e}");
                }
            }
            // Players' pads count while any of the windows has focus.
            WindowEvent::Focused(focused) => {
                self.surfaces[surface].focused = focused;
                let any = self.surfaces.iter().any(|s| s.focused);
                for i in 0..self.players() {
                    if let Some((player, id)) = self.player(i) {
                        player.window_event(event_loop, id, WindowEvent::Focused(any));
                    }
                }
            }
            WindowEvent::CursorMoved {
                device_id,
                position,
            } => {
                self.cursor = position;
                let position = self.cursor_in_focus();
                let here = self.views().get(self.focus).is_some_and(|v| v.0 == surface);
                if here && let Some((player, id)) = self.player(self.focus) {
                    player.window_event(
                        event_loop,
                        id,
                        WindowEvent::CursorMoved {
                            device_id,
                            position,
                        },
                    );
                }
            }
            WindowEvent::MouseInput {
                device_id,
                state: ElementState::Pressed,
                ..
            } => {
                // A click on another player's view gives it keyboard and mouse, unless the
                // focused player holds the mouse (playing): Esc frees it first, as in vanilla.
                let (x, y) = (self.cursor.x as u32, self.cursor.y as u32);
                let clicked = self.views().iter().position(|(s, [vx, vy], size)| {
                    *s == surface
                        && (*vx..vx + size.width).contains(&x)
                        && (*vy..vy + size.height).contains(&y)
                });
                let holding = self.game(self.focus).is_some_and(|g| g.captured);
                if let Some(clicked) = clicked
                    && clicked != self.focus
                    && !holding
                {
                    self.handoff(clicked);
                    self.tag(clicked, "Keyboard and mouse");
                    let position = self.cursor_in_focus();
                    if let Some((player, id)) = self.player(clicked) {
                        player.window_event(
                            event_loop,
                            id,
                            WindowEvent::CursorMoved {
                                device_id,
                                position,
                            },
                        );
                    }
                }
                // Only into the focused player's own window: a click in another window
                // is not that player's attack or use.
                let here = self.views().get(self.focus).is_some_and(|v| v.0 == surface);
                if here && let Some((player, id)) = self.player(self.focus) {
                    player.window_event(event_loop, id, event);
                }
            }
            _ => {
                // Presses (keys, wheel) from a window the focused player is not in stay there;
                // releases still pass, so a key held across a window change can't stick.
                let here = self.views().get(self.focus).is_some_and(|v| v.0 == surface);
                let press = match &event {
                    WindowEvent::KeyboardInput { event: key, .. } => {
                        key.state == ElementState::Pressed
                    }
                    WindowEvent::MouseWheel { .. } => true,
                    _ => false,
                };
                if (here || !press)
                    && let Some((player, id)) = self.player(self.focus)
                {
                    player.window_event(event_loop, id, event);
                }
            }
        }
        self.turn(0);
    }

    fn device_event(&mut self, event_loop: &ActiveEventLoop, id: DeviceId, event: DeviceEvent) {
        // Alone: exactly P1's path, as in window_event (no GUI-scale store per mouse motion).
        if self.surfaces.is_empty() {
            return self.host.device_event(event_loop, id, event);
        }
        if let Some((player, _)) = self.player(self.focus) {
            player.device_event(event_loop, id, event);
        }
        self.turn(0);
    }

    fn about_to_wait(&mut self, event_loop: &ActiveEventLoop) {
        let on = self.host.settings.extras.splitscreen || self.forced;
        // Only splitscreen places windows on monitors. Listing them is a round trip to the
        // window server (macOS: 0.1-0.3 ms, more on a busy machine), so not every frame.
        if (on || !self.surfaces.is_empty())
            && self
                .screens_read
                .is_none_or(|at| at.elapsed() >= Duration::from_secs(1))
        {
            self.screens_read = Some(Instant::now());
            self.refresh_monitors();
        }
        self.host.split_hud.menu = self.guests.iter().any(|g| g.name.is_some());
        // Off, or the last other player gone: P1 draws on its window again.
        if !self.surfaces.is_empty()
            && (!on || self.guests.is_empty())
            && let Err(e) = self.disable(event_loop, on)
        {
            log::warn!("Horizon: splitscreen could not switch back: {e}");
        }
        if self.surfaces.is_empty() {
            self.sync_setup();
            if !on {
                self.stop_routing();
                return self.host.about_to_wait(event_loop);
            }
            // Alone, the controllers watched for someone joining; P1's own drives P1, its
            // output (rumble, triggers) through the split's reader for P1's turn.
            let pad_joins = self.route_pads(true);
            self.turn(0);
            if let Some(id) = self.p1_pad.owner {
                self.pads.lend_output(&mut self.host.pad, id);
            }
            self.host.about_to_wait(event_loop);
            if self.p1_pad.owner.is_some() {
                self.pads.reclaim_output(&mut self.host.pad);
            }
            if self.admit(event_loop, pad_joins) {
                self.relayout(event_loop);
            }
            return;
        }
        let started = Instant::now();
        if let Some(previous) = self.frame_started.replace(started) {
            // What the last frame left after its own work: events, the limiter, the OS.
            self.spent[3] += started.saturating_duration_since(previous);
        }
        let pad_joins = self.route_pads(false);
        self.turn(0);
        self.host.about_to_wait(event_loop);
        let mut changed = self.drop_out() | self.admit(event_loop, pad_joins);
        self.follow_pack_answer();
        self.sync_profiles();
        changed |= self.pick_profiles();
        changed |= self.sync_setup();
        changed |= self.sync_surfaces(event_loop);
        if changed || self.views() != self.applied {
            self.relayout(event_loop);
        }
        // Each player's badge: who it is, always with Names on (P1's Setup), else a moment when
        // something changes for it.
        let names = self.host.settings.extras.splitscreen_names;
        self.host.split_hud.badge = Some("P1".into());
        self.host.split_hud.names = names;
        for g in &mut self.guests {
            g.game.split_hud.badge = Some(g.name.clone().unwrap_or_else(|| "New player".into()));
            g.game.split_hud.names = names;
        }
        let master = self.host.audio.master;
        for i in 0..self.guests.len() {
            self.turn(i + 1);
            // One set of speakers: P1's volume.
            self.guests[i].game.audio.master = master;
            self.guests[i].game.about_to_wait(event_loop);
            // A player's game stops the event loop on an error, as P1's does: say why.
            if let Some(e) = &self.guests[i].game.error {
                log::error!("Horizon: splitscreen: P{}: {e}", self.guests[i].seat);
            }
            // Choosing its profile, the bumpers move its view (its pad as its game read it: the
            // controller, or `horizon-ctl pad`).
            let place = self.stop_label(i + 1);
            let game = &mut self.guests[i].game;
            if game.ui.options.page() == horizon_client::options_ui::Page::SplitProfiles
                && game.screen == super::Screen::Options
            {
                game.ui.options.split_profiles.place = place;
                let state = game.pad.state;
                let held = [
                    state.held(Button::LeftBumper),
                    state.held(Button::RightBumper),
                ];
                let before = std::mem::replace(&mut self.guests[i].bumpers, held);
                if held[0] && !before[0] {
                    self.move_with_bumpers(i + 1, true);
                } else if held[1] && !before[1] {
                    self.move_with_bumpers(i + 1, false);
                }
            }
        }
        self.pads
            .play_rumbles(&mut self.host.pad, self.p1_pad.owner);
        for g in &mut self.guests {
            self.pads.play_rumbles(&mut g.game.pad, g.pad);
        }
        self.turn(0);
        let rendered = Instant::now();
        let presented = self.present();
        let waited = Instant::now();
        for (k, d) in [rendered - started, presented - rendered, waited - presented]
            .into_iter()
            .enumerate()
        {
            self.spent[k] += d;
        }
        // The rest of the frame (the limiter, the OS) counts as outside, from `waited` on.
        self.spent[3] = self.spent[3].saturating_sub(waited - started);
        self.spent_frames += 1;
        self.print_stats();
        // One pace for all: the fastest any player wants, so an idle one (vanilla's AFK limit)
        // can't slow the others. With vsync the display paces anything at or above its refresh
        // rate; the limiter on top would miss refreshes.
        let limit = std::iter::once(self.host.framerate_limit())
            .chain(self.guests.iter().map(|g| g.game.framerate_limit()))
            .max()
            .unwrap_or(60);
        let refresh_hz = self
            .surfaces
            .get(windows::paced_surface(
                self.window1_shown,
                self.surfaces.len(),
            ))
            .and_then(|s| s.window.current_monitor()?.refresh_rate_millihertz())
            .map_or(60, |mhz| mhz.div_ceil(1000) as i32);
        // Offscreen, nothing presents: no display paces the frames.
        if !(self.host.settings.vsync && limit >= refresh_hz && windows::presents(self.offscreen)) {
            horizon_client::window::end_frame(&mut self.limiter, limit, &mut self.clock);
        }
    }

    fn exiting(&mut self, event_loop: &ActiveEventLoop) {
        for i in (0..self.players()).rev() {
            if let Some((player, _)) = self.player(i) {
                player.exiting(event_loop);
            }
        }
        self.turn(0);
    }
}

impl Game<'_> {
    /// Keyboard and mouse go to another player: release everything they held here.
    pub(super) fn release_keyboard_mouse(&mut self) {
        // A routing handoff is not a real window key event (`InputEvent.Key`).
        self.physical_keys.clear();
        // Only what the keyboard held, and a script acting as it: this player's pad keeps its
        // presses.
        let mut released = self
            .keys
            .release_source(horizon_client::held::Source::Keyboard);
        released.extend(
            self.keys
                .release_source(horizon_client::held::Source::Agent),
        );
        for key in released {
            if let Err(e) = self.mapped_key(
                key,
                false,
                false,
                key,
                horizon_client::held::Source::Keyboard,
            ) {
                log::warn!("Horizon: splitscreen: releasing input: {e}");
            }
        }
        for button in std::mem::take(&mut self.physical_buttons) {
            self.extras_mouse(button, false);
        }
        self.drag_button = None;
        self.modifiers = Default::default();
        // A press this player's pad holds goes on, as for its keys.
        self.left = self.pad.holds_action("key.attack");
        self.right = self.pad.holds_action("key.use");
        self.inventory_mouse_release(false);
        self.inventory_mouse_release(true);
        self.inventory_pick_release();
        self.loom_release();
        self.creative_screen.release();
        self.ui.options.release();
        self.dragging = false;
        self.stats_release();
        self.world_options_release();
        self.advancements_mouse(false, [0, 0]);
        if let Some(title) = &mut self.title {
            title.release();
            title.release_field();
        }
        self.capture(false);
        self.keyboard_mouse = false;
    }
}
