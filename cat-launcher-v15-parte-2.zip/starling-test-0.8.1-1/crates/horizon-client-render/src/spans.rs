//! Named timings within a frame, for finding what makes a frame slow:
//! `HORIZON_SPIKES=MS` prints the spans of every frame whose CPU time
//! exceeds MS milliseconds, and of every server tick (dedicated or
//! integrated) longer than MS. Each span keeps its wall time and the
//! thread's CPU time inside it, so a span that waited (for a lock, the GPU
//! or a core on a busy machine) shows apart from one that worked. Costs two
//! clock reads per span when enabled and a relaxed load otherwise.
use std::{
    cell::{Cell, RefCell},
    sync::atomic::{AtomicBool, Ordering},
    time::{Duration, Instant},
};

static ENABLED: AtomicBool = AtomicBool::new(false);
static RECORDING: AtomicBool = AtomicBool::new(false);
type Totals = (u64, f64, f64, f32);
type Trace = std::collections::BTreeMap<(&'static str, &'static str), Totals>;
static TRACE: std::sync::Mutex<Trace> = std::sync::Mutex::new(Trace::new());

/// Opt-in bounded, aggregate timings. Names are engine constants, never world data.
pub fn record_timings(on: bool) {
    DIAGNOSTIC_HERE.with(|h| h.set(on));
    RECORDING.store(on, Ordering::Relaxed);
    TRACE.lock().unwrap_or_else(|e| e.into_inner()).clear();
}
fn collect(role: &'static str, span: Span) {
    if !RECORDING.load(Ordering::Relaxed) {
        return;
    }
    let mut trace = TRACE.lock().unwrap_or_else(|e| e.into_inner());
    // Bounds the registry even if future instrumentation adds dynamic stages.
    if trace.len() >= 256 && !trace.contains_key(&(role, span.name)) {
        return;
    }
    let total = trace.entry((role, span.name)).or_default();
    total.0 += 1;
    total.1 += f64::from(span.ms);
    total.2 += f64::from(span.cpu_ms);
    total.3 = total.3.max(span.ms);
}
pub fn drain_timings() -> serde_json::Value {
    let trace = std::mem::take(&mut *TRACE.lock().unwrap_or_else(|e| e.into_inner()));
    serde_json::Value::Array(
        trace
            .into_iter()
            .map(|((role, stage), (calls, wall, cpu, max))| {
                serde_json::json!({"role": role, "stage": stage, "calls": calls,
            "wall_ms": wall, "thread_cpu_ms": cpu, "max_ms": max})
            })
            .collect(),
    )
}
/// A worker task measured independently of the render/server thread's spans.
pub fn job<T>(name: &'static str, f: impl FnOnce() -> T) -> T {
    if !RECORDING.load(Ordering::Relaxed) {
        return f();
    }
    let (started, cpu) = (Instant::now(), thread_cpu());
    let value = f();
    let ms = started.elapsed().as_secs_f32() * 1000.0;
    let cpu_ms = thread_cpu()
        .zip(cpu)
        .map_or(ms, |(end, start)| (end - start).as_secs_f32() * 1000.0);
    let thread = std::thread::current();
    let role = if thread.name() == Some("Server thread") {
        "server"
    } else {
        "worker"
    };
    collect(
        role,
        Span {
            name,
            ms,
            cpu_ms,
            depth: 0,
        },
    );
    value
}

thread_local! {
    static SPANS: RefCell<Vec<Span>> = const { RefCell::new(Vec::new()) };
    /// Spans recorded on this thread alone, wall time only ([`record_here`]).
    static HERE: Cell<bool> = const { Cell::new(false) };
    /// The caller that started local recording drains raw spans each rendered frame.
    static DIAGNOSTIC_HERE: Cell<bool> = const { Cell::new(false) };
    /// How many timed spans the thread is inside: the next span's [`Span::depth`].
    static DEPTH: Cell<u8> = const { Cell::new(0) };
    /// What this thread's slowest steps were busy with since it last took them ([`note`]).
    static NOTES: RefCell<Vec<(f32, String)>> = const { RefCell::new(Vec::new()) };
}

/// The most spans a thread holds before they are taken ([`take_raw`]): a worker thread
/// that records spans (`lod_reduce`, `lt_*`) while they are on for every thread is never
/// taken from, so it drops what it held instead of growing for as long as they stay on.
const UNTAKEN_MAX: usize = 1 << 14;

/// The shortest step a [`note`] keeps, in milliseconds.
pub const NOTE_MS: f32 = 10.0;
/// The notes a thread keeps between two [`take_notes`]: its slowest steps.
const NOTES_KEPT: usize = 3;

/// A named timing: wall milliseconds and the thread's CPU milliseconds in it.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Span {
    pub name: &'static str,
    pub ms: f32,
    pub cpu_ms: f32,
    /// How many timed spans it ran inside (0: none): `tick_mobs` is inside `tick`.
    pub depth: u8,
}

pub fn enable(on: bool) {
    ENABLED.store(on, Ordering::Relaxed);
}
/// Whether spans are being recorded.
pub fn enabled() -> bool {
    ENABLED.load(Ordering::Relaxed)
}
/// Records `ms` under `name`, measured by the caller (the sum of a loop's parts); its wall time
/// stands for its CPU time.
pub fn add(name: &'static str, ms: f32) {
    if recording_here() {
        emit(Span {
            name,
            ms,
            cpu_ms: ms,
            depth: DEPTH.with(Cell::get),
        });
    }
}
/// Raw spans belong only to threads whose existing consumer drains them. Recording
/// aggregate diagnostics must not grow a worker's thread-local buffer forever.
fn emit(span: Span) {
    if RECORDING.load(Ordering::Relaxed) {
        let role = if std::thread::current().name() == Some("Server thread") {
            "server"
        } else if HERE.with(Cell::get) || DIAGNOSTIC_HERE.with(Cell::get) {
            "render"
        } else {
            "worker"
        };
        collect(role, span);
    }
    if enabled()
        || HERE.with(Cell::get)
        || (RECORDING.load(Ordering::Relaxed) && DIAGNOSTIC_HERE.with(Cell::get))
    {
        push(span);
    }
}
/// Record this thread's spans even with spans off, their wall time only (no CPU clock read):
/// what the render thread's slow frames spent their time in. The thread takes them every
/// frame ([`take`]).
pub fn record_here(on: bool) {
    HERE.with(|h| h.set(on));
}
/// Whether this thread records spans: all of them on, or [`record_here`].
#[inline]
pub fn recording_here() -> bool {
    ENABLED.load(Ordering::Relaxed)
        || HERE.with(Cell::get)
        || RECORDING.load(Ordering::Relaxed)
        || trace::on()
}
/// The thread's CPU time when spans are on for every thread (`HORIZON_SPIKES`): only they
/// print it.
#[inline]
fn cpu_if_enabled() -> Option<Duration> {
    if ENABLED.load(Ordering::Relaxed) || RECORDING.load(Ordering::Relaxed) {
        thread_cpu()
    } else {
        None
    }
}
/// Run `f`, recording its duration under `name` when spans are enabled.
#[inline]
pub fn time<T>(name: &'static str, f: impl FnOnce() -> T) -> T {
    let _span = guard(name);
    f()
}
/// A span that ends where it is dropped: [`time`] for a step with several ways out (early
/// returns). Nothing is read while spans are off.
#[must_use = "the span ends when the guard is dropped"]
pub struct Guard {
    open: Option<(&'static str, Instant, Option<Duration>, u8)>,
    _heap: Option<horizon_threads::heap_census::Tag>,
}
/// Start a span named `name` that ends when the returned [`Guard`] is dropped.
#[inline]
pub fn guard(name: &'static str) -> Guard {
    let _heap = horizon_threads::heap_tag(name);
    if !recording_here() {
        return Guard { open: None, _heap };
    }
    let depth = DEPTH.with(|d| d.replace(d.get().saturating_add(1)));
    Guard {
        open: Some((name, Instant::now(), cpu_if_enabled(), depth)),
        _heap,
    }
}
impl Drop for Guard {
    fn drop(&mut self) {
        let Some((name, started, cpu, depth)) = self.open.take() else {
            return;
        };
        let ms = started.elapsed().as_secs_f32() * 1000.0;
        let cpu_ms = cpu
            .and_then(|start| Some((thread_cpu()?, start)))
            .map_or(ms, |(end, start)| (end - start).as_secs_f32() * 1000.0);
        DEPTH.with(|d| d.set(depth));
        trace::span(name, started, ms);
        emit(Span {
            name,
            ms,
            cpu_ms,
            depth,
        });
    }
}
/// Keeps a finished span for the thread's next [`take_raw`].
fn push(span: Span) {
    SPANS.with(|s| {
        let mut s = s.borrow_mut();
        if s.len() >= UNTAKEN_MAX {
            s.clear();
        }
        s.push(span);
    });
}
/// Attach per-tick counts without interpreting them as durations.
pub fn counters(counts: &[(&str, u64)]) {
    if !enabled() {
        return;
    }
    NOTES.with(|n| {
        n.borrow_mut().push((
            0.0,
            counts
                .iter()
                .map(|(name, count)| format!("{name}={count}"))
                .collect::<Vec<_>>()
                .join(", "),
        ))
    });
}
/// Notes that one step inside a span took `ms` milliseconds doing `what` (one player's
/// packets, say), when this thread records spans and the step took at least [`NOTE_MS`]: a
/// span says where a slow tick went, its notes whose doing it was. Only the slowest few are
/// kept, and `what` is built only for a step that is.
pub fn note(ms: f32, what: impl FnOnce() -> String) {
    if ms < NOTE_MS || !recording_here() {
        return;
    }
    NOTES.with(|n| {
        let mut n = n.borrow_mut();
        if n.len() >= NOTES_KEPT {
            let Some((i, _)) = n
                .iter()
                .enumerate()
                .filter(|(_, (kept, _))| *kept < ms)
                .min_by(|a, b| a.1.0.total_cmp(&b.1.0))
            else {
                return;
            };
            n.swap_remove(i);
        }
        n.push((ms, what()));
    });
}
/// This thread's notes ([`note`]), slowest first; clears them.
pub fn take_notes() -> Vec<(f32, String)> {
    let mut notes = NOTES.with(|n| std::mem::take(&mut *n.borrow_mut()));
    notes.sort_by(|a, b| b.0.total_cmp(&a.0));
    notes
}
/// Consecutive steps of one function timed as spans: each [`Laps::lap`] records the time since
/// the previous one (or since [`laps`]) under its name. Nothing is read while spans are off.
pub struct Laps(Option<(Instant, Option<Duration>)>);
/// Start timing the steps of a function (see [`Laps`]).
#[inline]
pub fn laps() -> Laps {
    Laps(recording_here().then(|| (Instant::now(), cpu_if_enabled())))
}
impl Laps {
    /// Record the step that just ended under `name`, and start the next.
    #[inline]
    pub fn lap(&mut self, name: &'static str) {
        let Some((started, cpu)) = &mut self.0 else {
            return;
        };
        let now = Instant::now();
        let now_cpu = cpu.and_then(|_| thread_cpu());
        let ms = (now - *started).as_secs_f32() * 1000.0;
        let cpu_ms = now_cpu
            .zip(*cpu)
            .map_or(ms, |(end, start)| (end - start).as_secs_f32() * 1000.0);
        let depth = DEPTH.with(Cell::get);
        trace::span(name, *started, ms);
        emit(Span {
            name,
            ms,
            cpu_ms,
            depth,
        });
        (*started, *cpu) = (now, now_cpu);
    }
}
/// The CPU time this thread has used, where the platform tells it: a tick
/// with more wall time than CPU time waited (for a lock, or for a core on a
/// busy machine).
pub fn thread_cpu() -> Option<Duration> {
    #[cfg(unix)]
    {
        let t = rustix::time::clock_gettime(rustix::time::ClockId::ThreadCPUTime);
        Some(Duration::new(t.tv_sec as u64, t.tv_nsec as u32))
    }
    #[cfg(not(unix))]
    horizon_threads::thread_cpu()
}

/// The frame's spans as they were recorded, each after the spans inside it; clears them.
pub fn take_raw() -> Vec<Span> {
    SPANS.with(|s| std::mem::take(&mut *s.borrow_mut()))
}
/// The frame's spans, summed by name, slowest first; clears them.
pub fn take() -> Vec<Span> {
    merge(&take_raw())
}
/// What a frame spent its time in, from its spans as recorded ([`take_raw`]): the slowest of
/// the outermost spans (summed by name, as a frame can tick several times), then the slowest
/// span inside it while that one took at least half of it, and so on. The path of names
/// (`tick/tick_mobs`) and the last one's milliseconds; `None` without spans.
pub fn culprit(raw: &[Span]) -> Option<(String, f32)> {
    // The spans directly inside each one: recorded just before it, one level deeper.
    let mut inside: Vec<Vec<usize>> = vec![Vec::new(); raw.len()];
    let mut outer: Vec<usize> = Vec::new();
    for (i, span) in raw.iter().enumerate() {
        while let Some(&j) = outer.last()
            && raw[j].depth > span.depth
        {
            outer.pop();
            inside[i].push(j);
        }
        outer.push(i);
    }
    let slowest = |group: &[usize]| {
        let mut sums: Vec<(&'static str, f32, Vec<usize>)> = Vec::new();
        for &i in group {
            match sums.iter_mut().find(|s| s.0 == raw[i].name) {
                Some(sum) => {
                    sum.1 += raw[i].ms;
                    sum.2.push(i);
                }
                None => sums.push((raw[i].name, raw[i].ms, vec![i])),
            }
        }
        sums.into_iter().max_by(|a, b| a.1.total_cmp(&b.1))
    };
    let (name, mut ms, mut at) = slowest(&outer)?;
    let mut path = name.to_owned();
    loop {
        let next: Vec<usize> = at.iter().flat_map(|&i| inside[i].iter().copied()).collect();
        match slowest(&next) {
            Some((name, inner_ms, spans)) if inner_ms >= ms * 0.5 => {
                path.push('/');
                path.push_str(name);
                (ms, at) = (inner_ms, spans);
            }
            _ => return Some((path, ms)),
        }
    }
}
/// Spans summed by name, slowest first.
pub fn merge(spans: &[Span]) -> Vec<Span> {
    let mut sums: Vec<Span> = Vec::new();
    for &span in spans {
        match sums.iter_mut().find(|s| s.name == span.name) {
            Some(sum) => {
                sum.ms += span.ms;
                sum.cpu_ms += span.cpu_ms;
            }
            None => sums.push(span),
        }
    }
    sums.sort_by(|a, b| b.ms.total_cmp(&a.ms));
    sums
}
/// `name wall` for spans of at least 0.5 ms, with `/cpu` when the thread
/// worked for less than nine tenths of it: the slow-frame and slow-tick lines.
pub fn describe(spans: &[Span]) -> String {
    let list: Vec<String> = spans
        .iter()
        .filter(|s| s.ms >= 0.5)
        .map(|s| {
            if s.cpu_ms < s.ms * 0.9 {
                format!("{} {:.1}/{:.1}", s.name, s.ms, s.cpu_ms)
            } else {
                format!("{} {:.1}", s.name, s.ms)
            }
        })
        .collect();
    list.join(", ")
}

/// The run's timeline: every span ([`time`], [`guard`], [`Laps::lap`]) on every thread, as
/// Chrome trace events that Perfetto (ui.perfetto.dev) opens as they are. `HORIZON_TRACE=FILE`
/// writes it from the start; [`start`](trace::start) and [`stop`](trace::stop) write one for a
/// while (`horizon-trace` on a dedicated server's console, `trace` on the control socket). Spans
/// show on their threads where they ran, nested by time, so what ran beside what, and what a
/// thread waited for, can be read off. Off, a span costs one relaxed load more.
pub mod trace {
    use std::{
        cell::Cell,
        fs::File,
        io::{BufWriter, Write as _},
        path::Path,
        sync::{
            Mutex, PoisonError,
            atomic::{AtomicBool, AtomicU32, Ordering},
        },
        time::Instant,
    };

    static ON: AtomicBool = AtomicBool::new(false);
    static SINK: Mutex<Option<Sink>> = Mutex::new(None);
    /// Counts the traces started: a thread names itself again in each one.
    static TRACES: AtomicU32 = AtomicU32::new(0);
    static NEXT_THREAD: AtomicU32 = AtomicU32::new(1);
    thread_local! {
        /// This thread's id in traces (0: none yet).
        static THREAD: Cell<u32> = const { Cell::new(0) };
        /// The trace this thread last named itself in.
        static NAMED_IN: Cell<u32> = const { Cell::new(0) };
    }
    /// How often a trace's buffer goes to the file, at most: a run that ends without
    /// [`stop`] loses no more than this.
    const FLUSH_EVERY: std::time::Duration = std::time::Duration::from_secs(1);

    struct Sink {
        file: BufWriter<File>,
        origin: Instant,
        /// Until when it records ([`start`]'s `seconds`).
        until: Option<Instant>,
        flushed: Instant,
        /// Events written: the next one is preceded by a comma.
        events: u64,
    }
    impl Sink {
        fn event(&mut self, event: std::fmt::Arguments) {
            let comma = if self.events == 0 { "" } else { ",\n" };
            let _ = write!(self.file, "{comma}{{\"pid\":1,{event}}}");
            self.events += 1;
        }
    }

    /// Whether a trace is being written.
    #[inline]
    pub fn on() -> bool {
        ON.load(Ordering::Relaxed)
    }

    /// Starts a trace written to `path` (replacing a trace being written), for `seconds` or
    /// until [`stop`].
    pub fn start(path: &Path, seconds: Option<u32>) -> std::io::Result<()> {
        let mut file = BufWriter::with_capacity(1 << 18, File::create(path)?);
        file.write_all(b"[\n")?;
        let now = Instant::now();
        let sink = Sink {
            file,
            origin: now,
            until: seconds.map(|s| now + std::time::Duration::from_secs(u64::from(s))),
            flushed: now,
            events: 0,
        };
        let mut slot = SINK.lock().unwrap_or_else(PoisonError::into_inner);
        if let Some(old) = slot.take() {
            close(old);
        }
        *slot = Some(sink);
        TRACES.fetch_add(1, Ordering::Relaxed);
        ON.store(true, Ordering::Relaxed);
        Ok(())
    }

    /// Starts the trace `HORIZON_TRACE` names, if it names one.
    pub fn start_from_env() {
        if let Some(path) = std::env::var_os("HORIZON_TRACE")
            && let Err(e) = start(Path::new(&path), None)
        {
            log::warn!("Horizon: HORIZON_TRACE: {e}");
        }
    }

    /// Ends the trace being written: the file is complete JSON. The events written so far
    /// and whether one was being written.
    pub fn stop() -> Option<u64> {
        ON.store(false, Ordering::Relaxed);
        let sink = SINK.lock().unwrap_or_else(PoisonError::into_inner).take()?;
        let events = sink.events;
        close(sink);
        Some(events)
    }

    /// Whether the trace being written has run its time ([`start`]'s `seconds`): the caller
    /// then [`stop`]s it.
    pub fn due() -> bool {
        on() && SINK
            .lock()
            .unwrap_or_else(PoisonError::into_inner)
            .as_ref()
            .and_then(|s| s.until)
            .is_some_and(|until| Instant::now() >= until)
    }

    fn close(mut sink: Sink) {
        let _ = sink.file.write_all(b"\n]\n");
        let _ = sink.file.flush();
    }

    /// A span of this thread from `started`, `ms` long.
    pub(super) fn span(name: &'static str, started: Instant, ms: f32) {
        if !on() {
            return;
        }
        let tid = THREAD.with(|t| {
            if t.get() == 0 {
                t.set(NEXT_THREAD.fetch_add(1, Ordering::Relaxed));
            }
            t.get()
        });
        let trace = TRACES.load(Ordering::Relaxed);
        let mut slot = SINK.lock().unwrap_or_else(PoisonError::into_inner);
        let Some(sink) = slot.as_mut() else {
            return;
        };
        if NAMED_IN.with(|n| n.replace(trace)) != trace {
            let name = std::thread::current()
                .name()
                .unwrap_or("unnamed")
                .replace(['"', '\\'], "_");
            sink.event(format_args!(
                r#""ph":"M","name":"thread_name","tid":{tid},"args":{{"name":"{name}"}}"#
            ));
        }
        let ts = started.saturating_duration_since(sink.origin).as_secs_f64() * 1e6;
        sink.event(format_args!(
            r#""ph":"X","name":"{name}","tid":{tid},"ts":{ts:.3},"dur":{:.3}"#,
            f64::from(ms) * 1e3
        ));
        let now = Instant::now();
        if now.duration_since(sink.flushed) >= FLUSH_EVERY {
            let _ = sink.file.flush();
            sink.flushed = now;
        }
    }
}

/// The start's timeline: `HORIZON_STARTUP_TRACE=FILE` writes every named step of
/// the start (resource tables, the renderer, the title, a world's open, a
/// server's join, a dimension change) on whichever thread ran it, one Chrome
/// trace event per line (`tools/startup_trace.py` reads it; wrapped in `[...]`,
/// Perfetto opens it). Times are microseconds since the process started. Off,
/// a step costs one relaxed load.
pub mod startup {
    use std::{
        io::Write as _,
        sync::{
            Mutex, OnceLock,
            atomic::{AtomicBool, AtomicU32, Ordering},
        },
        time::Instant,
    };

    static ON: AtomicBool = AtomicBool::new(false);
    static SINK: OnceLock<Option<Mutex<std::fs::File>>> = OnceLock::new();
    static ORIGIN: OnceLock<Instant> = OnceLock::new();
    static NEXT_THREAD: AtomicU32 = AtomicU32::new(1);
    thread_local! {
        /// This thread's trace id, given (with its name) on its first event.
        static THREAD: std::cell::Cell<u32> = const { std::cell::Cell::new(0) };
    }

    /// Opens the trace named by `HORIZON_STARTUP_TRACE`, timed from `origin`
    /// (the process's start). Call once, first thing.
    pub fn init(origin: Instant) {
        ORIGIN.get_or_init(|| origin);
        let sink = SINK.get_or_init(|| {
            let path = std::env::var_os("HORIZON_STARTUP_TRACE")?;
            std::fs::File::create(&path).ok().map(Mutex::new)
        });
        ON.store(sink.is_some(), Ordering::Relaxed);
    }

    /// Whether a trace is being written.
    #[inline]
    pub fn on() -> bool {
        ON.load(Ordering::Relaxed)
    }

    fn micros(at: Instant) -> u128 {
        ORIGIN.get().map_or(0, |origin| {
            at.saturating_duration_since(*origin).as_micros()
        })
    }

    fn write(event: std::fmt::Arguments) {
        let Some(Some(sink)) = SINK.get() else {
            return;
        };
        let tid = THREAD.with(|id| {
            if id.get() == 0 {
                id.set(NEXT_THREAD.fetch_add(1, Ordering::Relaxed));
                let name = std::thread::current()
                    .name()
                    .unwrap_or("unnamed")
                    .replace(['"', '\\'], "_");
                let mut file = sink.lock().unwrap_or_else(std::sync::PoisonError::into_inner);
                let _ = writeln!(
                    file,
                    r#"{{"ph":"M","name":"thread_name","pid":1,"tid":{},"args":{{"name":"{name}"}}}}"#,
                    id.get()
                );
            }
            id.get()
        });
        let mut file = sink
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner);
        let _ = writeln!(file, r#"{{"pid":1,"tid":{tid},{event}}}"#);
    }

    /// A step running until it is dropped.
    #[must_use = "the step ends when this is dropped"]
    pub struct Step {
        name: &'static str,
        started: Instant,
        traced: bool,
        /// A heap-census build's tag for the step's allocations.
        _heap: Option<horizon_threads::heap_census::Tag>,
    }
    impl Drop for Step {
        fn drop(&mut self) {
            if !self.traced {
                return;
            }
            let end = Instant::now();
            write(format_args!(
                r#""ph":"X","name":"{}","ts":{},"dur":{}"#,
                self.name,
                micros(self.started),
                end.saturating_duration_since(self.started).as_micros()
            ));
        }
    }

    /// Starts a step named `name` (a literal: no quotes or backslashes).
    #[inline]
    pub fn step(name: &'static str) -> Option<Step> {
        let traced = on();
        (traced || horizon_threads::HEAP_CENSUS).then(|| Step {
            name,
            started: Instant::now(),
            traced,
            _heap: horizon_threads::heap_tag(name),
        })
    }

    /// Runs `f` as a step named `name`.
    #[inline]
    pub fn time<T>(name: &'static str, f: impl FnOnce() -> T) -> T {
        let _step = step(name);
        f()
    }

    /// A moment of the start: the title drawn, the world in view.
    #[inline]
    pub fn mark(name: &'static str) {
        if on() {
            write(format_args!(
                r#""ph":"i","s":"g","name":"{name}","ts":{}"#,
                micros(Instant::now())
            ));
        }
    }

    /// The first time `name` happens, as a mark. `once` is the caller's flag.
    #[inline]
    pub fn mark_once(once: &AtomicBool, name: &'static str) {
        if on() && !once.swap(true, Ordering::Relaxed) {
            mark(name);
        }
    }

    /// Set while a world opens, a server is joined or the dimension changes,
    /// until the view first fills ([`view_filled`]).
    static FILLING: AtomicBool = AtomicBool::new(false);

    /// A world starts loading: the next full view is marked.
    pub fn arm(name: &'static str) {
        if on() {
            mark(name);
            FILLING.store(true, Ordering::Relaxed);
        }
    }

    /// Whether a world's view is still filling (between [`arm`] and the
    /// `world.view_full` mark).
    #[inline]
    pub fn filling() -> bool {
        on() && FILLING.load(Ordering::Relaxed)
    }

    /// Values at this moment, as a counter track named `name` (Perfetto draws
    /// each value as a line): what the view waits on while it fills.
    pub fn counters(name: &'static str, values: &[(&'static str, usize)]) {
        if !on() {
            return;
        }
        let args: Vec<String> = values
            .iter()
            .map(|(k, v)| format!(r#""{k}":{v}"#))
            .collect();
        write(format_args!(
            r#""ph":"C","name":"{name}","ts":{},"args":{{{}}}"#,
            micros(Instant::now()),
            args.join(",")
        ));
    }

    /// Called each frame in a world: marks `world.view_full` the first frame
    /// after [`arm`] where nothing waits to load, generate, light, mesh or
    /// upload and the resident columns cover perf_bench's share of the view
    /// (0.8 pi r^2: corners are never loaded).
    #[inline]
    pub fn view_filled(resident: usize, pending: usize, radius: u32) {
        if FILLING.load(Ordering::Relaxed)
            && pending == 0
            && resident as f64 >= 0.8 * std::f64::consts::PI * f64::from(radius * radius)
            && FILLING.swap(false, Ordering::Relaxed)
        {
            mark("world.view_full");
        }
    }
}

#[cfg(test)]
mod tests {
    use super::Span;
    use std::sync::{Mutex, MutexGuard};

    /// Spans on for every thread ([`super::enable`]) is process-wide: a test that turns them on
    /// would make another, run beside it, record what it expects left out. Those tests take
    /// this lock.
    fn spans_switch() -> MutexGuard<'static, ()> {
        static SWITCH: Mutex<()> = Mutex::new(());
        SWITCH.lock().unwrap_or_else(|e| e.into_inner())
    }

    #[test]
    fn diagnostic_aggregates_do_not_retain_worker_raw_spans() {
        let _switch = spans_switch();
        super::record_timings(true);
        super::time("render_step", || ());
        assert_eq!(super::take_raw()[0].name, "render_step");
        std::thread::spawn(|| {
            for _ in 0..10000 {
                super::time("worker_step", || ());
            }
            assert!(super::take_raw().is_empty());
        })
        .join()
        .unwrap();
        let rows = super::drain_timings();
        assert!(
            rows.as_array()
                .unwrap()
                .iter()
                .any(|row| row["stage"] == "render_step" && row["role"] == "render")
        );
        let step = rows
            .as_array()
            .unwrap()
            .iter()
            .find(|row| row["stage"] == "worker_step")
            .unwrap();
        assert_eq!(step["calls"], 10000);
        assert_eq!(step["role"], "worker");
        super::record_timings(false);
    }

    /// A slow tick's notes are its slowest steps, slowest first; short steps and steps on a
    /// thread that records no spans leave none.
    #[test]
    fn notes_keep_the_slowest_steps() {
        let _switch = spans_switch();
        super::record_here(false);
        super::note(500.0, || "unrecorded".into());
        assert!(super::take_notes().is_empty());
        super::record_here(true);
        for (ms, what) in [
            (12.0, "a"),
            (900.0, "b"),
            (3.0, "short"),
            (40.0, "c"),
            (11.0, "d"),
            (60.0, "e"),
        ] {
            super::note(ms, || what.into());
        }
        let notes: Vec<(f32, String)> = super::take_notes();
        super::record_here(false);
        let names: Vec<&str> = notes.iter().map(|(_, w)| w.as_str()).collect();
        assert_eq!(names, ["b", "e", "c"]);
        assert!(super::take_notes().is_empty(), "taking them clears them");
    }

    /// Spans of one name add up; a span the thread spent mostly waiting
    /// shows its CPU time after the wall time, short ones are left out.
    #[test]
    fn spans_sum_by_name_and_show_waits() {
        super::SPANS.with(|s| {
            s.borrow_mut().extend([
                Span {
                    name: "tick",
                    ms: 2.0,
                    cpu_ms: 2.0,
                    depth: 0,
                },
                Span {
                    name: "submit",
                    ms: 30.0,
                    cpu_ms: 0.2,
                    depth: 0,
                },
                Span {
                    name: "tick",
                    ms: 3.0,
                    cpu_ms: 2.9,
                    depth: 0,
                },
                Span {
                    name: "hud",
                    ms: 0.3,
                    cpu_ms: 0.3,
                    depth: 0,
                },
            ]);
        });
        let spans = super::take();
        assert_eq!(
            spans[0],
            Span {
                name: "submit",
                ms: 30.0,
                cpu_ms: 0.2,
                depth: 0,
            }
        );
        assert_eq!((spans[1].name, spans[1].ms), ("tick", 5.0));
        assert_eq!(super::describe(&spans), "submit 30.0/0.2, tick 5.0");
        assert!(super::take().is_empty());
    }

    /// A thread that records on its own keeps its spans with spans off, each with how many
    /// spans it ran inside, after them.
    #[test]
    fn a_recording_thread_keeps_its_spans_and_their_nesting() {
        std::thread::spawn(|| {
            super::record_here(true);
            super::time("tick", || {
                super::time("tick_mobs", || ());
                super::time("tick_items", || ());
            });
            super::time("renderer", || ());
            let raw = super::take_raw();
            let seen: Vec<_> = raw.iter().map(|s| (s.name, s.depth)).collect();
            assert_eq!(
                seen,
                [
                    ("tick_mobs", 1),
                    ("tick_items", 1),
                    ("tick", 0),
                    ("renderer", 0)
                ]
            );
        })
        .join()
        .unwrap();
    }

    /// A guarded span ends on every way out of its step, an early return's too, and holds the
    /// spans that ran inside it until then; the next span outside it is back at its depth.
    #[test]
    fn a_guarded_span_ends_where_its_step_returns() {
        fn step(early: bool) -> u32 {
            let _span = super::guard("use_block");
            super::time("open_loot", || ());
            if early {
                return 1;
            }
            super::time("open_maps", || ());
            2
        }
        std::thread::spawn(|| {
            super::record_here(true);
            assert_eq!(step(true), 1);
            assert_eq!(step(false), 2);
            super::time("use_item", || ());
            let raw = super::take_raw();
            let seen: Vec<_> = raw.iter().map(|s| (s.name, s.depth)).collect();
            assert_eq!(
                seen,
                [
                    ("open_loot", 1),
                    ("use_block", 0),
                    ("open_loot", 1),
                    ("open_maps", 1),
                    ("use_block", 0),
                    ("use_item", 0)
                ]
            );
        })
        .join()
        .unwrap();
    }

    /// A slow frame is put down to the slowest outer span, then to the span inside it that took
    /// at least half of it; repeated spans (several ticks a frame) add up.
    #[test]
    fn a_frame_is_put_down_to_the_step_that_took_most_of_it() {
        let span = |name, ms, depth| Span {
            name,
            ms,
            cpu_ms: ms,
            depth,
        };
        let frame = [
            span("tick_mobs", 90.0, 1),
            span("tick_items", 5.0, 1),
            span("tick", 100.0, 0),
            span("tick_mobs", 90.0, 1),
            span("tick", 100.0, 0),
            span("r_uploads", 120.0, 1),
            span("renderer", 150.0, 0),
        ];
        assert_eq!(
            super::culprit(&frame),
            Some(("tick/tick_mobs".to_owned(), 180.0))
        );
        // Spread over many steps: the outer span alone.
        let spread = [
            span("tick_mobs", 40.0, 1),
            span("tick_items", 40.0, 1),
            span("tick", 300.0, 0),
        ];
        assert_eq!(super::culprit(&spread), Some(("tick".to_owned(), 300.0)));
        assert_eq!(super::culprit(&[]), None);
    }

    /// Laps record the steps between them while spans are on, and nothing while off.
    #[test]
    fn laps_time_consecutive_steps() {
        let _switch = spans_switch();
        let _ = super::take();
        let mut off = super::laps();
        off.lap("unseen");
        super::enable(true);
        let mut laps = super::laps();
        std::thread::sleep(std::time::Duration::from_millis(2));
        laps.lap("first");
        laps.lap("second");
        super::enable(false);
        off.lap("still unseen");
        let spans = super::take();
        let names: Vec<_> = spans.iter().map(|s| s.name).collect();
        assert_eq!(names, ["first", "second"]);
        assert!(spans[0].ms >= 2.0);
    }

    /// The thread's CPU clock moves with work done on it, not with time
    /// spent asleep.
    #[cfg(any(unix, all(windows, target_arch = "x86_64")))]
    #[test]
    fn thread_cpu_counts_work_not_sleep() {
        let start = super::thread_cpu().unwrap();
        std::thread::sleep(std::time::Duration::from_millis(50));
        let slept = super::thread_cpu().unwrap() - start;
        // Busy until the clock shows 10 ms of work (a loaded machine gives
        // the thread less than its wall time).
        let mut x = 0u64;
        let busy = std::time::Instant::now();
        let worked = loop {
            x = std::hint::black_box(x.wrapping_mul(31).wrapping_add(7));
            let worked = super::thread_cpu().unwrap() - start - slept;
            if worked.as_millis() >= 10 || busy.elapsed().as_secs() >= 10 {
                break worked;
            }
        };
        assert!(slept.as_millis() < 25, "{slept:?} while asleep");
        assert!(worked.as_millis() >= 10, "{worked:?} while busy");
    }
}
