//! Player settings persisted in `options.txt` with vanilla's keys and value
//! encodings (Options.processOptions); lines Horizon does not know are kept.
//! The option screens live in `options_ui`.
use crate::keybinds::KeyBinds;
use crate::options_file::{OptionsFile, V};
use horizon_protocol::packets::configuration::ClientInformation;
use std::{fs, path::Path};

pub use horizon_client_core::sound_source::SOUND_SOURCES;

/// Per-source volumes for the mixer (soundCategory_* except master).
static SOURCE_VOLUMES: std::sync::RwLock<[f32; 11]> = std::sync::RwLock::new([1.0; 11]);
pub fn set_source_volumes(volumes: [f32; 11]) {
    *SOURCE_VOLUMES.write().unwrap_or_else(|e| e.into_inner()) = volumes;
}
/// The SoundSource an event plays on. Vanilla callers pick the source; this
/// follows their conventions by event family.
pub fn sound_source(event: &str) -> usize {
    let e = event.trim_start_matches("minecraft:");
    let index = |name: &str| SOUND_SOURCES.iter().position(|n| *n == name).unwrap_or(0);
    const HOSTILE: [&str; 34] = [
        "zombie",
        "skeleton",
        "creeper",
        "spider",
        "cave_spider",
        "enderman",
        "witch",
        "slime",
        "magma_cube",
        "blaze",
        "ghast",
        "drowned",
        "husk",
        "stray",
        "phantom",
        "pillager",
        "vindicator",
        "evoker",
        "illusioner",
        "ravager",
        "guardian",
        "elder_guardian",
        "silverfish",
        "zombified_piglin",
        "wither_skeleton",
        "bogged",
        "breeze",
        "endermite",
        "parched",
        "warden",
        "zombie_villager",
        "vex",
        "wither",
        // Monster's common hurt/death (e.g. Giant) and other shared sounds.
        "hostile",
    ];
    if e == "block.potent_sulfur.noxious_gas" {
        // PotentSulfurBlock.animateTick, its only caller, plays it as AMBIENT.
        index("ambient")
    } else if e.starts_with("music_disc.") {
        index("record")
    } else if e.starts_with("item.goat_horn.") {
        // InstrumentItem.play: SoundSource.RECORDS.
        index("record")
    } else if e.starts_with("music.") {
        index("music")
    } else if e.starts_with("weather.") || e.starts_with("entity.lightning_bolt") {
        index("weather")
    } else if e.starts_with("block.") {
        index("block")
    } else if e.starts_with("ambient.") {
        index("ambient")
    } else if e.starts_with("ui.") {
        index("ui")
    } else if e.starts_with("entity.player.")
        || e.starts_with("item.")
        || e.starts_with("entity.item.")
        || e.starts_with("entity.experience_orb")
        || e.starts_with("entity.arrow")
    {
        index("player")
    } else if let Some(rest) = e.strip_prefix("entity.") {
        let mob = rest.split('.').next().unwrap_or("");
        if HOSTILE.contains(&mob) {
            index("hostile")
        } else {
            index("neutral")
        }
    } else {
        index("master")
    }
}
/// Volume multiplier of a sound source by index.
pub fn source_volume(i: usize) -> f32 {
    if i == 0 {
        1.0
    } else {
        SOURCE_VOLUMES.read().unwrap_or_else(|e| e.into_inner())[i]
    }
}

/// What a button of the player's own on the touch controls does.
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum CustomAction {
    /// Holds one of the game's controls (`key.sprint`) while a finger is on it.
    Key(String),
    /// Holds a key of the keyboard (`key.keyboard.f1`) while a finger is on it.
    Input(String),
    /// Sends a command or a chat line when pressed.
    Send(String),
}

/// A button of the player's own on the touch controls (its place is the layout's).
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct CustomButton {
    pub id: u32,
    pub action: CustomAction,
    /// One of [`CUSTOM_ICONS`]; none shows what it does in words.
    pub icon: Option<String>,
    /// Wears the player's own image instead (`own_buttons`).
    pub image: bool,
    /// Wears another image of the player's own while pressed (`own_buttons::pressed_slot`).
    pub pressed: bool,
    /// A press turns it on and the next one off; otherwise it is on while held.
    pub toggle: bool,
}

/// What a custom button can wear: `starling:touch/custom_<name>` and its `_pressed`
/// (packaging/touch/make.py draws them).
pub const CUSTOM_ICONS: [&str; 15] = [
    "star", "heart", "shield", "skull", "home", "crown", "flag", "plus", "check", "cross",
    "potion", "pickaxe", "apple", "fire", "music",
];

impl CustomButton {
    /// What it shows on it.
    pub fn label(&self) -> String {
        match &self.action {
            CustomAction::Key(name) => crate::lang::get(name),
            CustomAction::Input(name) => crate::keybinds::display_name(name).plain(),
            CustomAction::Send(line) => line.clone(),
        }
    }
}

#[derive(Clone, Debug)]
pub struct Settings {
    pub touch: crate::android_controls::Settings,
    pub keypad: crate::keypad::Settings,
    /// Degrees, 30..=110 (options.txt stores (fov - 70) / 40).
    pub fov: f32,
    /// Chunks, 2..=32.
    pub render_distance: i32,
    /// Chunks, 5..=32.
    pub simulation_distance: i32,
    /// 0..1, vanilla default 0.5.
    pub sensitivity: f32,
    /// 0..1 (soundCategory_master).
    pub master_volume: f32,
    /// Volumes of every other sound source, indexed like SOUND_SOURCES.
    pub volumes: [f32; 11],
    /// Empty for system default, or a specific audio device name.
    pub sound_device: String,
    /// Requested scale (0 = auto); rendering caps it to the current framebuffer.
    pub gui_scale: u32,
    pub view_bobbing: bool,
    /// Brightness 0..1 (gamma).
    pub gamma: f32,
    /// 10..=260 (260 = unlimited).
    pub max_fps: u32,
    pub vsync: bool,
    pub fullscreen: bool,
    /// Smooth lighting (ao).
    pub smooth_lighting: bool,
    /// "false", "fast" or "true" (renderClouds).
    pub clouds: String,
    pub cloud_range: i32,
    /// 0 all, 1 decreased, 2 minimal.
    pub particles: u8,
    pub entity_distance: f32,
    pub entity_shadows: bool,
    pub biome_blend: i32,
    /// "fast", "fancy", "fabulous" or "custom".
    pub graphics_preset: String,
    pub mipmap_levels: i32,
    pub weather_radius: i32,
    pub chunk_fade: f32,
    pub vignette: bool,
    pub autosave_indicator: bool,
    pub cutout_leaves: bool,
    pub improved_transparency: bool,
    /// 0 off, 1 crosshair, 2 hotbar.
    pub attack_indicator: u8,
    pub inactivity_fps_limit: String,
    /// The creative screen with the inventory and a crafting grid beside it, as Bedrock's.
    pub bedrock_inventory: bool,
    pub prioritize_chunk_updates: u8,
    pub menu_blur: i32,
    pub invert_y: bool,
    pub mouse_wheel_sensitivity: f32,
    pub discrete_scroll: bool,
    pub toggle_crouch: bool,
    pub toggle_sprint: bool,
    pub auto_jump: bool,
    pub language: String,
    pub force_unicode: bool,
    pub japanese_glyphs: bool,
    pub chat_visibility: u8,
    pub chat_colors: bool,
    pub chat_links: bool,
    pub chat_links_prompt: bool,
    pub chat_opacity: f32,
    /// Chat Delay in seconds (`chatDelay`): player chat shows this far apart.
    pub chat_delay: f64,
    pub text_background_opacity: f32,
    pub chat_scale: f32,
    pub chat_width: f32,
    pub chat_height_focused: f32,
    pub chat_height_unfocused: f32,
    pub chat_line_spacing: f32,
    pub auto_suggestions: bool,
    pub reduced_debug_info: bool,
    pub high_contrast: bool,
    /// `showSubtitles`: the closed-caption overlay.
    pub show_subtitles: bool,
    /// `notificationDisplayTime`: a multiplier for subtitle and toast times.
    pub notification_display_time: f32,
    pub main_hand_left: bool,
    /// Enabled resource packs, bottom first (resourcePacks).
    pub resource_packs: Vec<String>,
    pub keys: KeyBinds,
    /// Every option in its stored form (the typed fields above mirror it).
    pub file: OptionsFile,
    pub invert_x: bool,
    /// Allow widgets to replace the default mouse cursor icon.
    pub allow_cursor_changes: bool,
    pub toggle_attack: bool,
    pub toggle_use: bool,
    /// Taps of the sprint key counted as double taps (sprintWindow).
    pub sprint_window: i32,
    /// Show the operator items tab in a creative inventory.
    pub operator_items_tab: bool,
    /// Allow platform quit shortcuts to close the game window.
    pub quit_shortcuts: bool,
    /// On macOS, turn Control-click into a right click.
    pub ctrl_click_emulates_right_click: bool,
    /// Horizon's own graphics settings (`horizon-graphics.txt`, not options.txt).
    pub horizon: crate::graphics::Graphics,
    /// The graphics API the game started with: `Options.preferredGraphicsBackendFromStartup`.
    pub startup_api: crate::graphics::GraphicsApi,
    /// `Monitor.videoModes` of the window's monitor, for the Video page (set by the game).
    pub video_modes: Vec<crate::window::VideoMode>,
    /// Controller settings (`horizon-controller.txt`, Horizon's own).
    pub controller: crate::gamepad::PadSettings,
    /// Horizon's optional extras (`horizon-extras.txt`), all off by default.
    pub extras: crate::extras::Extras,
    /// The Horizon mods turned on (`horizon-mods.txt`), all off by default.
    pub mods: crate::mod_list::ModList,
    /// The packs in `shaderpacks/`, listed when the Shader Packs page opens; the pick is
    /// `horizon.shader_pack`.
    pub shader_packs: Vec<crate::shader_pack_list::Entry>,
    /// The picked pack's options while its Shader Options page is open.
    pub shader_options: Option<crate::shader_options::ShaderOptions>,
    /// The touch layout's own buttons while the Custom Buttons page shows them.
    pub custom_buttons: Vec<CustomButton>,
}
impl Default for Settings {
    fn default() -> Self {
        Self {
            touch: crate::android_controls::Settings::load(),
            keypad: Default::default(),
            fov: 70.0,
            render_distance: 12,
            simulation_distance: 12,
            sensitivity: 0.5,
            master_volume: 1.0,
            volumes: [1.0; 11],
            sound_device: String::new(),
            gui_scale: 0,
            view_bobbing: true,
            gamma: 0.5,
            // Vanilla's default, as for an options.txt without the key: a
            // capped frame rate leaves the cores idle when VSync is off.
            max_fps: 120,
            vsync: true,
            fullscreen: false,
            smooth_lighting: true,
            clouds: "true".into(),
            cloud_range: 128,
            particles: 0,
            entity_distance: 1.0,
            entity_shadows: true,
            biome_blend: 2,
            graphics_preset: "fancy".into(),
            mipmap_levels: 4,
            weather_radius: 10,
            chunk_fade: 0.75,
            vignette: true,
            autosave_indicator: true,
            cutout_leaves: true,
            improved_transparency: false,
            attack_indicator: 1,
            inactivity_fps_limit: "afk".into(),
            // Cat Launcher: one creative window, as the game itself draws it; the two-window
            // Bedrock layout is only on when the player turns it on in the options.
            bedrock_inventory: false,
            prioritize_chunk_updates: 0,
            menu_blur: 5,
            invert_y: false,
            mouse_wheel_sensitivity: 1.0,
            discrete_scroll: false,
            allow_cursor_changes: true,
            toggle_crouch: false,
            toggle_sprint: false,
            auto_jump: false,
            language: "en_us".into(),
            force_unicode: false,
            japanese_glyphs: false,
            chat_visibility: 0,
            chat_colors: true,
            chat_links: true,
            chat_links_prompt: true,
            chat_opacity: 1.0,
            chat_delay: 0.0,
            text_background_opacity: 0.5,
            chat_scale: 1.0,
            chat_width: 1.0,
            chat_height_focused: 1.0,
            chat_height_unfocused: 70.0 / 160.0,
            chat_line_spacing: 0.0,
            auto_suggestions: true,
            reduced_debug_info: false,
            high_contrast: false,
            show_subtitles: false,
            notification_display_time: 1.0,
            main_hand_left: false,
            resource_packs: Vec::new(),
            keys: KeyBinds::default(),
            file: OptionsFile::default(),
            invert_x: false,
            toggle_attack: false,
            toggle_use: false,
            sprint_window: 7,
            operator_items_tab: false,
            quit_shortcuts: true,
            ctrl_click_emulates_right_click: false,
            horizon: Default::default(),
            startup_api: Default::default(),
            video_modes: Vec::new(),
            controller: Default::default(),
            extras: Default::default(),
            mods: Default::default(),
            shader_packs: Vec::new(),
            shader_options: None,
            custom_buttons: Vec::new(),
        }
    }
}
fn put_f(f: &mut OptionsFile, key: &str, v: f32) {
    if v != f.double(key) as f32 {
        f.set(key, V::Double(f64::from(v)));
    }
}
fn put_i(f: &mut OptionsFile, key: &str, v: i32) {
    if v != f.int(key) {
        f.set(key, V::Int(v));
    }
}
fn put_b(f: &mut OptionsFile, key: &str, v: bool) {
    if v != f.bool(key) {
        f.set(key, V::Bool(v));
    }
}
fn put_name(f: &mut OptionsFile, key: &str, v: &str) {
    if v != f.name(key) {
        f.set_name(key, v);
    }
}
fn put_s(f: &mut OptionsFile, key: &str, v: &str) {
    if v != f.string(key) {
        f.set(key, V::Str(v.to_owned()));
    }
}
impl Settings {
    /// The index in `video_modes` of the preferred fullscreen mode, -1 (the desktop's own mode)
    /// when none is set or the monitor lacks it: `Monitor.indexOfMode`.
    pub fn video_mode_index(&self) -> i32 {
        self.file
            .fullscreen_resolution
            .as_deref()
            .and_then(crate::window::VideoMode::read)
            .and_then(|mode| self.video_modes.iter().position(|m| *m == mode))
            .map_or(-1, |i| i as i32)
    }
    /// Loads only the crates' settings stores (`horizon_hooks::settings`) from the files next to
    /// `path`, into the seat whose turn it is (`horizon_hooks::seat`): a splitscreen player whose
    /// settings were made from P1's rather than loaded.
    pub fn load_stores(path: &Path) {
        let dir = path.parent();
        horizon_hooks::settings::engine::load(&mut |file| fs::read_to_string(dir?.join(file)).ok());
    }
    pub fn load(path: &Path) -> Self {
        let mut horizon = path
            .parent()
            .map(crate::graphics::Graphics::load)
            .unwrap_or_default();
        crate::mipmap::set_dither_cutouts(horizon.dither_cutout_mips);
        if let Some(dir) = path.parent() {
            let (key, _) = crate::shader_pack_list::resolve(
                &crate::logging::shared_dir(dir).join(crate::shader_pack_list::DIR),
                &horizon.shader_pack,
            );
            if key != horizon.shader_pack {
                horizon.shader_pack = key;
                horizon.save(dir);
            }
        }
        let controller = path
            .parent()
            .map(crate::gamepad::PadSettings::load)
            .unwrap_or_default();
        let extras_text = path
            .parent()
            .and_then(|dir| fs::read_to_string(dir.join(crate::extras::FILE)).ok())
            .unwrap_or_default();
        let mut extras = crate::extras::Extras::parse(&extras_text);
        // The settings stores of the crates above the engine: their lines of this file, or of
        // their own (docs/layers.md, "Platform registries").
        horizon_hooks::settings::engine::load(&mut |file| match path.parent() {
            _ if file == crate::extras::FILE => Some(extras_text.clone()),
            Some(dir) => fs::read_to_string(dir.join(file)).ok(),
            None => None,
        });
        // The enabled mods are the game folder's, shared by its players (`--player-dir`).
        let mods = path
            .parent()
            .map(|dir| crate::mod_list::ModList::load(&crate::logging::shared_dir(dir)))
            .unwrap_or_default();
        let keypad = crate::keypad::Settings::load(&path.with_file_name("horizon-keypad.json"));
        let mut settings = match fs::read(path) {
            Ok(bytes) => {
                let text = String::from_utf8_lossy(&bytes);
                extras.read_old_options(&extras_text, &text);
                Self {
                    horizon,
                    controller,
                    keypad,
                    extras,
                    mods,
                    ..Self::parse(&text)
                }
            }
            Err(_) => Self {
                horizon,
                controller,
                keypad,
                extras,
                mods,
                ..Self::default()
            },
        };
        // Horizon's own key bindings live in horizon-extras.txt, not in options.txt.
        let emote = settings.extras.emote_key.clone();
        settings.keys.set("key.emote", &emote);
        // The loaded set is the active one: `keybind` text components show its keys.
        settings.keys.sync_action_bindings();
        // `Options.load`: `sharePresence` decides what the friends service posts.
        crate::social::set_share_presence(crate::social::SharePresence::of(
            settings.file.int("sharePresence").clamp(0, 2) as u8,
        ));
        settings.describe_for_crashes();
        // Options.load: the backend asked for at startup, what a restart is measured from.
        Self {
            startup_api: settings.horizon.api,
            ..settings
        }
    }
    /// The render settings and resource packs a crash report lists.
    fn describe_for_crashes(&self) {
        let on = |b: bool| if b { "on" } else { "off" };
        let scale = match self.gui_scale {
            0 => "auto".to_owned(),
            n => n.to_string(),
        };
        crate::crash::set_detail(
            "Render Settings",
            format!(
                "render distance {}, simulation distance {}, graphics {}, FOV {:.0}, max FPS {}, VSync {}, fullscreen {}, GUI scale {scale}, smooth lighting {}, clouds {}, biome blend {}, mipmap levels {}",
                self.render_distance,
                self.simulation_distance,
                self.graphics_preset,
                self.fov,
                if self.max_fps >= 260 {
                    "unlimited".to_owned()
                } else {
                    self.max_fps.to_string()
                },
                on(self.vsync),
                on(self.fullscreen),
                on(self.smooth_lighting),
                self.clouds,
                self.biome_blend,
                self.mipmap_levels,
            ),
        );
        crate::crash::set_detail(
            "Resource Packs",
            if self.resource_packs.is_empty() {
                "vanilla".to_owned()
            } else {
                self.resource_packs.join(", ")
            },
        );
    }
    pub fn parse(text: &str) -> Self {
        Self::from_file(OptionsFile::parse(text))
    }
    /// Typed view of an options file.
    pub fn from_file(f: OptionsFile) -> Self {
        let mut keys = KeyBinds::default();
        for (name, _, _) in crate::keybinds::MAPPINGS {
            keys.set(name, &f.key_binding(name));
        }
        let mut volumes = [1.0; 11];
        for (i, source) in SOUND_SOURCES.iter().enumerate() {
            volumes[i] = f.double(&format!("soundCategory_{source}")) as f32;
        }
        Self {
            touch: crate::android_controls::Settings::load(),
            keypad: Default::default(),
            fov: f.int("fov") as f32,
            render_distance: f.int("renderDistance"),
            simulation_distance: f.int("simulationDistance"),
            sensitivity: f.double("mouseSensitivity") as f32,
            master_volume: volumes[0],
            volumes,
            sound_device: f.string("soundDevice"),
            gui_scale: f.int("guiScale").max(0) as u32,
            view_bobbing: f.bool("bobView"),
            gamma: f.double("gamma") as f32,
            max_fps: f.int("maxFps") as u32,
            vsync: f.bool("enableVsync"),
            fullscreen: f.bool("fullscreen"),
            smooth_lighting: f.bool("ao"),
            clouds: f.name("renderClouds"),
            cloud_range: f.int("cloudRange"),
            particles: f.int("particles") as u8,
            entity_distance: f.double("entityDistanceScaling") as f32,
            entity_shadows: f.bool("entityShadows"),
            biome_blend: f.int("biomeBlendRadius"),
            graphics_preset: f.name("graphicsPreset"),
            mipmap_levels: f.int("mipmapLevels"),
            weather_radius: f.int("weatherRadius"),
            chunk_fade: f.double("chunkSectionFadeInTime") as f32,
            vignette: f.bool("vignette"),
            autosave_indicator: f.bool("showAutosaveIndicator"),
            cutout_leaves: f.bool("cutoutLeaves"),
            improved_transparency: f.bool("improvedTransparency"),
            attack_indicator: f.int("attackIndicator") as u8,
            inactivity_fps_limit: f.name("inactivityFpsLimit"),
            // Saved by what turns it on (key `bedrockInventory`): a file from before it, which only
            // had `javaCreativeInventory`, now reads as off, i.e. the single window.
            bedrock_inventory: f.bool("bedrockInventory"),
            prioritize_chunk_updates: f.int("prioritizeChunkUpdates") as u8,
            menu_blur: f.int("menuBackgroundBlurriness"),
            invert_x: f.bool("invertXMouse"),
            invert_y: f.bool("invertYMouse"),
            mouse_wheel_sensitivity: f.double("mouseWheelSensitivity") as f32,
            discrete_scroll: f.bool("discrete_mouse_scroll"),
            allow_cursor_changes: f.bool("allowCursorChanges"),
            toggle_crouch: f.bool("toggleCrouch"),
            toggle_sprint: f.bool("toggleSprint"),
            toggle_attack: f.bool("toggleAttack"),
            toggle_use: f.bool("toggleUse"),
            sprint_window: f.int("sprintWindow"),
            operator_items_tab: f.bool("operatorItemsTab"),
            quit_shortcuts: f.bool("quitShortcuts"),
            ctrl_click_emulates_right_click: f.bool("ctrlClickEmulatesRightClick"),
            horizon: Default::default(),
            startup_api: Default::default(),
            video_modes: Vec::new(),
            controller: Default::default(),
            extras: Default::default(),
            mods: Default::default(),
            shader_packs: Vec::new(),
            shader_options: None,
            custom_buttons: Vec::new(),
            auto_jump: f.bool("autoJump"),
            language: f.string("lang"),
            force_unicode: f.bool("forceUnicodeFont"),
            japanese_glyphs: f.bool("japaneseGlyphVariants"),
            chat_visibility: f.int("chatVisibility") as u8,
            chat_colors: f.bool("chatColors"),
            chat_links: f.bool("chatLinks"),
            chat_links_prompt: f.bool("chatLinksPrompt"),
            chat_opacity: f.double("chatOpacity") as f32,
            chat_delay: f.double("chatDelay"),
            text_background_opacity: f.double("textBackgroundOpacity") as f32,
            chat_scale: f.double("chatScale") as f32,
            chat_width: f.double("chatWidth") as f32,
            chat_height_focused: f.double("chatHeightFocused") as f32,
            chat_height_unfocused: f.double("chatHeightUnfocused") as f32,
            chat_line_spacing: f.double("chatLineSpacing") as f32,
            auto_suggestions: f.bool("autoSuggestions"),
            reduced_debug_info: f.bool("reducedDebugInfo"),
            high_contrast: f.bool("highContrast"),
            show_subtitles: f.bool("showSubtitles"),
            notification_display_time: f.double("notificationDisplayTime") as f32,
            main_hand_left: f.name("mainHand") == "left",
            resource_packs: f.list("resourcePacks"),
            keys,
            file: f,
        }
    }
    /// `Options.createInformation`: what the server learns about this player (its language, for
    /// a plugin's messages, chat colours and particles too).
    pub fn client_information(&self, view_distance: i8) -> ClientInformation {
        ClientInformation {
            language: self.language.clone(),
            chat_visibility: self.chat_visibility as i32,
            chat_colors: self.chat_colors,
            model_customisation: self.file.model_customisation(),
            main_hand: i32::from(!self.main_hand_left),
            particle_status: i32::from(self.particles),
            allows_listing: self.file.bool("allowServerListing"),
            ..ClientInformation::new(view_distance)
        }
    }
    /// The options file reflecting the typed fields; values the game did not
    /// change keep their stored form.
    pub fn to_file(&self) -> OptionsFile {
        let mut f = self.file.clone();
        put_i(&mut f, "fov", self.fov as i32);
        put_i(&mut f, "renderDistance", self.render_distance);
        put_i(&mut f, "simulationDistance", self.simulation_distance);
        put_f(&mut f, "mouseSensitivity", self.sensitivity);
        for (i, source) in SOUND_SOURCES.iter().enumerate() {
            let v = if i == 0 {
                self.master_volume
            } else {
                self.volumes[i]
            };
            put_f(&mut f, &format!("soundCategory_{source}"), v);
        }
        put_s(&mut f, "soundDevice", &self.sound_device);
        put_i(&mut f, "guiScale", self.gui_scale as i32);
        put_b(&mut f, "bobView", self.view_bobbing);
        put_f(&mut f, "gamma", self.gamma);
        put_i(&mut f, "maxFps", self.max_fps as i32);
        put_b(&mut f, "enableVsync", self.vsync);
        put_b(&mut f, "fullscreen", self.fullscreen);
        put_b(&mut f, "ao", self.smooth_lighting);
        put_name(&mut f, "renderClouds", &self.clouds);
        put_i(&mut f, "cloudRange", self.cloud_range);
        put_i(&mut f, "particles", i32::from(self.particles));
        put_f(&mut f, "entityDistanceScaling", self.entity_distance);
        put_b(&mut f, "entityShadows", self.entity_shadows);
        put_i(&mut f, "biomeBlendRadius", self.biome_blend);
        put_name(&mut f, "graphicsPreset", &self.graphics_preset);
        put_i(&mut f, "mipmapLevels", self.mipmap_levels);
        put_i(&mut f, "weatherRadius", self.weather_radius);
        put_f(&mut f, "chunkSectionFadeInTime", self.chunk_fade);
        put_b(&mut f, "vignette", self.vignette);
        put_b(&mut f, "showAutosaveIndicator", self.autosave_indicator);
        put_b(&mut f, "cutoutLeaves", self.cutout_leaves);
        put_b(&mut f, "improvedTransparency", self.improved_transparency);
        put_i(&mut f, "attackIndicator", i32::from(self.attack_indicator));
        put_name(&mut f, "inactivityFpsLimit", &self.inactivity_fps_limit);
        put_b(&mut f, "bedrockInventory", self.bedrock_inventory);
        put_i(
            &mut f,
            "prioritizeChunkUpdates",
            i32::from(self.prioritize_chunk_updates),
        );
        put_i(&mut f, "menuBackgroundBlurriness", self.menu_blur);
        put_b(&mut f, "invertXMouse", self.invert_x);
        put_b(&mut f, "invertYMouse", self.invert_y);
        put_f(
            &mut f,
            "mouseWheelSensitivity",
            self.mouse_wheel_sensitivity,
        );
        put_b(&mut f, "discrete_mouse_scroll", self.discrete_scroll);
        put_b(&mut f, "allowCursorChanges", self.allow_cursor_changes);
        put_b(&mut f, "toggleCrouch", self.toggle_crouch);
        put_b(&mut f, "toggleSprint", self.toggle_sprint);
        put_b(&mut f, "toggleAttack", self.toggle_attack);
        put_b(&mut f, "toggleUse", self.toggle_use);
        put_i(&mut f, "sprintWindow", self.sprint_window);
        put_b(&mut f, "operatorItemsTab", self.operator_items_tab);
        put_b(&mut f, "quitShortcuts", self.quit_shortcuts);
        put_b(
            &mut f,
            "ctrlClickEmulatesRightClick",
            self.ctrl_click_emulates_right_click,
        );
        put_b(&mut f, "autoJump", self.auto_jump);
        put_s(&mut f, "lang", &self.language);
        put_b(&mut f, "forceUnicodeFont", self.force_unicode);
        put_b(&mut f, "japaneseGlyphVariants", self.japanese_glyphs);
        put_i(&mut f, "chatVisibility", i32::from(self.chat_visibility));
        put_b(&mut f, "chatColors", self.chat_colors);
        put_b(&mut f, "chatLinks", self.chat_links);
        put_b(&mut f, "chatLinksPrompt", self.chat_links_prompt);
        put_f(&mut f, "chatOpacity", self.chat_opacity);
        if self.chat_delay != f.double("chatDelay") {
            f.set("chatDelay", V::Double(self.chat_delay));
        }
        put_f(
            &mut f,
            "textBackgroundOpacity",
            self.text_background_opacity,
        );
        put_f(&mut f, "chatScale", self.chat_scale);
        put_f(&mut f, "chatWidth", self.chat_width);
        put_f(&mut f, "chatHeightFocused", self.chat_height_focused);
        put_f(&mut f, "chatHeightUnfocused", self.chat_height_unfocused);
        put_f(&mut f, "chatLineSpacing", self.chat_line_spacing);
        put_b(&mut f, "autoSuggestions", self.auto_suggestions);
        put_b(&mut f, "reducedDebugInfo", self.reduced_debug_info);
        put_b(&mut f, "highContrast", self.high_contrast);
        put_b(&mut f, "showSubtitles", self.show_subtitles);
        put_f(
            &mut f,
            "notificationDisplayTime",
            self.notification_display_time,
        );
        put_name(
            &mut f,
            "mainHand",
            if self.main_hand_left { "left" } else { "right" },
        );
        if self.resource_packs != f.list("resourcePacks") {
            f.set("resourcePacks", V::List(self.resource_packs.clone()));
        }
        for (name, key) in self.keys.saved() {
            put_s(&mut f, &format!("key_{name}"), &key);
        }
        f
    }
    /// These settings with one `options.txt` value changed (`horizon-ctl
    /// options-set`, as `OptionsFile::set_text` reads it). Horizon's own
    /// files (graphics, controller, extras, the mod list) aren't in
    /// `options.txt`, so they stay as they are, as do the monitor's video modes.
    pub fn with_option(&self, key: &str, value: &str) -> Result<Self, String> {
        let mut file = self.to_file();
        file.set_text(key, value)?;
        let mut next = Self {
            horizon: self.horizon.clone(),
            controller: self.controller.clone(),
            keypad: self.keypad.clone(),
            extras: self.extras.clone(),
            mods: self.mods.clone(),
            video_modes: self.video_modes.clone(),
            ..Self::from_file(file)
        };
        // Horizon's own bindings aren't in options.txt.
        next.keys.set("key.emote", self.keys.get("key.emote"));
        Ok(next)
    }
    /// The `options.txt` text (Options.save).
    pub fn serialize(&self) -> String {
        self.to_file().serialize()
    }
    pub fn save(&self, path: &Path) {
        self.describe_for_crashes();
        if let Err(e) = fs::write(path, self.serialize()) {
            log::warn!("Horizon: options.txt is not saved: {e}");
        }
        if let Some(dir) = path.parent() {
            self.horizon.save(dir);
            self.controller.save(dir);
            let _ = self.keypad.save(&dir.join("horizon-keypad.json"));
            let mut extras = self.extras.clone();
            extras.emote_key = self.keys.get("key.emote").to_owned();
            extras.save(dir);
            horizon_hooks::settings::engine::save_own(dir, &[crate::extras::FILE]);
            self.mods.save(&crate::logging::shared_dir(dir));
        }
    }
    /// Volume of a sound source (master excluded).
    pub fn volume(&self, source: &str) -> f32 {
        SOUND_SOURCES
            .iter()
            .position(|n| *n == source)
            .map_or(1.0, |i| {
                if i == 0 {
                    self.master_volume
                } else {
                    self.volumes[i]
                }
            })
    }
    /// `Options.getFinalSoundSourceVolume`: a source's volume times master's.
    pub fn final_volume(&self, source: &str) -> f32 {
        if source == "master" {
            self.master_volume
        } else {
            self.volume(source) * self.master_volume
        }
    }
    /// `Options.narrator`: the `narrator` id in options.txt.
    pub fn narrator(&self) -> horizon_narrator::Status {
        horizon_narrator::Status::by_id(self.file.int("narrator"))
    }
    pub fn set_narrator(&mut self, status: horizon_narrator::Status) {
        self.file
            .set("narrator", crate::options_file::V::Int(status.id()));
    }
    /// `Options.getBackgroundColor(float)`: the text backdrop colour, `default`
    /// opacity unless `backgroundForChatOnly` is off.
    pub fn text_background(&self, default: f32) -> u32 {
        crate::hud_layout::background_color(
            self.file.bool("backgroundForChatOnly"),
            f64::from(self.text_background_opacity),
            default,
        )
    }
    pub fn chat_options(&self) -> crate::chat::ChatOptions {
        crate::chat::ChatOptions {
            opacity: f64::from(self.chat_opacity),
            background_opacity: f64::from(self.text_background_opacity),
            scale: f64::from(self.chat_scale),
            width: f64::from(self.chat_width),
            height_focused: f64::from(self.chat_height_focused),
            height_unfocused: f64::from(self.chat_height_unfocused),
            line_spacing: f64::from(self.chat_line_spacing),
            colors: self.chat_colors,
        }
    }
}

/// One option instance.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Opt {
    TouchMode,
    TouchAnalog,
    TouchCircleSize,
    TouchAttackSide,
    TouchHorizontalMargin,
    TouchVerticalMargin,
    TouchSensitivity,
    TouchSensitivityHorizontal,
    TouchSensitivityVertical,
    TouchMouseButton,
    TouchKeyboardButton,
    TouchOffhand,
    TouchShield,
    TouchButtonScale,
    TouchInteract,
    TouchLeftHand,
    TouchSprintButton,
    TouchSprintToggle,
    TouchInventoryControls,
    TouchMouseSensitivity,
    TouchCrosshairGestures,
    TouchControlHub,
    TouchUiVibration,
    TouchGameVibration,
    TouchAttackButtonLook,
    TouchDynamicJoystick,
    TouchDynamicAreaX,
    TouchDynamicAreaY,
    AndroidGyroscope,
    AndroidGyroSensitivity,
    TouchSwapJumpSneak,
    TouchAutoSprint,
    TouchAvoidCutout,
    AndroidInputSelection,

    Fov,
    RenderDistance,
    SimulationDistance,
    Sensitivity,
    WheelSensitivity,
    DiscreteScroll,
    InvertX,
    InvertY,
    AllowCursorChanges,
    Volume(usize),
    /// Setting `.1` of the native mod in row `.0` of Options > Mods, a range on a slider.
    ModSetting(u16, u16),
    SoundDevice,
    GuiScale,
    ViewBobbing,
    Gamma,
    MaxFps,
    Vsync,
    Fullscreen,
    SmoothLighting,
    Clouds,
    CloudRange,
    Particles,
    EntityDistance,
    EntityShadows,
    BiomeBlend,
    Preset,
    Mipmaps,
    WeatherRadius,
    ChunkFade,
    Vignette,
    Autosave,
    CutoutLeaves,
    ImprovedTransparency,
    AttackIndicator,
    InactivityFps,
    ChunkBuilder,
    MenuBlur,
    ToggleCrouch,
    ToggleSprint,
    ToggleAttack,
    ToggleUse,
    AutoJump,
    SprintWindow,
    QuitShortcuts,
    CtrlClickEmulatesRightClick,
    OperatorItemsTab,
    ChatVisibility,
    ChatColors,
    ChatLinks,
    ChatLinksPrompt,
    ChatOpacity,
    TextBackgroundOpacity,
    ChatScale,
    ChatWidth,
    ChatHeightFocused,
    ChatHeightUnfocused,
    ChatLineSpacing,
    AutoSuggestions,
    HideMatchedNames,
    ReducedDebugInfo,
    OnlySecureChat,
    SaveChatDrafts,
    HighContrast,
    ShowSubtitles,
    MusicFrequency,
    NotificationDisplayTime,
    Narrator,
    TextBackground,
    ChatDelay,
    DistortionEffects,
    FovEffects,
    DarknessPulsing,
    DamageTilt,
    GlintSpeed,
    GlintStrength,
    HideLightningFlashes,
    MonochromeLogo,
    PanoramaSpeed,
    HideSplashTexts,
    NarratorHotkey,
    RotateWithMinecarts,
    HighContrastBlockOutlines,
    ForceUnicode,
    JapaneseGlyphs,
    /// Horizon's controller settings (`horizon-controller.txt`).
    PadEnabled,
    PadVibration,
    PadPlayInBackground,
    PadAdaptiveTriggers,
    PadLightbar,
    PadLookSensitivity,
    PadPointerSpeed,
    PadScrollSpeed,
    PadRepeatDelay,
    PadRepeatInterval,
    PadInvertX,
    PadInvertY,
    PadCraftOnServers,
    PadToggleSneak,
    PadServerStick,
    PadStickPrompt,
    PadMoveDeadzone,
    PadLookDeadzone,
    PadTriggerThreshold,
    PadGlyphs,
    /// A Nintendo pad's face buttons by place or by letter (`PadSettings::nintendo_letters`).
    PadNintendoButtons,
    PadKeyboard,
    PadGameplayGuide,
    /// The radial menu's opener held or pressed once (`PadSettings::radial_mode`).
    PadRadialMode,
    /// The stick the radial menu selects with (`PadSettings::radial_stick`).
    PadRadialStick,
    /// `options.modelPart.*`: one skin layer (index into `options_file::MODEL_PARTS`).
    ModelPart(usize),
    /// A slider of a page a crate registered (`horizon_hooks::pages`): (page, row).
    Page(usize, usize),
    /// 3D skin layers: the player's outer layer as extruded slabs.
    SkinLayers3d,
    MainHand,
    AllowServerListing,
    RealmsNotifications,
    InGameNotification,
    SharePresence,
    DirectionalAudio,
    MusicToast,
    /// `Options.exclusiveFullscreen`.
    ExclusiveFullscreen,
    /// VideoSettingsScreen's "Exclusive Fullscreen Mode": the monitor's mode to take.
    ExclusiveMode,
    /// `Options.preferredGraphicsBackend`.
    GraphicsBackend,
    /// `Options.textureFiltering`.
    TextureFiltering,
    /// `Options.maxAnisotropyBit`.
    MaxAnisotropy,
}

impl Settings {
    /// GUI scaling inputs for this settings owner.
    pub fn gui_scale_inputs(&self) -> crate::hud::GuiScale {
        crate::hud::GuiScale {
            requested: self.gui_scale,
            unicode: self.force_unicode,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn the_narrator_reads_its_status_and_the_voice_under_master() {
        let s = Settings::parse("narrator:2\nsoundCategory_master:0.5\nsoundCategory_voice:0.5\n");
        assert_eq!(s.narrator(), horizon_narrator::Status::Chat);
        assert_eq!(s.final_volume("voice"), 0.25);
        assert_eq!(s.final_volume("master"), 0.5);
        let mut s = s;
        s.set_narrator(horizon_narrator::Status::Off);
        assert_eq!(
            Settings::parse(&s.serialize()).narrator(),
            horizon_narrator::Status::Off
        );
    }
    /// `Monster.getSoundSource`: the verified families and inherited common sounds.
    #[test]
    fn hostile_families_keep_their_sound_category() {
        for (event, source) in [
            ("entity.zombie.hurt", 5),
            ("entity.cow.hurt", 6),
            ("block.stone.break", 4),
            ("entity.player.hurt", 7),
            ("entity.arrow.hit", 7),
            ("music_disc.13", 2),
            ("item.goat_horn.sound.0", 2),
            ("weather.rain", 3),
            ("ambient.cave", 8),
        ] {
            assert_eq!(sound_source(event), source, "{event}");
        }
        // Explicit sources still take precedence, including H331's arrow route.
        let mut audio = crate::audio::Audio::silent(
            &horizon_assets::resource_source::ResourceSource::directory(
                Path::new("/nonexistent/h068-audio").to_path_buf(),
            ),
        );
        audio.capture = Some(Vec::new());
        audio.play_on(6, "minecraft:entity.arrow.hit", Some([1.0; 3]), 1.0, 1.0);
        audio.play_on(4, "minecraft:entity.warden.hurt", Some([1.0; 3]), 1.0, 1.0);
        assert_eq!(
            audio
                .capture
                .as_ref()
                .unwrap()
                .iter()
                .map(|s| s.source)
                .collect::<Vec<_>>(),
            [6, 4]
        );
        for family in [
            "bogged",
            "breeze",
            "endermite",
            "parched",
            "warden",
            "zombie_villager",
            "vex",
            "wither",
            "hostile",
        ] {
            for suffix in ["hurt", "death"] {
                for prefix in ["", "minecraft:"] {
                    let event = format!("{prefix}entity.{family}.{suffix}");
                    assert_eq!(sound_source(&event), 5, "{event}");
                }
            }
        }
    }

    #[test]
    fn three_d_skin_layers_move_from_options_txt_to_the_extras_file() {
        // #8091 wrote the switch into options.txt; a player who had it on keeps
        // it, and the next options.txt is vanilla's again.
        let dir = std::env::temp_dir().join(format!(
            "horizon-skin-layers-{}-{:?}",
            std::process::id(),
            std::thread::current().id()
        ));
        fs::create_dir_all(&dir).unwrap();
        fs::write(dir.join("options.txt"), "fov:0.5\nthreeDSkinLayers:true\n").unwrap();
        let s = Settings::load(&dir.join("options.txt"));
        assert!(s.extras.three_d_skin_layers);
        assert_eq!(s.fov, 90.0);
        assert!(!s.serialize().contains("threeDSkinLayers"));
        assert!(crate::extras::Extras::parse(&s.extras.serialize()).three_d_skin_layers);
        // Once horizon-extras.txt has its own line, a stale options.txt one is ignored.
        fs::write(dir.join(crate::extras::FILE), "threeDSkinLayers:false\n").unwrap();
        assert!(
            !Settings::load(&dir.join("options.txt"))
                .extras
                .three_d_skin_layers
        );
        let _ = fs::remove_dir_all(&dir);
    }
    fn scratch(name: &str) -> std::path::PathBuf {
        let dir = std::env::temp_dir().join(format!(
            "horizon-{name}-{}-{:?}",
            std::process::id(),
            std::thread::current().id()
        ));
        let _ = fs::remove_dir_all(&dir);
        fs::create_dir_all(&dir).unwrap();
        dir
    }

    #[test]
    fn options_txt_lists_only_vanillas_key_mappings() {
        // Options.keyMappings has the friends key, then social interactions; Horizon's emote key
        // (#10092 put it between them) is not in the file.
        let out = Settings::default().serialize();
        assert!(!out.contains("emote"), "{out}");
        assert!(out.contains(
            "\nkey_key.friends:key.keyboard.o\nkey_key.socialInteractions:key.keyboard.p\n"
        ));
        let mut s = Settings::default();
        s.keys.set("key.emote", "key.keyboard.g");
        assert!(!s.serialize().contains("emote"));
    }

    #[test]
    fn the_emote_key_is_kept_in_the_extras_file() {
        let dir = scratch("emote-key");
        let options = dir.join("options.txt");
        // Untouched: no extras file is made for it.
        Settings::default().save(&options);
        assert!(!dir.join(crate::extras::FILE).exists());
        assert_eq!(
            Settings::load(&options).keys.get("key.emote"),
            "key.keyboard.b"
        );
        // Rebound in Controls: saved to horizon-extras.txt, and options.txt stays vanilla's.
        let mut s = Settings::load(&options);
        s.keys.set("key.emote", "key.keyboard.g");
        s.save(&options);
        assert!(!fs::read_to_string(&options).unwrap().contains("emote"));
        let extras = fs::read_to_string(dir.join(crate::extras::FILE)).unwrap();
        assert!(
            extras.lines().any(|l| l == "emoteKey:key.keyboard.g"),
            "{extras}"
        );
        let back = Settings::load(&options);
        assert_eq!(back.keys.get("key.emote"), "key.keyboard.g");
        // horizon-ctl options-set rebuilds from options.txt text and keeps it.
        assert_eq!(
            back.with_option("fov", "90").unwrap().keys.get("key.emote"),
            "key.keyboard.g"
        );
        // Reset to B and back to the default: the file says so.
        let mut s = back;
        s.keys.set(
            "key.emote",
            crate::keybinds::KeyBinds::default_of("key.emote"),
        );
        s.save(&options);
        assert_eq!(
            Settings::load(&options).keys.get("key.emote"),
            "key.keyboard.b"
        );
        let _ = fs::remove_dir_all(&dir);
    }

    #[test]
    fn the_emote_key_moves_from_options_txt_to_the_extras_file() {
        // #10092 wrote `key_key.emote` into options.txt; a rebound key is kept, the next
        // options.txt is vanilla's again.
        let dir = scratch("emote-key-move");
        let options = dir.join("options.txt");
        fs::write(
            &options,
            "version:4000\nfov:0.5\nkey_key.emote:key.keyboard.h\nkey_key.jump:key.keyboard.j\n",
        )
        .unwrap();
        let s = Settings::load(&options);
        assert_eq!(s.keys.get("key.emote"), "key.keyboard.h");
        assert_eq!(s.keys.get("key.jump"), "key.keyboard.j");
        s.save(&options);
        assert!(!fs::read_to_string(&options).unwrap().contains("emote"));
        assert_eq!(
            Settings::load(&options).keys.get("key.emote"),
            "key.keyboard.h"
        );
        // Once horizon-extras.txt has its own line, a stale options.txt one is ignored.
        fs::write(dir.join(crate::extras::FILE), "emoteKey:key.keyboard.k\n").unwrap();
        fs::write(&options, "version:4000\nkey_key.emote:key.keyboard.h\n").unwrap();
        assert_eq!(
            Settings::load(&options).keys.get("key.emote"),
            "key.keyboard.k"
        );
        // A value that is no key is not adopted; an unbound emote key is.
        fs::remove_file(dir.join(crate::extras::FILE)).unwrap();
        fs::write(&options, "version:4000\nkey_key.emote:banana\n").unwrap();
        assert_eq!(
            Settings::load(&options).keys.get("key.emote"),
            "key.keyboard.b"
        );
        fs::write(
            &options,
            "version:4000\nkey_key.emote:key.keyboard.unknown\n",
        )
        .unwrap();
        assert_eq!(
            Settings::load(&options).keys.get("key.emote"),
            "key.keyboard.unknown"
        );
        let _ = fs::remove_dir_all(&dir);
    }

    #[test]
    fn an_option_set_keeps_horizon_files() {
        let mut s = Settings::parse("fov:70\n");
        s.mods.enabled.insert("zoom".into());
        s.extras.minimap = true;
        s.horizon.fog = !s.horizon.fog;
        s.controller.vibration = !s.controller.vibration;
        let set = s.with_option("fov", "90").unwrap();
        assert_eq!(set.fov, 90.0);
        assert_eq!(set.mods, s.mods);
        assert_eq!(set.extras, s.extras);
        assert_eq!(set.horizon, s.horizon);
        assert_eq!(set.controller, s.controller);
        assert!(s.with_option("fov", "200").is_err());
    }
    #[test]
    fn gui_scale_survives_temporary_small_framebuffer() {
        for requested in [0, 1, 2, 6] {
            let settings = Settings::parse(&format!("guiScale:{requested}\n"));
            // Hyprland's initial surface can be smaller than the fullscreen one.
            for (framebuffer, maximum) in [([715, 860], 2), ([3400, 1913], 7)] {
                let effective = crate::window::calculate_scale(
                    framebuffer,
                    settings.gui_scale as i32,
                    settings.force_unicode,
                );
                assert_eq!(
                    effective,
                    if requested == 0 {
                        maximum
                    } else {
                        (requested as i32).min(maximum)
                    }
                );
                let saved = Settings::parse(&settings.serialize());
                assert_eq!(saved.gui_scale, requested);
            }
        }
    }

    #[test]
    fn round_trips_vanilla_options_txt() {
        let text = "version:4000\nfov:0.5\nrenderDistance:16\nmaxFps:260\nrenderClouds:\"fast\"\nkey_key.jump:key.keyboard.j\nsoundCategory_music:0.25\nresourcePacks:[\"vanilla\",\"file/x.zip\"]\nlang:fr_fr\nsomeFutureOption:42\n";
        let s = Settings::parse(text);
        assert_eq!(s.fov, 90.0);
        assert_eq!(s.render_distance, 16);
        assert_eq!(s.max_fps, 260);
        assert_eq!(s.clouds, "fast");
        assert_eq!(s.keys.get("key.jump"), "key.keyboard.j");
        assert_eq!(s.volume("music"), 0.25);
        assert_eq!(s.resource_packs, ["vanilla", "file/x.zip"]);
        assert_eq!(s.language, "fr_fr");
        let out = s.serialize();
        assert!(out.starts_with("version:"));
        assert!(out.contains("\nkey_key.jump:key.keyboard.j\n"));
        // Options.save writes only the options it knows.
        assert!(!out.contains("someFutureOption"));
        assert!(out.contains("\nrenderClouds:\"fast\"\n"));
        let again = Settings::parse(&out);
        assert_eq!(again.fov, 90.0);
        assert_eq!(again.keys.get("key.jump"), "key.keyboard.j");
    }
    #[test]
    fn client_information_maps_the_stored_main_hand() {
        // The Skin Customization option is stored by name; ClientInformation
        // sends HumanoidArm (LEFT = 0, RIGHT = 1).
        for (stored, arm) in [("left", 0), ("right", 1)] {
            let s = Settings::parse(&format!("mainHand:{stored}\n"));
            assert_eq!(s.client_information(10).main_hand, arm);
            assert!(s.serialize().contains(&format!("mainHand:\"{stored}\"")));
        }
        assert_eq!(Settings::default().client_information(10).main_hand, 1);
    }
    #[test]
    fn no_options_txt_paces_frames_like_an_empty_one() {
        let (fresh, empty) = (Settings::default(), Settings::parse(""));
        assert_eq!(fresh.max_fps, 120);
        assert_eq!(fresh.max_fps, empty.max_fps);
        assert_eq!(fresh.vsync, empty.vsync);
        assert_eq!(fresh.inactivity_fps_limit, empty.inactivity_fps_limit);
        assert_eq!(fresh.render_distance, empty.render_distance);
        assert_eq!(fresh.simulation_distance, empty.simulation_distance);
    }
    #[test]
    fn subtitle_options() {
        let s = Settings::parse("showSubtitles:true\nnotificationDisplayTime:2.5\n");
        assert!(s.show_subtitles);
        assert_eq!(s.notification_display_time, 2.5);
        let again = Settings::parse(&s.serialize());
        assert!(again.show_subtitles);
        assert_eq!(again.notification_display_time, 2.5);
        let d = Settings::parse("");
        assert!(!d.show_subtitles);
        assert_eq!(d.notification_display_time, 1.0);
        // Codec.doubleRange(0.5, 10.0) rejects other values; the default stays.
        assert_eq!(
            Settings::parse("notificationDisplayTime:50\n").notification_display_time,
            1.0
        );
    }
    #[test]
    fn sound_device_option() {
        let s = Settings::parse("soundDevice:\"Headphones\"\n");
        assert_eq!(s.sound_device, "Headphones");
        let serialized = s.serialize();
        assert!(serialized.contains("soundDevice:\"Headphones\""));
        let again = Settings::parse(&serialized);
        assert_eq!(again.sound_device, "Headphones");
        let empty = Settings::parse("");
        assert_eq!(empty.sound_device, "");
    }
}
