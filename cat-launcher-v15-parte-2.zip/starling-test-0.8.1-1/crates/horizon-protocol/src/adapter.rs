//! Speaking to servers of an older release: the first layer of the native protocol adapter (roadmap
//! `older-servers`). Horizon's packets are 26.3's; a server on another protocol numbers them differently.
//! This maps packet ids per connection state, both ways; a [`Session`] follows one connection's states
//! and renumbers what goes through it. [`ids`] renumbers the registry ids inside packets as the shared
//! readers decode them, and `translate` rewrites the packets whose layout changed. An older version is
//! translated a release at a time (26.1 to 26.2, then 26.2 to 26.3), with its ids mapped straight to the
//! pinned ones. A Horizon server runs the ids the other way for a client of an older release
//! ([`ClientSession`], roadmap `older-clients`), when its owner lets such clients join.
pub mod client_session;
pub mod ids;
pub mod layout_26_2;
mod legacy;
mod pinned_ids;
pub mod session;
mod translate;
pub(crate) use translate::v1_20_2::read_component as read_legacy_component;
pub mod v1_20_2;
mod v1_20_2_ids;
pub mod v1_20_3;
mod v1_20_3_ids;
pub mod v1_20_6;
mod v1_20_6_ids;
pub mod v1_21_1;
pub mod v1_21_10;
mod v1_21_10_ids;
pub mod v1_21_11;
mod v1_21_11_ids;
mod v1_21_1_ids;
pub mod v1_21_3;
mod v1_21_3_ids;
pub mod v1_21_4;
mod v1_21_4_ids;
pub mod v1_21_5;
mod v1_21_5_ids;
pub mod v1_21_6;
mod v1_21_6_ids;
pub mod v1_21_8;
mod v1_21_8_ids;
pub mod v26_1_2;
mod v26_1_2_ids;
pub mod v26_2;
mod v26_2_ids;

pub use client_session::ClientSession;
pub use session::Session;

use crate::{
    Direction, Result, State,
    buf::{Reader, write_varint},
};

/// The protocol a server speaks.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Hash)]
pub enum ServerVersion {
    /// The pinned version ([`crate::PROTOCOL_VERSION`]): nothing to translate.
    #[default]
    Current,
    V26_2,
    /// 26.1, 26.1.1 and 26.1.2: one protocol.
    V26_1,
    V1_21_11,
    /// 1.21.9 and 1.21.10: one protocol.
    V1_21_10,
    /// 1.21.7 and 1.21.8: one protocol.
    V1_21_8,
    V1_21_6,
    V1_21_5,
    V1_21_4,
    /// 1.21.2 and 1.21.3: one protocol.
    V1_21_3,
    /// 1.21 and 1.21.1: one protocol.
    V1_21_1,
    /// 1.20.5 and 1.20.6: one protocol.
    V1_20_6,
    /// 1.20.3 and 1.20.4: one protocol.
    V1_20_3,
    V1_20_2,
}

impl ServerVersion {
    /// Newest first.
    pub const ALL: [Self; 14] = [
        Self::Current,
        Self::V26_2,
        Self::V26_1,
        Self::V1_21_11,
        Self::V1_21_10,
        Self::V1_21_8,
        Self::V1_21_6,
        Self::V1_21_5,
        Self::V1_21_4,
        Self::V1_21_3,
        Self::V1_21_1,
        Self::V1_20_6,
        Self::V1_20_3,
        Self::V1_20_2,
    ];

    /// Whether this is `other` or an older release: the translation steps from `other` up apply.
    pub fn at_most(self, other: Self) -> bool {
        let age = |v: Self| Self::ALL.iter().position(|&a| a == v).unwrap_or(0);
        age(self) >= age(other)
    }

    /// The protocol number its handshake states.
    pub fn protocol(self) -> i32 {
        match self {
            Self::Current => crate::PROTOCOL_VERSION,
            Self::V26_2 => v26_2::PROTOCOL,
            Self::V26_1 => v26_1_2::PROTOCOL,
            Self::V1_21_11 => v1_21_11::PROTOCOL,
            Self::V1_21_10 => v1_21_10::PROTOCOL,
            Self::V1_21_8 => v1_21_8::PROTOCOL,
            Self::V1_21_6 => v1_21_6::PROTOCOL,
            Self::V1_21_5 => v1_21_5::PROTOCOL,
            Self::V1_21_4 => v1_21_4::PROTOCOL,
            Self::V1_21_3 => v1_21_3::PROTOCOL,
            Self::V1_21_1 => v1_21_1::PROTOCOL,
            Self::V1_20_6 => v1_20_6::PROTOCOL,
            Self::V1_20_3 => v1_20_3::PROTOCOL,
            Self::V1_20_2 => v1_20_2::PROTOCOL,
        }
    }

    /// The release name, as a server list shows it.
    pub fn name(self) -> &'static str {
        match self {
            Self::Current => crate::GAME_VERSION,
            Self::V26_2 => v26_2::NAME,
            Self::V26_1 => "26.1",
            Self::V1_21_11 => v1_21_11::NAME,
            Self::V1_21_10 => "1.21.10",
            Self::V1_21_8 => v1_21_8::NAME,
            Self::V1_21_6 => v1_21_6::NAME,
            Self::V1_21_5 => v1_21_5::NAME,
            Self::V1_21_4 => v1_21_4::NAME,
            Self::V1_21_3 => v1_21_3::NAME,
            Self::V1_21_1 => v1_21_1::NAME,
            Self::V1_20_6 => v1_20_6::NAME,
            Self::V1_20_3 => v1_20_3::NAME,
            Self::V1_20_2 => v1_20_2::NAME,
        }
    }

    /// The version a server's status reports by its protocol number.
    pub fn from_protocol(protocol: i32) -> Option<Self> {
        Self::ALL.into_iter().find(|v| v.protocol() == protocol)
    }

    /// The pinned version's id for a packet this version's server sent as `id`. `None` when the pinned
    /// version has no such packet.
    pub fn clientbound_id(self, state: State, id: i32) -> Option<i32> {
        self.map(state, Direction::Clientbound, id)
    }

    /// The id this version's server knows a packet Horizon sends as `id` by. `None` when that server has
    /// no such packet, so it must not be sent.
    pub fn serverbound_id(self, state: State, id: i32) -> Option<i32> {
        self.map(state, Direction::Serverbound, id)
    }

    /// How this version numbers block states and registries, against the pinned one. `None` for the pinned
    /// version itself.
    pub fn ids(self) -> Option<&'static ids::Ids> {
        // Before 26.3 a tag slot display was a bare tag id, and pot decorations were item ids.
        const BEFORE_26_3: ids::Quirks = ids::Quirks {
            tag_slot_display_is_id: true,
            pot_decorations_are_items: true,
            ..ids::Quirks::NONE
        };
        // Before 26.1 registry entries in components were EitherHolders, damage resistance a tag,
        // and components held ItemStacks rather than templates.
        const BEFORE_26_1: ids::Quirks = ids::Quirks {
            either_holders_and_tag_resistance: true,
            stacks_in_components: true,
            ..BEFORE_26_3
        };
        static V26_2: ids::Ids = ids::Ids {
            quirks: BEFORE_26_3,
            ..v26_2_ids::IDS
        };
        static V26_1: ids::Ids = ids::Ids {
            quirks: BEFORE_26_3,
            ..v26_1_2_ids::IDS
        };
        static V1_21_11: ids::Ids = ids::Ids {
            quirks: BEFORE_26_1,
            // 26.1 registered the cat, cow, pig and chicken sound variants among the others.
            entity_data_serializer: ids::Remap::Runs {
                up: &[
                    (0, 0, 22),
                    (22, 23, 1),
                    (23, 25, 4),
                    (27, 30, 1),
                    (28, 32, 11),
                ],
                down: &[
                    (0, 0, 22),
                    (23, 22, 1),
                    (25, 23, 4),
                    (30, 27, 1),
                    (32, 28, 11),
                ],
            },
            ..v1_21_11_ids::IDS
        };
        static V1_21_10: ids::Ids = ids::Ids {
            quirks: BEFORE_26_1,
            // As 1.21.11's, without the zombie nautilus variant 1.21.11 added after the chicken's.
            entity_data_serializer: ids::Remap::Runs {
                up: &[
                    (0, 0, 22),
                    (22, 23, 1),
                    (23, 25, 4),
                    (27, 30, 1),
                    (28, 33, 9),
                ],
                down: &[
                    (0, 0, 22),
                    (23, 22, 1),
                    (25, 23, 4),
                    (30, 27, 1),
                    (33, 28, 9),
                ],
            },
            ..v1_21_10_ids::IDS
        };
        static V1_21_8: ids::Ids = ids::Ids {
            quirks: ids::Quirks {
                shoulder_parrots_as_nbt: true,
                count_first_templates: true,
                optional_profile_fields: true,
                simple_spell_particles: true,
                ..BEFORE_26_1
            },
            // EntityDataSerializers in 1.21.8's registration order: compound tags (16) went away;
            // the later sound variants, copper golem states and profile serializers were added.
            entity_data_serializer: ids::Remap::Runs {
                up: &[
                    (0, 0, 16),
                    (17, 16, 6),
                    (23, 23, 1),
                    (24, 25, 4),
                    (28, 30, 1),
                    (29, 33, 4),
                    (33, 39, 2),
                ],
                down: &[
                    (0, 0, 16),
                    (16, 17, 6),
                    (23, 23, 1),
                    (25, 24, 4),
                    (30, 28, 1),
                    (33, 29, 4),
                    (39, 33, 2),
                ],
            },
            ..v1_21_8_ids::IDS
        };
        static V1_21_6: ids::Ids = ids::Ids {
            // The same layouts and metadata serializers, with the item/sound numbering before
            // 1.21.7 added the lava chicken disc. Other registries are shared by generated tables.
            quirks: V1_21_8.quirks,
            entity_data_serializer: V1_21_8.entity_data_serializer,
            ..v1_21_6_ids::IDS
        };
        static V1_21_5: ids::Ids = ids::Ids {
            quirks: ids::Quirks {
                components_before_1_21_6: true,
                ..V1_21_8.quirks
            },
            entity_data_serializer: V1_21_8.entity_data_serializer,
            ..v1_21_5_ids::IDS
        };
        static V1_21_4: ids::Ids = ids::Ids {
            quirks: ids::Quirks {
                wolf_variant_holder: true,
                components_before_1_21_5: true,
                ..V1_21_5.quirks
            },
            // Vanilla EntityDataSerializers' registration order (not their declaration order).
            entity_data_serializer: ids::Remap::Runs {
                up: &[
                    (0, 0, 16),
                    (17, 16, 6),
                    (23, 25, 1),
                    (24, 27, 1),
                    (25, 33, 4),
                    (29, 39, 2),
                ],
                down: &[
                    (0, 0, 16),
                    (16, 17, 6),
                    (25, 23, 1),
                    (27, 24, 1),
                    (33, 25, 4),
                    (39, 29, 2),
                ],
            },
            ..v1_21_4_ids::IDS
        };
        static V1_21_3: ids::Ids = ids::Ids {
            quirks: ids::Quirks {
                integer_custom_model_data: true,
                trail_without_duration: true,
                ..V1_21_4.quirks
            },
            entity_data_serializer: V1_21_4.entity_data_serializer,
            ..v1_21_3_ids::IDS
        };
        static V1_21_1: ids::Ids = ids::Ids {
            quirks: ids::Quirks {
                components_before_1_21_2: true,
                ..V1_21_3.quirks
            },
            entity_data_serializer: V1_21_3.entity_data_serializer,
            ..v1_21_1_ids::IDS
        };
        static V1_20_6: ids::Ids = ids::Ids {
            quirks: ids::Quirks {
                components_before_1_21: true,
                wolf_variant_holder: false,
                ..V1_21_1.quirks
            },
            entity_data_serializer: V1_21_1.entity_data_serializer,
            ..v1_20_6_ids::IDS
        };
        static V1_20_3: ids::Ids = ids::Ids {
            quirks: ids::Quirks {
                legacy_item_nbt: true,
                legacy_item_data_version: 3698,
                ..V1_20_6.quirks
            },
            // EntityDataSerializers registration order before PARTICLES, WOLF_VARIANT and ARMADILLO_STATE.
            entity_data_serializer: ids::Remap::Runs {
                up: &[
                    (0, 0, 16),
                    (17, 16, 1),
                    (18, 18, 4),
                    (22, 27, 1),
                    (23, 33, 3),
                    (26, 39, 2),
                ],
                down: &[
                    (0, 0, 16),
                    (16, 17, 1),
                    (18, 18, 4),
                    (27, 22, 1),
                    (33, 23, 3),
                    (39, 26, 2),
                ],
            },
            ..v1_20_3_ids::IDS
        };
        static V1_20_2: ids::Ids = ids::Ids {
            quirks: ids::Quirks {
                legacy_item_data_version: 3578,
                components_as_json: true,
                vibration_source_identifier: true,
                ..V1_20_3.quirks
            },
            entity_data_serializer: V1_20_3.entity_data_serializer,
            ..v1_20_2_ids::IDS
        };
        match self {
            Self::Current => None,
            Self::V26_2 => Some(&V26_2),
            Self::V26_1 => Some(&V26_1),
            Self::V1_21_11 => Some(&V1_21_11),
            Self::V1_21_10 => Some(&V1_21_10),
            Self::V1_21_8 => Some(&V1_21_8),
            Self::V1_21_6 => Some(&V1_21_6),
            Self::V1_21_5 => Some(&V1_21_5),
            Self::V1_21_4 => Some(&V1_21_4),
            Self::V1_21_3 => Some(&V1_21_3),
            Self::V1_21_1 => Some(&V1_21_1),
            Self::V1_20_6 => Some(&V1_20_6),
            Self::V1_20_3 => Some(&V1_20_3),
            Self::V1_20_2 => Some(&V1_20_2),
        }
    }

    /// The id a client of this version knows a packet a Horizon server sends as `id` by: the inverse of
    /// [`Self::clientbound_id`]. `None` when that client has no such packet, so it must not be sent.
    pub fn clientbound_id_down(self, state: State, id: i32) -> Option<i32> {
        self.inverse(state, Direction::Clientbound, id)
    }

    /// The pinned version's id for a packet a client of this version sent as `id`: the inverse of
    /// [`Self::serverbound_id`]. `None` when the pinned version has no such packet.
    pub fn serverbound_id_up(self, state: State, id: i32) -> Option<i32> {
        self.inverse(state, Direction::Serverbound, id)
    }

    fn inverse(self, state: State, direction: Direction, id: i32) -> Option<i32> {
        if self == Self::Current {
            return Some(id);
        }
        let at = self
            .table(state, direction)
            .iter()
            .position(|&m| m.map(i32::from) == Some(id))?;
        i32::try_from(at).ok()
    }

    fn map(self, state: State, direction: Direction, id: i32) -> Option<i32> {
        if self == Self::Current {
            return Some(id);
        }
        let mapped = *self
            .table(state, direction)
            .get(usize::try_from(id).ok()?)?;
        mapped.map(i32::from)
    }

    fn table(self, state: State, direction: Direction) -> &'static [Option<u8>] {
        match (self, direction) {
            (Self::Current, _) => &[],
            (Self::V26_2, Direction::Clientbound) => v26_2::clientbound(state),
            (Self::V26_2, Direction::Serverbound) => v26_2::serverbound(state),
            (Self::V26_1, Direction::Clientbound) => v26_1_2::clientbound(state),
            (Self::V26_1, Direction::Serverbound) => v26_1_2::serverbound(state),
            (Self::V1_21_11, Direction::Clientbound) => v1_21_11::clientbound(state),
            (Self::V1_21_11, Direction::Serverbound) => v1_21_11::serverbound(state),
            (Self::V1_21_10, Direction::Clientbound) => v1_21_10::clientbound(state),
            (Self::V1_21_10, Direction::Serverbound) => v1_21_10::serverbound(state),
            (Self::V1_21_8, Direction::Clientbound) => v1_21_8::clientbound(state),
            (Self::V1_21_8, Direction::Serverbound) => v1_21_8::serverbound(state),
            (Self::V1_21_6, Direction::Clientbound) => v1_21_6::clientbound(state),
            (Self::V1_21_6, Direction::Serverbound) => v1_21_6::serverbound(state),
            (Self::V1_21_5, Direction::Clientbound) => v1_21_5::clientbound(state),
            (Self::V1_21_5, Direction::Serverbound) => v1_21_5::serverbound(state),
            (Self::V1_21_4, Direction::Clientbound) => v1_21_4::clientbound(state),
            (Self::V1_21_4, Direction::Serverbound) => v1_21_4::serverbound(state),
            (Self::V1_21_3, Direction::Clientbound) => v1_21_3::clientbound(state),
            (Self::V1_21_3, Direction::Serverbound) => v1_21_3::serverbound(state),
            (Self::V1_21_1, Direction::Clientbound) => v1_21_1::clientbound(state),
            (Self::V1_21_1, Direction::Serverbound) => v1_21_1::serverbound(state),
            (Self::V1_20_6, Direction::Clientbound) => v1_20_6::clientbound(state),
            (Self::V1_20_6, Direction::Serverbound) => v1_20_6::serverbound(state),
            (Self::V1_20_3, Direction::Clientbound) => v1_20_3::clientbound(state),
            (Self::V1_20_3, Direction::Serverbound) => v1_20_3::serverbound(state),
            (Self::V1_20_2, Direction::Clientbound) => v1_20_2::clientbound(state),
            (Self::V1_20_2, Direction::Serverbound) => v1_20_2::serverbound(state),
        }
    }

    /// A packet body (VarInt id + payload) Horizon sends, renumbered for this version's server. `None`
    /// when that server has no such packet.
    pub fn serverbound_body(self, state: State, body: &[u8]) -> Result<Option<Vec<u8>>> {
        let mut r = Reader::new(body);
        let id = r.varint()?;
        let payload = r.rest();
        let Some(mapped) = self.serverbound_id(state, id) else {
            return Ok(None);
        };
        if mapped == id {
            return Ok(Some(body.to_vec()));
        }
        let mut out = Vec::with_capacity(body.len() + 1);
        write_varint(&mut out, mapped);
        out.extend_from_slice(payload);
        Ok(Some(out))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::ids;

    // Expected ids below are read off the 26.2 and 26.3 packets reports by hand
    // (`version_port.py diff 26.2 26.3`), not from the generated tables.

    #[test]
    fn a_26_2_server_is_known_by_its_protocol() {
        assert_eq!(
            ServerVersion::from_protocol(776),
            Some(ServerVersion::V26_2)
        );
        assert_eq!(
            ServerVersion::from_protocol(crate::PROTOCOL_VERSION),
            Some(ServerVersion::Current)
        );
        assert_eq!(
            ServerVersion::from_protocol(775),
            Some(ServerVersion::V26_1)
        );
        assert_eq!(
            ServerVersion::from_protocol(774),
            Some(ServerVersion::V1_21_11)
        );
        assert_eq!(
            ServerVersion::from_protocol(773),
            Some(ServerVersion::V1_21_10)
        );
        assert_eq!(
            ServerVersion::from_protocol(772),
            Some(ServerVersion::V1_21_8)
        );
        assert_eq!(
            ServerVersion::from_protocol(771),
            Some(ServerVersion::V1_21_6)
        );
        assert_eq!(
            ServerVersion::from_protocol(770),
            Some(ServerVersion::V1_21_5)
        );
        assert_eq!(
            ServerVersion::from_protocol(769),
            Some(ServerVersion::V1_21_4)
        );
        assert_eq!(
            ServerVersion::from_protocol(768),
            Some(ServerVersion::V1_21_3)
        );
        assert_eq!(
            ServerVersion::from_protocol(767),
            Some(ServerVersion::V1_21_1)
        );
        assert_eq!(
            ServerVersion::from_protocol(766),
            Some(ServerVersion::V1_20_6)
        );
        assert_eq!(
            ServerVersion::from_protocol(765),
            Some(ServerVersion::V1_20_3)
        );
        assert_eq!(
            ServerVersion::from_protocol(764),
            Some(ServerVersion::V1_20_2)
        );
        assert_eq!(ServerVersion::from_protocol(763), None);
        assert!(ServerVersion::V26_1.at_most(ServerVersion::V26_2));
        assert!(!ServerVersion::V26_2.at_most(ServerVersion::V26_1));
    }

    #[test]
    fn renumbered_clientbound_play_packets_reach_their_26_3_ids() {
        let v = ServerVersion::V26_2;
        // keep_alive 44 -> 45, login 49 -> 50, respawn 82 -> 84, clear_dialog 139 -> 142.
        assert_eq!(
            v.clientbound_id(State::Play, 44),
            Some(ids::play::clientbound::KEEP_ALIVE)
        );
        assert_eq!(
            v.clientbound_id(State::Play, 49),
            Some(ids::play::clientbound::LOGIN)
        );
        assert_eq!(
            v.clientbound_id(State::Play, 82),
            Some(ids::play::clientbound::RESPAWN)
        );
        assert_eq!(
            v.clientbound_id(State::Play, 139),
            Some(ids::play::clientbound::CLEAR_DIALOG)
        );
        // Unchanged before the first insertion (add_transient_block at 37).
        assert_eq!(v.clientbound_id(State::Play, 0), Some(0));
        // Past 26.2's 141 packets.
        assert_eq!(v.clientbound_id(State::Play, 141), None);
        // Configuration: store_cookie 10 -> 11 (post_effects took 10).
        assert_eq!(
            v.clientbound_id(State::Configuration, 10),
            Some(ids::configuration::clientbound::STORE_COOKIE)
        );
    }

    #[test]
    fn serverbound_packets_26_2_lacks_are_not_sent() {
        let v = ServerVersion::V26_2;
        // punch is new in 26.3; swing, which 26.2 has at 63, is gone.
        assert_eq!(
            v.serverbound_id(State::Play, ids::play::serverbound::PUNCH),
            None
        );
        // resource_pack 50 -> 49, spectator_action 63 -> 62, keep_alive unchanged.
        assert_eq!(
            v.serverbound_id(State::Play, ids::play::serverbound::RESOURCE_PACK),
            Some(49)
        );
        assert_eq!(
            v.serverbound_id(State::Play, ids::play::serverbound::SPECTATOR_ACTION),
            Some(62)
        );
        assert_eq!(
            v.serverbound_id(State::Play, ids::play::serverbound::KEEP_ALIVE),
            Some(ids::play::serverbound::KEEP_ALIVE)
        );
        assert_eq!(
            v.serverbound_id(State::Handshake, ids::handshake::serverbound::INTENTION),
            Some(0)
        );
    }

    #[test]
    fn serverbound_bodies_keep_their_payload_under_the_new_id() {
        let v = ServerVersion::V26_2;
        let mut body = Vec::new();
        write_varint(&mut body, ids::play::serverbound::RESOURCE_PACK);
        body.extend_from_slice(&[1, 2, 3]);
        assert_eq!(
            v.serverbound_body(State::Play, &body).unwrap(),
            Some(vec![49, 1, 2, 3])
        );
        let mut punch = Vec::new();
        write_varint(&mut punch, ids::play::serverbound::PUNCH);
        assert_eq!(v.serverbound_body(State::Play, &punch).unwrap(), None);
        assert_eq!(
            ServerVersion::Current
                .serverbound_body(State::Play, &body)
                .unwrap(),
            Some(body)
        );
    }
}
