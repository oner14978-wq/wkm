//! `SpawnPlacements`: each entity type's placement type
//! (`SpawnPlacementTypes.isSpawnPositionOk`) and spawn predicate
//! (`checkSpawnRules`), read through [`SpawnLevel`] so the game's world and a
//! differential test world answer the same questions. Random draws follow
//! vanilla's order.
use super::{Species, data};
use crate::blocks::{BlockFacts, Fluid};
use horizon_core::random::{RandomSource, slime_chunk_random};
use horizon_world::{dimension_type::DimensionFacts, registry::BlockStateId};

/// `EntitySpawnReason`: the mod API's own enum.
pub use mod_api::SpawnReason as Reason;
/// `EntitySpawnReason.isSpawner`.
pub fn is_spawner(reason: Reason) -> bool {
    matches!(reason, Reason::Spawner | Reason::TrialSpawner)
}
/// `EntitySpawnReason.ignoresLightRequirements`.
pub fn ignores_light(reason: Reason) -> bool {
    reason == Reason::TrialSpawner
}
/// What spawn checks read from a level.
pub trait SpawnLevel {
    /// `WorldBorder.isWithinBounds(BlockPos)`. Unbounded test levels allow all positions.
    fn within_world_border(&self, _x: i32, _z: i32) -> bool {
        true
    }

    fn state(&self, x: i32, y: i32, z: i32) -> BlockStateId;
    fn facts(&self) -> &BlockFacts;
    fn mob_data(&self) -> &data::MobData;
    fn block_tag(&self, tag: &str, block: &str) -> bool;
    fn biome_tag(&self, tag: &str, x: i32, y: i32, z: i32) -> bool;
    /// `getBrightness(LightLayer.SKY / BLOCK)`.
    fn sky_light(&self, x: i32, y: i32, z: i32) -> i32;
    fn block_light(&self, x: i32, y: i32, z: i32) -> i32;
    fn sky_darken(&self) -> i32;
    fn thundering(&self) -> bool;
    fn sea_level(&self) -> i32;
    /// `getHeight(WORLD_SURFACE, x, z)`: above the highest non-air block.
    fn world_surface(&self, x: i32, z: i32) -> i32;
    fn peaceful(&self) -> bool;
    fn dimension_type(&self) -> &DimensionFacts;
    /// The `gameplay/surface_slime_spawn_chance` environment attribute.
    fn surface_slime_chance(&self, x: i32, y: i32, z: i32) -> f32;
    fn world_seed(&self) -> i64;
    /// `getNearestPlayer(x, y, z, distance, true) != null`: a survival or
    /// adventure player that close.
    fn player_near(&self, x: f64, y: f64, z: f64, distance: f64) -> bool;
    /// `MobSpawnEvent.SpawnPlacementCheck`: what the check answers once
    /// `vanilla`, the type's own predicate, has run. Only the game's level
    /// tells mods.
    fn placement_check(
        &self,
        _entity: &str,
        _reason: Reason,
        _at: [i32; 3],
        vanilla: bool,
    ) -> bool {
        vanilla
    }
}

fn name<L: SpawnLevel>(l: &L, x: i32, y: i32, z: i32) -> &str {
    &l.facts().get(l.state(x, y, z)).name
}
fn fluid<L: SpawnLevel>(l: &L, x: i32, y: i32, z: i32) -> Fluid {
    l.facts().get(l.state(x, y, z)).fluid
}
fn flags<L: SpawnLevel>(l: &L, x: i32, y: i32, z: i32) -> u16 {
    l.mob_data().state(l.state(x, y, z)).flags
}
fn tag<L: SpawnLevel>(l: &L, tag: &str, x: i32, y: i32, z: i32) -> bool {
    l.block_tag(tag, name(l, x, y, z))
}
/// `getRawBrightness(pos, darkening)`.
fn raw_brightness<L: SpawnLevel>(l: &L, x: i32, y: i32, z: i32, darkening: i32) -> i32 {
    l.block_light(x, y, z).max(l.sky_light(x, y, z) - darkening)
}
fn can_see_sky<L: SpawnLevel>(l: &L, x: i32, y: i32, z: i32) -> bool {
    l.sky_light(x, y, z) >= 15
}
/// `LevelReader.canSeeSkyFromBelowWater`.
fn can_see_sky_from_below_water<L: SpawnLevel>(l: &L, x: i32, y: i32, z: i32) -> bool {
    let sea = l.sea_level();
    if y >= sea {
        return can_see_sky(l, x, y, z);
    }
    if !can_see_sky(l, x, sea, z) {
        return false;
    }
    ((y + 1)..sea).all(|yy| {
        let f = l.facts().get(l.state(x, yy, z));
        // `BlockState.liquid()` is water, lava and the bubble column. Kelp,
        // seagrass and waterlogged blocks hold water and still stop the scan.
        f.dampening == 0 || liquid_block(&f.name)
    })
}
/// `BlockState.liquid()`: the three blocks whose property is set.
fn liquid_block(name: &str) -> bool {
    matches!(
        name,
        "minecraft:water" | "minecraft:lava" | "minecraft:bubble_column"
    )
}

/// `EntityType.fireImmune`.
pub fn fire_immune(s: Species) -> bool {
    use Species as S;
    matches!(
        s,
        S::Blaze
            | S::Ghast
            | S::MagmaCube
            | S::Shulker
            | S::Strider
            | S::Vex
            | S::Warden
            | S::Wither
            | S::WitherSkeleton
            | S::Zoglin
            | S::ZombifiedPiglin
    )
}
/// `EntityType.isAllowedInPeaceful`.
pub fn allowed_in_peaceful(s: Species) -> bool {
    use Species as S;
    !matches!(
        s,
        S::Blaze
            | S::Bogged
            | S::Breeze
            | S::CaveSpider
            | S::Creaking
            | S::Creeper
            | S::Drowned
            | S::ElderGuardian
            | S::Enderman
            | S::Endermite
            | S::Evoker
            | S::Ghast
            | S::Giant
            | S::Guardian
            | S::Hoglin
            | S::Husk
            | S::Illusioner
            | S::MagmaCube
            | S::Parched
            | S::Phantom
            | S::PiglinBrute
            | S::Pillager
            | S::Ravager
            | S::Silverfish
            | S::Skeleton
            | S::Slime
            | S::Spider
            | S::Stray
            | S::Vex
            | S::Vindicator
            | S::Warden
            | S::Witch
            | S::Wither
            | S::WitherSkeleton
            | S::Zoglin
            | S::Zombie
            | S::ZombieVillager
            | S::ZombifiedPiglin
    )
}
/// The block tag an entity type is `immuneTo`.
fn immune_tag(s: Species) -> Option<&'static str> {
    use Species as S;
    match s {
        S::Fox => Some("minecraft:fox_immune_to"),
        S::PolarBear => Some("minecraft:polar_bear_immune_to"),
        S::SnowGolem => Some("minecraft:snow_golem_immune_to"),
        S::Stray => Some("minecraft:stray_immune_to"),
        S::Wither => Some("minecraft:wither_immune_to"),
        S::WitherSkeleton => Some("minecraft:wither_skeleton_immune_to"),
        _ => None,
    }
}
/// `BlockState.isValidSpawn(level, pos, type)` for the block at a position.
pub fn is_valid_spawn<L: SpawnLevel>(s: Species, l: &L, x: i32, y: i32, z: i32) -> bool {
    if name(l, x, y, z) == "minecraft:magma_block" {
        return fire_immune(s);
    }
    let bit = match s {
        Species::Ocelot | Species::Parrot => data::VALID_SPAWN_LEAVES,
        Species::PolarBear => data::VALID_SPAWN_ICE,
        _ => data::VALID_SPAWN,
    };
    flags(l, x, y, z) & bit != 0
}
/// `NaturalSpawner.isValidEmptySpawnBlock` for an entity type.
pub fn is_valid_empty_spawn<L: SpawnLevel>(s: Species, l: &L, x: i32, y: i32, z: i32) -> bool {
    // The exported flag is the zombie's answer; only blocks a zombie finds
    // dangerous can answer differently for another type.
    if flags(l, x, y, z) & data::VALID_EMPTY_SPAWN != 0 {
        return true;
    }
    let f = l.facts().get(l.state(x, y, z));
    let block = &*f.name;
    let burning = l.block_tag("minecraft:fire", block)
        || block == "minecraft:lava"
        || block == "minecraft:magma_block"
        || (block == "minecraft:campfire" || block == "minecraft:soul_campfire") && f.emission > 0
        || block == "minecraft:lava_cauldron";
    let other = matches!(
        block,
        "minecraft:wither_rose"
            | "minecraft:sweet_berry_bush"
            | "minecraft:cactus"
            | "minecraft:powder_snow"
    );
    if !burning && !other {
        return false;
    }
    let immune = immune_tag(s).is_some_and(|t| l.block_tag(t, block));
    let dangerous = !immune && (burning && !fire_immune(s) || other);
    !dangerous
        && !f.full_collision
        && f.fluid == Fluid::None
        && !l.block_tag("minecraft:prevent_mob_spawning_inside", block)
}
/// `SpawnPlacements.isSpawnPositionOk` for the entity type `entity`, of species `s`.
pub fn is_spawn_position_ok<L: SpawnLevel>(
    entity: &str,
    s: Species,
    l: &L,
    x: i32,
    y: i32,
    z: i32,
) -> bool {
    let placement = l.mob_data().entity_placement(entity, s);
    if placement != data::Placement::NoRestrictions && !l.within_world_border(x, z) {
        return false;
    }
    match placement {
        data::Placement::OnGround => {
            is_valid_spawn(s, l, x, y - 1, z)
                && is_valid_empty_spawn(s, l, x, y, z)
                && is_valid_empty_spawn(s, l, x, y + 1, z)
        }
        data::Placement::InWater => {
            fluid(l, x, y, z) == Fluid::Water
                && flags(l, x, y + 1, z) & data::REDSTONE_CONDUCTOR == 0
        }
        data::Placement::InLava => fluid(l, x, y, z) == Fluid::Lava,
        data::Placement::NoRestrictions => true,
    }
}
/// `Monster.isDarkEnoughToSpawn`.
pub fn is_dark_enough<L: SpawnLevel>(
    l: &L,
    random: &mut impl RandomSource,
    x: i32,
    y: i32,
    z: i32,
) -> bool {
    if l.sky_light(x, y, z) > random.next_int_bound(32).unwrap_or(0) {
        return false;
    }
    let dim = l.dimension_type();
    let limit = dim.monster_spawn_block_light_limit;
    if limit < 15 && l.block_light(x, y, z) > limit {
        return false;
    }
    let darken = if l.thundering() { 10 } else { l.sky_darken() };
    let brightness = raw_brightness(l, x, y, z, darken);
    brightness <= dim.monster_spawn_light_level.sample(random).unwrap_or(0)
}
/// `Animal.isBrightEnoughToSpawn`.
fn bright<L: SpawnLevel>(l: &L, x: i32, y: i32, z: i32) -> bool {
    raw_brightness(l, x, y, z, 0) > 8
}
/// `Mob.checkMobSpawnRules`.
fn mob_rules<L: SpawnLevel>(s: Species, l: &L, reason: Reason, x: i32, y: i32, z: i32) -> bool {
    is_spawner(reason) || is_valid_spawn(s, l, x, y - 1, z)
}
/// `Monster.checkMonsterSpawnRules`.
fn monster_rules<L: SpawnLevel>(
    s: Species,
    l: &L,
    reason: Reason,
    random: &mut impl RandomSource,
    x: i32,
    y: i32,
    z: i32,
) -> bool {
    (ignores_light(reason) || is_dark_enough(l, random, x, y, z))
        && mob_rules(s, l, reason, x, y, z)
}
/// `Animal.checkAnimalSpawnRules` with the given spawnable-on tag.
fn animal_rules<L: SpawnLevel>(l: &L, reason: Reason, on: &str, x: i32, y: i32, z: i32) -> bool {
    let bright = ignores_light(reason) || bright(l, x, y, z);
    tag(l, on, x, y - 1, z) && bright
}
/// `WaterAnimal.checkSurfaceWaterAnimalSpawnRules`.
fn surface_water<L: SpawnLevel>(l: &L, x: i32, y: i32, z: i32) -> bool {
    let sea = l.sea_level();
    y >= sea - 13
        && y <= sea
        && fluid(l, x, y - 1, z) == Fluid::Water
        && name(l, x, y + 1, z) == "minecraft:water"
}

/// `SpawnPlacements.checkSpawnRules` for the entity type `entity` (a species
/// can stand for several types), then `MobSpawnEvent.SpawnPlacementCheck`
/// through [`SpawnLevel::placement_check`].
pub fn check_spawn_rules<L: SpawnLevel>(
    entity: &str,
    s: Species,
    l: &L,
    reason: Reason,
    random: &mut impl RandomSource,
    at: [i32; 3],
) -> bool {
    if !allowed_in_peaceful(s) && l.peaceful() {
        return false;
    }
    let [x, y, z] = at;
    let vanilla = match l.mob_data().mod_spawns.get(entity) {
        Some(rule) => mod_predicate(rule, l, reason, random, x, y, z),
        None => placement_predicate(s, l, reason, random, x, y, z),
    };
    l.placement_check(entity, reason, at, vanilla)
}
/// A mod type's spawn predicate (`SpawnPlacements.Data.predicate`): the ground
/// tag, the biome tag, then the light, which draws last as vanilla's do.
fn mod_predicate<L: SpawnLevel>(
    rule: &mod_api::SpawnPlacementRule,
    l: &L,
    reason: Reason,
    random: &mut impl RandomSource,
    x: i32,
    y: i32,
    z: i32,
) -> bool {
    use mod_api::SpawnLight as Light;
    rule.spawnable_on
        .as_deref()
        .is_none_or(|on| tag(l, on, x, y - 1, z))
        && rule
            .biome_tag
            .as_deref()
            .is_none_or(|biome| l.biome_tag(biome, x, y, z))
        && match rule.light {
            Light::Dark => ignores_light(reason) || is_dark_enough(l, random, x, y, z),
            Light::Bright => ignores_light(reason) || bright(l, x, y, z),
            _ => true,
        }
}
/// The type's spawn predicate (`SpawnPlacements.Data.predicate`).
fn placement_predicate<L: SpawnLevel>(
    s: Species,
    l: &L,
    reason: Reason,
    random: &mut impl RandomSource,
    x: i32,
    y: i32,
    z: i32,
) -> bool {
    use Species as S;
    let below = |l: &L| name(l, x, y - 1, z).to_owned();
    match s {
        S::Axolotl => tag(l, "minecraft:axolotls_spawnable_on", x, y - 1, z),
        S::Cod | S::Pufferfish | S::Salmon | S::Dolphin | S::Squid => surface_water(l, x, y, z),
        S::Drowned => {
            if fluid(l, x, y - 1, z) != Fluid::Water && !is_spawner(reason) {
                return false;
            }
            let frequent = l.biome_tag("minecraft:more_frequent_drowned_spawns", x, y, z);
            let can_spawn = !l.peaceful()
                && (ignores_light(reason) || is_dark_enough(l, random, x, y, z))
                && (is_spawner(reason) || fluid(l, x, y, z) == Fluid::Water);
            if !can_spawn || !is_spawner(reason) && reason != Reason::Reinforcement {
                if frequent {
                    random.next_int_bound(15).unwrap_or(1) == 0 && can_spawn
                } else {
                    random.next_int_bound(40).unwrap_or(1) == 0
                        && y < l.sea_level() - 5
                        && can_spawn
                }
            } else {
                true
            }
        }
        S::Guardian | S::ElderGuardian => {
            (random.next_int_bound(20).unwrap_or(1) == 0
                || !can_see_sky_from_below_water(l, x, y, z))
                && !l.peaceful()
                && (is_spawner(reason) || fluid(l, x, y, z) == Fluid::Water)
                && fluid(l, x, y - 1, z) == Fluid::Water
        }
        S::TropicalFish => {
            fluid(l, x, y - 1, z) == Fluid::Water
                && name(l, x, y + 1, z) == "minecraft:water"
                && (l.biome_tag(
                    "minecraft:allows_tropical_fish_spawns_at_any_height",
                    x,
                    y,
                    z,
                ) || surface_water(l, x, y, z))
        }
        S::Armadillo => {
            tag(l, "minecraft:armadillo_spawnable_on", x, y - 1, z) && bright(l, x, y, z)
        }
        S::Bat => {
            if y >= l.world_surface(x, z) || random.next_boolean() {
                return false;
            }
            if raw_brightness(l, x, y, z, l.sky_darken()) > random.next_int_bound(4).unwrap_or(0) {
                return false;
            }
            tag(l, "minecraft:bats_spawnable_on", x, y - 1, z) && mob_rules(s, l, reason, x, y, z)
        }
        S::Blaze | S::Breeze | S::Zoglin => mob_rules(s, l, reason, x, y, z),
        S::Camel => tag(l, "minecraft:camels_spawnable_on", x, y - 1, z) && bright(l, x, y, z),
        S::CamelHusk | S::Husk | S::Parched => {
            monster_rules(s, l, reason, random, x, y, z)
                && (is_spawner(reason) || can_see_sky(l, x, y, z))
        }
        S::Chicken
        | S::Cow
        | S::Donkey
        | S::HappyGhast
        | S::Horse
        | S::Llama
        | S::Mule
        | S::Pig
        | S::Sheep
        | S::Cat
        | S::Panda
        | S::TraderLlama => animal_rules(l, reason, "minecraft:animals_spawnable_on", x, y, z),
        S::Endermite | S::Silverfish => {
            if !mob_rules(s, l, reason, x, y, z) {
                return false;
            }
            is_spawner(reason)
                || !l.player_near(
                    f64::from(x) + 0.5,
                    f64::from(y) + 0.5,
                    f64::from(z) + 0.5,
                    5.0,
                )
        }
        S::IronGolem
        | S::SnowGolem
        | S::Villager
        | S::Phantom
        | S::Shulker
        | S::WanderingTrader => mob_rules(s, l, reason, x, y, z),
        S::Frog => tag(l, "minecraft:frogs_spawnable_on", x, y - 1, z) && bright(l, x, y, z),
        S::Ghast => {
            !l.peaceful()
                && random.next_int_bound(20).unwrap_or(1) == 0
                && mob_rules(s, l, reason, x, y, z)
        }
        S::GlowSquid => {
            y <= l.sea_level() - 33
                && raw_brightness(l, x, y, z, 0) == 0
                && name(l, x, y, z) == "minecraft:water"
        }
        S::Goat => tag(l, "minecraft:goats_spawnable_on", x, y - 1, z) && bright(l, x, y, z),
        S::MagmaCube => !l.peaceful(),
        S::SulfurCube => true,
        S::Mooshroom => {
            tag(l, "minecraft:mooshrooms_spawnable_on", x, y - 1, z) && bright(l, x, y, z)
        }
        S::Nautilus => {
            let sea = l.sea_level();
            y >= sea - 25
                && y <= sea - 5
                && fluid(l, x, y - 1, z) == Fluid::Water
                && name(l, x, y + 1, z) == "minecraft:water"
        }
        S::Ocelot => random.next_int_bound(3).unwrap_or(0) != 0,
        S::Parrot => tag(l, "minecraft:parrots_spawnable_on", x, y - 1, z) && bright(l, x, y, z),
        S::Hoglin | S::Piglin => below(l) != "minecraft:nether_wart_block",
        S::Pillager => l.block_light(x, y, z) <= 8 && mob_rules(s, l, reason, x, y, z),
        S::PolarBear => {
            if l.biome_tag("minecraft:polar_bears_spawn_on_alternate_blocks", x, y, z) {
                bright(l, x, y, z)
                    && tag(
                        l,
                        "minecraft:polar_bears_spawnable_on_alternate",
                        x,
                        y - 1,
                        z,
                    )
            } else {
                animal_rules(l, reason, "minecraft:animals_spawnable_on", x, y, z)
            }
        }
        S::Rabbit => tag(l, "minecraft:rabbits_spawnable_on", x, y - 1, z) && bright(l, x, y, z),
        S::SkeletonHorse => {
            if is_spawner(reason) {
                ignores_light(reason) || bright(l, x, y, z)
            } else {
                animal_rules(l, reason, "minecraft:animals_spawnable_on", x, y, z)
            }
        }
        S::Slime => slime_rules(s, l, reason, random, x, y, z),
        S::Stray => {
            let mut sky = y + 1;
            while name(l, x, sky, z) == "minecraft:powder_snow" {
                sky += 1;
            }
            monster_rules(s, l, reason, random, x, y, z)
                && (is_spawner(reason) || can_see_sky(l, x, sky - 1, z))
        }
        S::Strider => {
            let mut up = y + 1;
            while fluid(l, x, up, z) == Fluid::Lava {
                up += 1;
            }
            l.facts().is_air(l.state(x, up, z))
        }
        S::Turtle => {
            y < l.sea_level() + 4 && tag(l, "minecraft:sand", x, y - 1, z) && bright(l, x, y, z)
        }
        S::Wolf => tag(l, "minecraft:wolves_spawnable_on", x, y - 1, z) && bright(l, x, y, z),
        S::ZombifiedPiglin => !l.peaceful() && below(l) != "minecraft:nether_wart_block",
        S::Fox => tag(l, "minecraft:foxes_spawnable_on", x, y - 1, z) && bright(l, x, y, z),
        S::Bogged
        | S::CaveSpider
        | S::Creeper
        | S::Enderman
        | S::Giant
        | S::Skeleton
        | S::Spider
        | S::Witch
        | S::Wither
        | S::WitherSkeleton
        | S::Creaking
        | S::Zombie
        | S::ZombieHorse
        | S::ZombieVillager
        | S::Evoker
        | S::Illusioner
        | S::Ravager
        | S::Vex
        | S::Vindicator
        | S::Warden => monster_rules(s, l, reason, random, x, y, z),
        // Types without a SpawnPlacements registration.
        _ => true,
    }
}
/// `Slime.checkSlimeSpawnRules`.
fn slime_rules<L: SpawnLevel>(
    s: Species,
    l: &L,
    reason: Reason,
    random: &mut impl RandomSource,
    x: i32,
    y: i32,
    z: i32,
) -> bool {
    if l.peaceful() {
        return false;
    }
    if is_spawner(reason) {
        return mob_rules(s, l, reason, x, y, z);
    }
    if l.biome_tag("minecraft:allows_surface_slime_spawns", x, y, z) && y > 50 && y < 70 {
        let chance = l.surface_slime_chance(x, y, z);
        if random.next_float() < chance
            && raw_brightness(l, x, y, z, l.sky_darken()) <= random.next_int_bound(8).unwrap_or(0)
        {
            return mob_rules(s, l, reason, x, y, z);
        }
    }
    let slime_chunk = slime_chunk_random(x >> 4, z >> 4, l.world_seed(), 987_234_911)
        .next_int_bound(10)
        .unwrap_or(1)
        == 0;
    if random.next_int_bound(10).unwrap_or(1) == 0 && slime_chunk && y < 40 {
        return mob_rules(s, l, reason, x, y, z);
    }
    false
}

impl SpawnLevel for super::MobWorld<'_> {
    fn within_world_border(&self, x: i32, z: i32) -> bool {
        self.border
            .is_none_or(|border| border.is_within_bounds(f64::from(x), f64::from(z), 0.0))
    }
    fn state(&self, x: i32, y: i32, z: i32) -> BlockStateId {
        self.world.block(x, y, z)
    }
    fn facts(&self) -> &BlockFacts {
        self.facts
    }
    fn mob_data(&self) -> &data::MobData {
        self.data
    }
    fn block_tag(&self, tag: &str, block: &str) -> bool {
        self.has_tag(tag, block)
    }
    fn biome_tag(&self, tag: &str, x: i32, y: i32, z: i32) -> bool {
        let Some(chunk) = self.world.chunks.get(&(x >> 4, z >> 4)) else {
            return false;
        };
        let biome = &self.biomes.get(chunk.biome(x, y, z)).name;
        self.data
            .biome_tags
            .get(tag.trim_start_matches('#'))
            .is_some_and(|members| members.contains(biome))
    }
    fn sky_light(&self, x: i32, y: i32, z: i32) -> i32 {
        // Kept as before: vanilla's End has sky light, but Horizon reads 0 there.
        if matches!(
            self.dimension_type.id.as_str(),
            "minecraft:the_nether" | "minecraft:the_end"
        ) {
            return 0;
        }
        i32::from(self.world.light(x, y, z) >> 4)
    }
    fn block_light(&self, x: i32, y: i32, z: i32) -> i32 {
        i32::from(self.world.light(x, y, z) & 15)
    }
    fn sky_darken(&self) -> i32 {
        super::MobWorld::sky_darken(self)
    }
    fn thundering(&self) -> bool {
        self.thundering
    }
    fn sea_level(&self) -> i32 {
        self.sea_level
    }
    fn world_surface(&self, x: i32, z: i32) -> i32 {
        self.world.world_surface(x, z, |id| self.facts.is_air(id))
    }
    fn peaceful(&self) -> bool {
        self.difficulty.effective == 0.0
    }
    fn dimension_type(&self) -> &DimensionFacts {
        self.dimension_type
    }
    fn surface_slime_chance(&self, _: i32, _: i32, _: i32) -> f32 {
        let phase = self.day_time.div_euclid(24000).rem_euclid(8) as usize;
        0.5 * super::spawning::MOON_BRIGHTNESS[phase]
    }
    fn world_seed(&self) -> i64 {
        self.world_seed
    }
    fn player_near(&self, x: f64, y: f64, z: f64, distance: f64) -> bool {
        self.selected_player().is_some_and(|p| {
            let d = (p.position.x - x).powi(2)
                + (p.position.y - y).powi(2)
                + (p.position.z - z).powi(2);
            p.alive && !p.creative && !p.spectator && d < distance * distance
        })
    }
}

/// One block state everywhere: what the spawn checks of a single block read of a level.
struct OneState<'a> {
    state: BlockStateId,
    facts: &'a BlockFacts,
    data: &'a data::MobData,
    block_tags: &'a std::collections::HashMap<String, std::collections::HashSet<String>>,
}
impl SpawnLevel for OneState<'_> {
    fn state(&self, _: i32, _: i32, _: i32) -> BlockStateId {
        self.state
    }
    fn facts(&self) -> &BlockFacts {
        self.facts
    }
    fn mob_data(&self) -> &data::MobData {
        self.data
    }
    fn block_tag(&self, tag: &str, block: &str) -> bool {
        self.block_tags.get(tag).is_some_and(|s| s.contains(block))
    }
    fn biome_tag(&self, _: &str, _: i32, _: i32, _: i32) -> bool {
        false
    }
    fn sky_light(&self, _: i32, _: i32, _: i32) -> i32 {
        0
    }
    fn block_light(&self, _: i32, _: i32, _: i32) -> i32 {
        0
    }
    fn sky_darken(&self) -> i32 {
        0
    }
    fn thundering(&self) -> bool {
        false
    }
    fn sea_level(&self) -> i32 {
        63
    }
    fn world_surface(&self, _: i32, _: i32) -> i32 {
        0
    }
    fn peaceful(&self) -> bool {
        false
    }
    fn dimension_type(&self) -> &DimensionFacts {
        DimensionFacts::vanilla("minecraft:overworld").unwrap()
    }
    fn surface_slime_chance(&self, _: i32, _: i32, _: i32) -> f32 {
        0.0
    }
    fn world_seed(&self) -> i64 {
        0
    }
    fn player_near(&self, _: f64, _: f64, _: f64, _: f64) -> bool {
        false
    }
}

/// [`spot_table`]'s bits: a mob may spawn on the state (`isValidSpawn`), in it
/// (`isValidEmptySpawnBlock`), and its collision shape meets the spawn box standing in its cell,
/// on top of it, or below it.
pub const SPOT_FLOOR: u8 = 1;
pub const SPOT_ROOM: u8 = 2;
pub const SPOT_FEET: u8 = 4;
pub const SPOT_BELOW: u8 = 8;
pub const SPOT_HEAD: u8 = 16;

/// Each block state's [`SPOT_FLOOR`]... bits for `s` (`width` by `height`) spawning on the
/// ground, so that a place is `SpawnPlacements.isSpawnPositionOk` (`ON_GROUND`) with nothing in
/// `getSpawnAABB` (`noCollision`, an empty collision context) when the block below has
/// `SPOT_FLOOR` and not `SPOT_BELOW`, the block there `SPOT_ROOM` and not `SPOT_FEET`, the one
/// above `SPOT_ROOM` and not `SPOT_HEAD`. A shape the world changes (bamboo's and dripstone's
/// offsets, a shulker box's lid, a moving piston) counts as meeting the box.
pub fn spot_table(
    s: Species,
    width: f32,
    height: f32,
    facts: &BlockFacts,
    data: &data::MobData,
    collision: &horizon_world::block_collision::BlockCollisionRegistry<'_>,
    block_tags: &std::collections::HashMap<String, std::collections::HashSet<String>>,
) -> Vec<u8> {
    use horizon_core::geometry::{ShapeOp, VoxelShape};
    let at = |y: f64| {
        let b = super::spawn_selection::spawn_aabb(s, 0.5, y, 0.5, width, height);
        VoxelShape::from_box(b).ok()
    };
    // The spawn box from the cell's own floor, from the top of it and from the floor below.
    let boxes = [
        (SPOT_FEET, at(0.0)),
        (SPOT_BELOW, at(1.0)),
        (SPOT_HEAD, at(-1.0)),
    ];
    (0..collision.registry().len())
        .map(|i| {
            let state = BlockStateId(i as u32);
            let one = OneState {
                state,
                facts,
                data,
                block_tags,
            };
            let mut bits = 0;
            if is_valid_spawn(s, &one, 0, 0, 0) {
                bits |= SPOT_FLOOR;
            }
            if is_valid_empty_spawn(s, &one, 0, 0, 0) {
                bits |= SPOT_ROOM;
            }
            let shape = collision.plain_shape(state);
            // Under an empty context (no entity above them) scaffolding, powder snow and
            // liquids have no collision; the other shapes the world changes count as meeting.
            let name = &*facts.get(state).name;
            let empty = matches!(
                name,
                "minecraft:scaffolding"
                    | "minecraft:powder_snow"
                    | "minecraft:water"
                    | "minecraft:lava"
            );
            for (bit, b) in &boxes {
                let meets = match (shape, b) {
                    (Some(shape), Some(b)) => {
                        shape.join_is_not_empty(b, ShapeOp::AND).unwrap_or(true)
                    }
                    _ => !empty,
                };
                if meets {
                    bits |= bit;
                }
            }
            bits
        })
        .collect()
}

#[cfg(test)]
mod underwater_sky_tests {
    use super::*;
    use crate::mobs::world::with_built_test_world;
    use horizon_core::random::LegacyRandom;
    use horizon_world::{block_state_properties::BlockProperties, chunk::BlockState};

    fn with_props(
        registry: &horizon_world::registry::BlockRegistry,
        name: &str,
        props: &[(&str, &str)],
    ) -> horizon_world::registry::BlockStateId {
        let mut properties = BlockProperties::new();
        for (key, value) in props {
            properties.insert((*key).to_owned(), (*value).to_owned());
        }
        registry
            .resolve(&BlockState {
                name: format!("minecraft:{name}"),
                properties,
            })
            .unwrap()
    }

    /// `Guardian.checkGuardianSpawnRules`: below sea level the 1-in-20 roll is
    /// skipped when `canSeeSkyFromBelowWater` is false. Kelp (dampening 1, not
    /// `liquid()`) makes it false. A bubble column is `liquid()`, so the scan
    /// continues and the roll is still required.
    #[test]
    fn kelp_hides_the_sky_from_a_guardian_and_a_bubble_column_does_not() {
        let ran = with_built_test_world(
            &[],
            |world, registry| {
                world.chunks.insert(
                    (0, 0),
                    std::sync::Arc::new(crate::chunk::Chunk::empty(0, 0)),
                );
                let water = registry.default_state("minecraft:water").unwrap();
                let kelp = with_props(registry, "kelp", &[("age", "0")]);
                let column = with_props(registry, "bubble_column", &[("drag", "true")]);
                for x in [0, 1] {
                    world.set(x, 49, 0, water).unwrap();
                    world.set(x, 50, 0, water).unwrap();
                }
                world.set(0, 55, 0, kelp).unwrap();
                world.set(1, 55, 0, column).unwrap();
            },
            |w, _| {
                // Sea level in this world is 63, so y=55 sits in the scan.
                assert_eq!(w.sea_level(), 63);
                let mut probe = LegacyRandom::new(1);
                assert_ne!(
                    probe.next_int_bound(20).unwrap(),
                    0,
                    "seed 1 must miss the 1-in-20"
                );
                let mut random = LegacyRandom::new(1);
                assert!(
                    check_spawn_rules(
                        "minecraft:guardian",
                        Species::Guardian,
                        w,
                        Reason::Natural,
                        &mut random,
                        [0, 50, 0]
                    ),
                    "kelp between the guardian and the sea hides the sky"
                );
                let mut random = LegacyRandom::new(1);
                assert!(
                    !check_spawn_rules(
                        "minecraft:guardian",
                        Species::Guardian,
                        w,
                        Reason::Natural,
                        &mut random,
                        [1, 50, 0]
                    ),
                    "a bubble column is liquid(), so the sky still shows"
                );
            },
        );
        // Without the vanilla data under .local/horizon-client the world
        // cannot be built: the test has nothing to check.
        let _ = ran;
    }
}

#[cfg(test)]
mod light_draw_tests {
    use super::*;
    use crate::mobs::{MobWorld, world::with_built_test_world};
    use horizon_core::random::LegacyRandom;

    /// `Monster.isDarkEnoughToSpawn`: the sky roll draws one bound-32 int, then the
    /// dimension type's light level draws as its provider does (uniform 0..=7 one
    /// bound-8 int, a constant none).
    #[test]
    fn dark_enough_draws_follow_the_dimension_type_provider() {
        with_built_test_world(
            &[],
            |world, _| {
                world.chunks.insert(
                    (0, 0),
                    std::sync::Arc::new(crate::chunk::Chunk::empty(0, 0)),
                );
            },
            |w, _| {
                for (type_id, draws) in [
                    ("minecraft:overworld", &[32, 8][..]),
                    ("minecraft:the_nether", &[32][..]),
                    ("minecraft:the_end", &[32][..]),
                ] {
                    let level = MobWorld {
                        dimension_type: DimensionFacts::vanilla(type_id).unwrap(),
                        ..w.clone()
                    };
                    let mut random = LegacyRandom::new(42);
                    let dark = is_dark_enough(&level, &mut random, 0, 70, 0);
                    let mut expected = LegacyRandom::new(42);
                    let rolls: Vec<i32> = draws
                        .iter()
                        .map(|bound| expected.next_int_bound(*bound).unwrap())
                        .collect();
                    assert_eq!(random.next_int(), expected.next_int(), "{type_id}");
                    let light = level
                        .block_light(0, 70, 0)
                        .max(level.sky_light(0, 70, 0) - level.sky_darken());
                    let test = rolls.get(1).copied().unwrap_or(match type_id {
                        "minecraft:the_nether" => 7,
                        _ => 15,
                    });
                    assert_eq!(
                        dark,
                        rolls[0] >= level.sky_light(0, 70, 0) && light <= test,
                        "{type_id}"
                    );
                }
            },
        );
    }
}

/// A mod type's spawn rule (`RegisterSpawnPlacementsEvent`) answers the
/// type's placement and spawn predicate in place of its template species'.
#[cfg(test)]
mod mod_spawn_rule_tests {
    use super::*;
    use crate::blocks::{RenderShape, Sounds, StateFacts};
    use horizon_core::random::LegacyRandom;
    use mod_api::{SpawnLight, SpawnPlacementRule, SpawnPlacementType};
    use std::{cell::RefCell, sync::Arc};

    const AIR: BlockStateId = BlockStateId(0);
    const GRASS: BlockStateId = BlockStateId(1);
    const STONE: BlockStateId = BlockStateId(2);

    fn state(name: &str, full: bool) -> StateFacts {
        let sound: Arc<str> = Arc::from("");
        StateFacts {
            name: Arc::from(name),
            emission: 0,
            dampening: 0,
            skylight_down: true,
            shape_occlusion: false,
            can_occlude: full,
            solid_render: full,
            hardness: 1.0,
            requires_tool: false,
            replaceable: !full,
            random_ticks: false,
            block_entity: false,
            render_shape: RenderShape::Model,
            destroy_overlay: true,
            full_collision: full,
            friction: 0.6,
            explosion_resistance: 1.0,
            item: Arc::from(name),
            pick_item: Arc::from(name),
            sounds: Sounds {
                volume: 1.0,
                pitch: 1.0,
                break_sound: sound.clone(),
                step: sound.clone(),
                place: sound.clone(),
                hit: sound.clone(),
                fall: sound,
            },
            fluid: Fluid::None,
            fluid_level: 0,
            fluid_falling: false,
            waterlogged: false,
            random_offset: false,
            outline_offset: false,
            legacy_solid: full,
            sturdy_full: 0,
            classes: Arc::from([]),
            outline: Arc::from([]),
            outline_edges: Arc::from([]),
            map_color: 0,
        }
    }

    /// A flat world: grass at y 0, stone at x 5 up to y 1, air above. Light,
    /// the biome and the answer the hook gives are the test's to set.
    struct Flat {
        facts: BlockFacts,
        data: data::MobData,
        sky: i32,
        block: i32,
        /// The biome tags the spot's biome is in.
        biome_tags: Vec<&'static str>,
        /// What the hook is told the rule answered, and what it answers.
        heard: RefCell<Vec<bool>>,
        hook: Option<bool>,
    }
    impl Flat {
        fn new(rules: &[(&str, SpawnPlacementRule)]) -> Self {
            let facts = BlockFacts {
                states: vec![
                    state("minecraft:air", false),
                    state("minecraft:grass_block", true),
                    state("minecraft:stone", true),
                ],
                air: AIR,
                woods: Default::default(),
                sign_texts: Default::default(),
            };
            let mut data = data::MobData::fallback(&facts);
            for (id, rule) in rules {
                data.register_mod_spawn(id, rule);
            }
            Self {
                facts,
                data,
                sky: 15,
                block: 0,
                biome_tags: vec!["test:haunted"],
                heard: RefCell::default(),
                hook: None,
            }
        }
        /// `SpawnPlacements.checkSpawnRules` for a type of the zombie species.
        fn check(&self, entity: &str, reason: Reason, at: [i32; 3]) -> bool {
            check_spawn_rules(
                entity,
                Species::Zombie,
                self,
                reason,
                &mut LegacyRandom::new(7),
                at,
            )
        }
    }
    impl SpawnLevel for Flat {
        fn state(&self, x: i32, y: i32, _: i32) -> BlockStateId {
            match (x, y) {
                (5, ..=1) => STONE,
                (_, 0) => GRASS,
                _ => AIR,
            }
        }
        fn facts(&self) -> &BlockFacts {
            &self.facts
        }
        fn mob_data(&self) -> &data::MobData {
            &self.data
        }
        fn block_tag(&self, tag: &str, block: &str) -> bool {
            tag == "test:ghoul_ground" && block == "minecraft:grass_block"
        }
        fn biome_tag(&self, tag: &str, _: i32, _: i32, _: i32) -> bool {
            self.biome_tags.contains(&tag)
        }
        fn sky_light(&self, _: i32, _: i32, _: i32) -> i32 {
            self.sky
        }
        fn block_light(&self, _: i32, _: i32, _: i32) -> i32 {
            self.block
        }
        fn sky_darken(&self) -> i32 {
            0
        }
        fn thundering(&self) -> bool {
            false
        }
        fn sea_level(&self) -> i32 {
            63
        }
        fn world_surface(&self, _: i32, _: i32) -> i32 {
            1
        }
        fn peaceful(&self) -> bool {
            false
        }
        fn dimension_type(&self) -> &DimensionFacts {
            DimensionFacts::vanilla("minecraft:overworld").unwrap()
        }
        fn surface_slime_chance(&self, _: i32, _: i32, _: i32) -> f32 {
            0.0
        }
        fn world_seed(&self) -> i64 {
            0
        }
        fn player_near(&self, _: f64, _: f64, _: f64, _: f64) -> bool {
            false
        }
        fn placement_check(&self, _: &str, _: Reason, _: [i32; 3], vanilla: bool) -> bool {
            self.heard.borrow_mut().push(vanilla);
            self.hook.unwrap_or(vanilla)
        }
    }

    fn rule(light: SpawnLight) -> SpawnPlacementRule {
        SpawnPlacementRule {
            placement: SpawnPlacementType::OnGround,
            heightmap: mod_api::Heightmap::OceanFloor,
            spawnable_on: Some("test:ghoul_ground".to_owned()),
            light,
            biome_tag: Some("test:haunted".to_owned()),
        }
    }

    /// Ground, biome and light each refuse on their own, and the rule's
    /// light replaces the template's: a zombie needs the dark, the ghoul
    /// that declared `Bright` spawns in daylight on the same spot.
    #[test]
    fn the_rule_checks_ground_biome_and_light_in_place_of_the_templates_predicate() {
        let mut level = Flat::new(&[("ruby:ghoul", rule(SpawnLight::Bright))]);
        let on_grass = [0, 1, 0];
        assert!(level.check("ruby:ghoul", Reason::Natural, on_grass));
        assert!(
            !level.check("minecraft:zombie", Reason::Natural, on_grass),
            "the vanilla zombie still needs the dark"
        );
        // The block below, stone, is not in the ground tag.
        assert!(!level.check("ruby:ghoul", Reason::Natural, [5, 2, 0]));
        // The biome is not in the tag.
        level.biome_tags.clear();
        assert!(!level.check("ruby:ghoul", Reason::Natural, on_grass));
        level.biome_tags.push("test:haunted");
        // Light 8 is not above 8; a trial spawner ignores light.
        level.sky = 8;
        assert!(!level.check("ruby:ghoul", Reason::Natural, on_grass));
        assert!(level.check("ruby:ghoul", Reason::TrialSpawner, on_grass));
        level.sky = 9;
        assert!(level.check("ruby:ghoul", Reason::Natural, on_grass));
    }

    #[test]
    fn a_dark_rule_needs_the_dark_a_monster_needs() {
        let mut level = Flat::new(&[("ruby:ghoul", rule(SpawnLight::Dark))]);
        let on_grass = [0, 1, 0];
        level.sky = 0;
        assert!(level.check("ruby:ghoul", Reason::Natural, on_grass));
        level.block = 15;
        assert!(!level.check("ruby:ghoul", Reason::Natural, on_grass));
        level.sky = 15;
        level.block = 0;
        assert!(!level.check("ruby:ghoul", Reason::Natural, on_grass));
    }

    /// `mob_spawn_placement_check` still runs after the rule and is told its
    /// answer as `default_result`; it may overturn it either way.
    #[test]
    fn the_per_check_hook_hears_the_rules_answer() {
        let mut level = Flat::new(&[("ruby:ghoul", rule(SpawnLight::Bright))]);
        level.hook = Some(true);
        assert!(level.check("ruby:ghoul", Reason::Natural, [5, 2, 0]));
        level.hook = Some(false);
        assert!(!level.check("ruby:ghoul", Reason::Natural, [0, 1, 0]));
        assert_eq!(*level.heard.borrow(), [false, true]);
    }

    #[test]
    fn a_declared_placement_type_and_heightmap_replace_the_species_ones() {
        let anywhere = SpawnPlacementRule {
            placement: SpawnPlacementType::NoRestrictions,
            spawnable_on: None,
            biome_tag: None,
            ..rule(SpawnLight::Any)
        };
        let level = Flat::new(&[("ruby:floater", anywhere)]);
        // Mid-air with nothing below: no restrictions allows it, a zombie's
        // `ON_GROUND` does not, and the same type on grass is fine.
        assert!(is_spawn_position_ok(
            "ruby:floater",
            Species::Zombie,
            &level,
            3,
            10,
            0
        ));
        assert!(!is_spawn_position_ok(
            "ruby:undeclared",
            Species::Zombie,
            &level,
            3,
            10,
            0
        ));
        assert!(is_spawn_position_ok(
            "ruby:undeclared",
            Species::Zombie,
            &level,
            0,
            1,
            0
        ));
        assert_eq!(level.data.heightmap("ruby:floater"), "OCEAN_FLOOR");
        assert_eq!(
            level.data.heightmap("ruby:undeclared"),
            "MOTION_BLOCKING_NO_LEAVES"
        );
    }
}
