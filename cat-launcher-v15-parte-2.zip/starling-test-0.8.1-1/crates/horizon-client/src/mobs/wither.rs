//! The wither (`WitherBoss`): eleven seconds of invulnerable charging that
//! end in a blast, then flying after its target while three heads fire
//! skulls, breaking blocks around it when hurt, immune to arrows and a
//! player's wind charges below half health.
use super::{
    DamageKind, Mob, MobEvent, MobWorld, Species, Who,
    anim::{Poses, State},
    control::MoveKind,
    goals::{
        Cx, Goal, HurtByTarget, JUMP, LOOK, LookAtPlayer, MOVE, NearestTarget, Prey,
        RandomLookAround, Stroll, goal_clone,
    },
    nav::NavKind,
};
use crate::projectiles::{Projectile, ProjectileKind};
use horizon_core::geometry::trig::Mth;
use horizon_core::{geometry::Vec3, random::RandomSource};

// Wither state: `counter` the invulnerable ticks, `counter2` the block
// breaking clock, `point` the main target's position. `ints`: the side
// heads' targets (mob id, -1 the player, 0 none), their next update ticks
// and idle counts. AnimState slots 0-1 the side heads' yaw, 2-3 their pitch.
pub const INVULNERABLE: i32 = 220;

pub fn register(m: &mut Mob) {
    m.ai.mov.kind = MoveKind::Flying {
        max_turn: 10.0,
        hovers: false,
    };
    m.ai.nav.kind = NavKind::Flying;
    let g = &mut m.ai.goals;
    g.add(0, DoNothing);
    g.add(
        2,
        super::witch::RangedAttack::new(1.0, 40, 40, 20.0, |m, who, _, cx| {
            if let Some(t) = cx.w.target_info(who) {
                let at = [
                    t.position.x,
                    t.position.y + (t.eye_y - t.position.y) * 0.5,
                    t.position.z,
                ];
                let dangerous = m.random.next_float() < 0.001;
                shoot(m, 0, at, dangerous, cx.events);
            }
        }),
    );
    g.add(5, Stroll::flying(1.0));
    g.add(6, LookAtPlayer::new(8.0));
    g.add(7, RandomLookAround::default());
    m.ai.targets.add(1, HurtByTarget::new());
    m.ai.targets.add(
        2,
        NearestTarget::new(Prey::Filter(|s| !undead(s.species)), false).interval(0),
    );
    m.ai.targets
        .add(2, NearestTarget::player(false).interval(0));
}
/// `WitherBoss.hurtServer`: a wither takes nothing from a `#wither_friends`
/// mob (the undead, other withers included) that is not a player.
pub fn shielded_from(victim: Species, attacker: Species) -> bool {
    victim == Species::Wither && undead(attacker)
}
/// `#wither_friends`: the undead.
fn undead(s: Species) -> bool {
    matches!(
        s,
        Species::Zombie
            | Species::Husk
            | Species::Drowned
            | Species::ZombieVillager
            | Species::Skeleton
            | Species::Stray
            | Species::Bogged
            | Species::Parched
            | Species::WitherSkeleton
            | Species::ZombieHorse
            | Species::SkeletonHorse
            | Species::Phantom
            | Species::ZombifiedPiglin
            | Species::Zoglin
            | Species::Wither
    )
}
/// `WitherDoNothingGoal`: still while charging.
#[derive(Clone, Debug)]
struct DoNothing;
impl Goal for DoNothing {
    goal_clone!();
    fn flags(&self) -> u8 {
        MOVE | JUMP | LOOK
    }
    fn can_use(&mut self, m: &mut Mob, _cx: &mut Cx) -> bool {
        m.extra.counter > 0
    }
}
/// `WitherBoss.makeInvulnerable`: a third of its health, charging up.
pub fn make_invulnerable(m: &mut Mob) {
    m.extra.counter = INVULNERABLE;
    m.health = m.attrs.max_health / 3.0;
}
pub fn powered(m: &Mob) -> bool {
    m.health <= m.attrs.max_health / 2.0
}
pub fn head_pos(m: &Mob, i: usize) -> [f64; 3] {
    if i == 0 {
        return [m.position.x, m.position.y + 3.0, m.position.z];
    }
    let a = (m.body_yaw + 180.0 * (i as f32 - 1.0)).to_radians();
    [
        m.position.x + f64::from(a.mcos()) * 1.3,
        m.position.y + 2.2,
        m.position.z + f64::from(a.msin()) * 1.3,
    ]
}
/// `performRangedAttack`: a skull from a head toward a point.
fn shoot(m: &mut Mob, head: usize, at: [f64; 3], dangerous: bool, events: &mut Vec<MobEvent>) {
    let h = head_pos(m, head);
    // Level event 1024: the shoot sound (the client's pitch).
    if !m.silent {
        events.push(MobEvent::LevelEventSound {
            sound: "entity.wither.shoot",
            at: [m.position.x, m.position.y, m.position.z],
            volume: 2.0,
            spread: 0.2,
        });
    }
    let dir = [at[0] - h[0], at[1] - h[1], at[2] - h[2]];
    let p = Projectile::fireball(
        ProjectileKind::WitherSkull { dangerous },
        Vec3::new(h[0], h[1], h[2]),
        Some(Who::Mob(m.id)),
        dir,
    );
    events.push(MobEvent::Projectile(p));
}
/// `WitherBoss.aiStep` before travel: climb above and close in on the
/// main target.
pub fn steer(m: &mut Mob) {
    let mut v = Vec3::new(m.velocity.x, m.velocity.y * 0.6, m.velocity.z);
    if let (Some(t), Some(_)) = (m.extra.point, m.ai.target) {
        let mut yd = v.y;
        if m.position.y < t[1] || !powered(m) && m.position.y < t[1] + 5.0 {
            yd = yd.max(0.0);
            yd += 0.3 - yd * f64::from(0.6_f32);
        }
        v.y = yd;
        let (dx, dz) = (t[0] - m.position.x, t[2] - m.position.z);
        if dx * dx + dz * dz > 9.0 {
            let len = (dx * dx + dz * dz).sqrt();
            v.x += dx / len * 0.3 - v.x * 0.6;
            v.z += dz / len * 0.3 - v.z * 0.6;
        }
    }
    m.velocity = v;
    if v.x * v.x + v.z * v.z > 0.05 {
        // (float)Mth.atan2(z, x) * (180.0F / (float)Math.PI) - 90.0F
        m.yaw = (horizon_core::geometry::trig::atan2(v.z, v.x) as f32)
            * (180.0_f32 / std::f32::consts::PI)
            - 90.0;
    }
}
fn target_pos(w: &MobWorld, id: i32) -> Option<([f64; 3], f64, bool)> {
    match id {
        -1 => w
            .selected_player()
            .filter(|p| p.alive && !p.creative && !p.spectator)
            .map(|p| ([p.position.x, p.position.y, p.position.z], p.eye[1], true)),
        0 => None,
        id => w
            .others
            .iter()
            .find(|s| s.id == id as u32 && s.alive)
            .map(|s| ([s.position.x, s.position.y, s.position.z], s.eye_y, false)),
    }
}
/// `WitherBoss.aiStep` on a client of a server: the smoke about each head
/// (`radius` 0.3 of the wither's scale, which is 1 here).
pub fn client_smoke(m: &mut Mob, events: &mut Vec<MobEvent>) {
    for i in 0..3 {
        let h = head_pos(m, i);
        let r = &mut m.random;
        let at = [
            h[0] + r.next_gaussian() * 0.3,
            h[1] + r.next_gaussian() * 0.3,
            h[2] + r.next_gaussian() * 0.3,
        ];
        events.push(MobEvent::ParticleAt {
            kind: "smoke",
            at,
            velocity: [0.0; 3],
        });
    }
}
/// `WitherBoss.rotlerp`: turn at most `max` degrees toward `b`, the result
/// not wrapped (unlike `MoveControl.rotlerp`, which keeps it in 0..360).
fn head_rotlerp(a: f32, b: f32, max: f32) -> f32 {
    a + super::living::wrap(b - a).clamp(-max, max)
}
/// The side heads turn toward their targets, else back to the body. `find`
/// gives the position and eye height of the entity a head's target id names.
fn turn_heads(m: &mut Mob, find: impl Fn(i32) -> Option<([f64; 3], f64)>) {
    for i in 0..2 {
        match find(m.extra.ints[i]) {
            Some((p, eye)) => {
                let h = head_pos(m, i + 1);
                let (xd, yd, zd) = (p[0] - h[0], eye - h[1], p[2] - h[2]);
                let sd = (xd * xd + zd * zd).sqrt();
                let y_rot = horizon_core::geometry::trig::atan2_degrees(zd, xd) - 90.0;
                let x_rot = -horizon_core::geometry::trig::atan2_degrees(yd, sd);
                m.anim.v[2 + i] = head_rotlerp(m.anim.v[2 + i], x_rot, 40.0);
                m.anim.v[i] = head_rotlerp(m.anim.v[i], y_rot, 10.0);
            }
            None => m.anim.v[i] = head_rotlerp(m.anim.v[i], m.body_yaw, 10.0),
        }
    }
}
/// `WitherBoss.aiStep` on a client that is not the server: the side heads
/// turn toward the targets of the synched data (`DATA_TARGET_B` and `_C`,
/// kept in `ints[0]` and `ints[1]` as network entity ids).
pub fn client_tick(m: &mut Mob, find: impl Fn(i32) -> Option<([f64; 3], f64)>) {
    m.anim.vo = m.anim.v;
    turn_heads(m, find);
}
/// `WitherBoss.aiStep` after `super.aiStep()`: the side heads turn, then
/// smoke and (while powered) the dim entity-effect particles at each head.
pub fn ai_step(
    m: &mut Mob,
    w: &MobWorld,
    level_random: &mut impl RandomSource,
    events: &mut Vec<MobEvent>,
) {
    turn_heads(m, |id| target_pos(w, id).map(|(p, eye, _)| (p, eye)));
    head_particles(m, level_random, events);
}
/// `WitherBoss.getHeadX/Y/Z`: the centre head is 3 blocks up, the side heads
/// 2.2 up and 1.3 out, all scaled.
fn particle_head(m: &Mob, index: usize, scale: f64) -> [f64; 3] {
    let p = m.position;
    if index == 0 {
        return [p.x, p.y + 3.0 * scale, p.z];
    }
    let a = (m.body_yaw + 180.0 * (index as f32 - 1.0)).to_radians();
    [
        p.x + f64::from(a.mcos()) * 1.3 * scale,
        p.y + 2.2 * scale,
        p.z + f64::from(a.msin()) * 1.3 * scale,
    ]
}
/// `WitherBoss.aiStep`'s head particles. Smoke is one per head, offset by
/// the wither's gaussian times `0.3 * getScale()`. While powered, the level
/// random picks one tick in four for an entity-effect particle `(0.7, 0.7,
/// 0.5)` at a fresh offset. A wither that is still charging then adds the
/// `(0.7, 0.7, 0.9)` cloud. `Level.addParticle` on the server draws nothing,
/// so a window following a server runs this on its own copy too.
pub fn head_particles(
    m: &mut Mob,
    level_random: &mut impl RandomSource,
    events: &mut Vec<MobEvent>,
) {
    let powered = powered(m);
    let scale = super::riders::scale(m);
    let radius = 0.3 * scale;
    for i in 0..3 {
        let h = particle_head(m, i, scale);
        let at = [
            h[0] + m.random.next_gaussian() * radius,
            h[1] + m.random.next_gaussian() * radius,
            h[2] + m.random.next_gaussian() * radius,
        ];
        events.push(MobEvent::Particles {
            kind: "smoke",
            at,
            count: 0,
        });
        if powered && level_random.next_int_bound(4).unwrap_or(1) == 0 {
            let at = [
                h[0] + m.random.next_gaussian() * radius,
                h[1] + m.random.next_gaussian() * radius,
                h[2] + m.random.next_gaussian() * radius,
            ];
            events.push(MobEvent::ParticleColored {
                at,
                color: [0.7, 0.7, 0.5],
            });
        }
    }
    if m.extra.counter > 0 {
        charging_particles(m, events);
    }
}
/// `WitherBoss.aiStep`'s entity-effect particles while the wither is still
/// charging (`getInvulnerableTicks() > 0`): three a tick in the
/// (0.7, 0.7, 0.9) colour, a gaussian away from the body on x and z and up to
/// `3.3 * getScale()` above its feet on y, all from the wither's own random.
pub fn charging_particles(m: &mut Mob, events: &mut Vec<MobEvent>) {
    if m.extra.counter <= 0 {
        return;
    }
    let spread = 3.3 * super::riders::scale(m);
    for _ in 0..3 {
        // `this.random`: a gaussian for x, a float for y, a gaussian for z.
        let at = [
            m.position.x + m.random.next_gaussian(),
            m.position.y + f64::from(m.random.next_float()) * spread,
            m.position.z + m.random.next_gaussian(),
        ];
        events.push(MobEvent::ParticleColored {
            at,
            color: [0.7, 0.7, 0.9],
        });
    }
}
/// `WitherBoss.customServerAiStep`: charging, then the side heads' targets
/// and volleys, block breaking and healing.
pub fn custom_server_ai_step(m: &mut Mob, w: &MobWorld, events: &mut Vec<MobEvent>) {
    if m.extra.counter > 0 {
        let left = m.extra.counter - 1;
        if left <= 0 {
            // `level.explode(this, ...)`: the wither is the blast's source, so
            // its entity query (`getEntities(source, box)`) leaves it out.
            let name = match &m.custom_name {
                Some(name) => crate::text::Text::literal(name.clone()),
                None => crate::text::Text::translate("entity.minecraft.wither", &[]),
            };
            events.push(MobEvent::ExplosionSource {
                mob: m.id,
                charged: false,
                name,
                in_water: m.fluids.in_water,
                kind: m.kind.id.clone(),
            });
            events.push(MobEvent::Explode(
                [m.position.x, m.eye_y(), m.position.z],
                7.0,
                m.species(),
                m.silent,
            ));
            // Global level event 1023.
            if !m.silent {
                events.push(MobEvent::LevelEventSound {
                    sound: "entity.wither.spawn",
                    at: [m.position.x, m.position.y, m.position.z],
                    volume: 1.0,
                    spread: 0.0,
                });
            }
        }
        m.extra.counter = left;
        if m.age.is_multiple_of(10) {
            m.heal(w.loop_context, 10.0);
        }
        return;
    }
    // `setAlternativeTarget(0, ...)` once charged: `aiStep` flies toward this
    // target only after the charge, never during it.
    m.extra.point = m
        .target_info(w)
        .map(|t| [t.position.x, t.position.y, t.position.z]);
    // The side heads pick targets and fire on their own.
    let age = m.age as i32;
    for i in 1..3 {
        let k = i - 1;
        if age < m.extra.ints[2 + k] {
            continue;
        }
        m.extra.ints[2 + k] = age + 10 + m.random.next_int_bound(10).unwrap_or(0);
        m.extra.ints[4 + k] += 1;
        if m.extra.ints[4 + k] > 16 {
            // Mth.nextDouble(random, min, max) = nextDouble * (max - min) + min.
            let p = m.position;
            let r = &mut m.random;
            let mut between = |lo: f64, hi: f64| r.next_double() * (hi - lo) + lo;
            let at = [
                between(p.x - 10.0, p.x + 10.0),
                between(p.y - 5.0, p.y + 5.0),
                between(p.z - 10.0, p.z + 10.0),
            ];
            shoot(m, i + 1, at, true, events);
            m.extra.ints[4 + k] = 0;
        }
        let id = m.extra.ints[k];
        if id != 0 {
            match target_pos(w, id) {
                // `hasLineOfSight` too: no volley through a wall.
                Some((p, eye, _))
                    if (p[0] - m.position.x).powi(2)
                        + (p[1] - m.position.y).powi(2)
                        + (p[2] - m.position.z).powi(2)
                        <= 900.0
                        && m.sees(
                            w,
                            if id == -1 {
                                Who::Player
                            } else {
                                Who::Mob(id as u32)
                            },
                        ) =>
                {
                    let at = [p[0], p[1] + (eye - p[1]) * 0.5, p[2]];
                    shoot(m, i + 1, at, false, events);
                    m.extra.ints[2 + k] = age + 40 + m.random.next_int_bound(20).unwrap_or(0);
                    m.extra.ints[4 + k] = 0;
                }
                _ => m.extra.ints[k] = 0,
            }
        } else {
            // A random living thing within 20 (8 up or down), no undead.
            let p = m.position;
            let near = |q: Vec3| {
                (q.x - p.x).abs() <= 20.0 && (q.y - p.y).abs() <= 8.0 && (q.z - p.z).abs() <= 20.0
            };
            let mut found: Vec<i32> = w
                .others
                .iter()
                .filter(|s| s.alive && s.id != m.id && !undead(s.species) && near(s.position))
                .map(|s| s.id as i32)
                .collect();
            if let Some(pl) = w.selected_player()
                && pl.alive
                && !pl.creative
                && !pl.spectator
                && near(pl.position)
            {
                found.push(-1);
            }
            if !found.is_empty() {
                let pick = m.random.next_int_bound(found.len() as i32).unwrap_or(0) as usize;
                m.extra.ints[k] = found[pick];
            }
        }
    }
    if m.extra.counter2 > 0 {
        m.extra.counter2 -= 1;
        if m.extra.counter2 == 0 && w.can_grief(m.id) {
            let width = (m.width() / 2.0 + 1.0).floor() as i32;
            let height = m.height().floor() as i32;
            let b = [
                m.position.x.floor() as i32,
                m.position.y.floor() as i32,
                m.position.z.floor() as i32,
            ];
            let mut destroyed = false;
            for x in b[0] - width..=b[0] + width {
                for y in b[1]..=b[1] + height {
                    for z in b[2] - width..=b[2] + width {
                        let name = w.block_name(x, y, z);
                        let immune = w
                            .block_tags
                            .get("minecraft:wither_immune")
                            .is_some_and(|t| t.contains(name));
                        if name != "minecraft:air" && !name.ends_with("_air") && !immune {
                            events.push(MobEvent::BreakBlock {
                                pos: [x, y, z],
                                drop: true,
                                by: Some(m.id),
                                breaker: None,
                            });
                            // destroyBlock is true when setBlock changed the
                            // cell: a liquid is already its fluid's block.
                            let state = w.world.block(x, y, z);
                            destroyed |= !w.facts.get(state).has_class("LiquidBlock");
                        }
                    }
                }
            }
            if destroyed {
                // Level event 1022, once the game has broken a block.
                let start = events.len();
                events.push(MobEvent::LevelEventSound {
                    sound: "entity.wither.break_block",
                    at: [m.position.x, m.position.y, m.position.z],
                    volume: 1.0,
                    spread: 0.0,
                });
                super::after_break(events, w.asks_living_destroy_block, m.id, start);
            }
        }
    }
    if m.age.is_multiple_of(20) {
        m.heal(w.loop_context, 1.0);
    }
}
/// `WitherBoss.hurtServer` filter: not while charging, no arrows once
/// powered, nothing from the undead.
pub fn accepts(m: &mut Mob, kind: DamageKind, attacker: Option<Who>, others_undead: bool) -> bool {
    if m.extra.counter > 0 && !kind.bypasses_invulnerability() {
        return false;
    }
    if powered(m) && kind == DamageKind::Arrow {
        return false;
    }
    if others_undead || matches!(attacker, Some(Who::Mob(id)) if id == m.id) {
        return false;
    }
    if m.extra.counter2 <= 0 {
        m.extra.counter2 = 20;
    }
    m.extra.ints[4] += 3;
    m.extra.ints[5] += 3;
    true
}
/// `WitherBoss.hurtServer`: a powered wither's armor refuses a direct
/// `WindCharge`. A breeze's `BreezeWindCharge` is not one (both only extend
/// `AbstractWindCharge`), so it still hurts. Checked on the projectile, not on
/// `DamageKind`: the `wind_charge` damage type alone has no direct charge
/// (`/damage @s minecraft:wind_charge`) and goes through.
pub fn armor_refuses(m: &Mob, direct: &ProjectileKind) -> bool {
    m.species() == Species::Wither && *direct == ProjectileKind::WindCharge && powered(m)
}
/// `WitherBossModel.setupAnim`.
pub fn anim(m: &Mob, s: &State, p: &mut Poses) {
    let body =
        m.previous_body_yaw + super::living::wrap(m.body_yaw - m.previous_body_yaw) * s.partial;
    for (i, head) in ["right_head", "left_head"].into_iter().enumerate() {
        let y = m.anim.lerp(i, s.partial);
        let x = m.anim.lerp(2 + i, s.partial);
        p.yrot(head, (y - body).to_radians());
        p.xrot(head, x.to_radians());
    }
    let anim = (s.age * 0.1).mcos();
    let rib = (0.065 + 0.05 * anim) * std::f32::consts::PI;
    p.xrot("ribcage", rib);
    let tail = p.get("tail");
    tail[0] = -2.0;
    tail[1] = 6.9 + rib.mcos() * 10.0;
    tail[2] = -0.5 + rib.msin() * 10.0;
    p.xrot("tail", (0.265 + 0.1 * anim) * std::f32::consts::PI);
    p.yrot("center_head", s.y_rot.to_radians());
    p.xrot("center_head", s.x_rot.to_radians());
}
/// `WitherBossRenderer`: the blinking blue texture while charging.
pub fn texture(m: &Mob) -> &'static str {
    let t = m.extra.counter;
    if t > 0 && (t > 80 || t / 5 % 2 != 1) {
        "entity/wither/wither_invulnerable"
    } else {
        "entity/wither/wither"
    }
}
/// `WitherBossRenderer.scale`: twice the model, smaller while charging.
pub fn scale(m: &Mob, alpha: f32) -> f32 {
    let mut s = 2.0;
    if m.extra.counter > 0 {
        s -= (m.extra.counter as f32 - alpha) / INVULNERABLE as f32 * 0.5;
    }
    s
}
#[cfg(test)]
mod tests {
    use super::*;
    /// The break sound waits for the game's verdict only when a listener can
    /// cancel the break: an installed mod that does not listen leaves it plain.
    #[test]
    #[ignore = "needs prepared resources"]
    fn break_sound_defers_only_for_a_destroy_listener() {
        use std::sync::Arc;
        let build = |world: &mut crate::world::World,
                     registry: &horizon_world::registry::BlockRegistry| {
            world
                .chunks
                .insert((0, 0), Arc::new(crate::chunk::Chunk::empty(0, 0)));
            world
                .set(0, 64, 0, registry.default_state("minecraft:stone").unwrap())
                .unwrap();
        };
        assert!(super::super::world::with_built_test_world(
            &[],
            build,
            |world, types| {
                let kind = Arc::new(types.types.get("minecraft:wither").unwrap().clone());
                let mut world = world.clone();
                for asks in [false, true] {
                    world.asks_living_destroy_block = asks;
                    let mut m = Mob::new(1, kind.clone(), Vec3::new(0.5, 64.0, 0.5), 0.0);
                    m.extra.counter = 0;
                    m.extra.counter2 = 1;
                    let mut events = Vec::new();
                    custom_server_ai_step(&mut m, &world, &mut events);
                    assert!(events.iter().any(|e| matches!(
                        e,
                        MobEvent::BreakBlock {
                            pos: [0, 64, 0],
                            ..
                        }
                    )));
                    let plain = events.iter().any(|e| {
                        matches!(
                            e,
                            MobEvent::LevelEventSound {
                                sound: "entity.wither.break_block",
                                ..
                            }
                        )
                    });
                    let deferred = events.iter().any(|e| matches!(
                        e,
                        MobEvent::IfBroke { mob: 1, effects, .. }
                            if matches!(effects.as_slice(), [MobEvent::LevelEventSound { sound: "entity.wither.break_block", .. }])
                    ));
                    assert_eq!((plain, deferred), (!asks, asks), "asks: {asks}");
                }
            }
        ));
    }
    #[test]
    fn head_rotlerp_keeps_negative_angles_unwrapped() {
        assert_eq!(head_rotlerp(-5.0, -20.0, 40.0), -20.0);
        assert_eq!(head_rotlerp(-5.0, -100.0, 40.0), -45.0);
        assert_eq!(head_rotlerp(355.0, 10.0, 10.0), 365.0);
        assert_eq!(head_rotlerp(2.0, -30.0, 10.0), -8.0);
        assert_eq!(head_rotlerp(-170.0, 170.0, 10.0), -180.0);
    }
    #[test]
    fn head_rotlerp_steps_are_bounded() {
        let (mut yaw, mut pitch) = (30.0_f32, 0.0_f32);
        for _ in 0..100 {
            let (ny, np) = (
                head_rotlerp(yaw, -100.0, 10.0),
                head_rotlerp(pitch, -80.0, 40.0),
            );
            assert!((ny - yaw).abs() <= 10.0 && (np - pitch).abs() <= 40.0);
            (yaw, pitch) = (ny, np);
        }
        assert_eq!((yaw, pitch), (-100.0, -80.0));
    }
    #[test]
    fn wither_ignores_wither_friends_only() {
        assert!(shielded_from(Species::Wither, Species::Wither));
        assert!(shielded_from(Species::Wither, Species::Skeleton));
        assert!(!shielded_from(Species::Wither, Species::Creeper));
        assert!(!shielded_from(Species::Zombie, Species::Wither));
    }
    /// `WitherBoss.hurtServer` tests `instanceof WindCharge`: a powered wither
    /// took a point of damage from every charge (#8779), and a breeze's charge,
    /// a sibling class, has to keep hurting it.
    #[test]
    fn only_a_powered_withers_armor_refuses_a_wind_charge() {
        use crate::mobs::Damage;
        use crate::mobs::sensor_scan_tests::kind;
        use std::sync::Arc;
        let mob = |species, health: f32| {
            let mut kind = kind();
            Arc::make_mut(&mut kind).species = species;
            let mut m = Mob::new(1, kind, Vec3::ZERO, 0.0);
            m.attrs.max_health = 300.0;
            m.health = health;
            m
        };
        let (charge, breeze) = (ProjectileKind::WindCharge, ProjectileKind::BreezeWindCharge);
        // `isPowered` is `health <= max / 2`: the armor starts at exactly half.
        let half = mob(Species::Wither, 150.0);
        assert!(armor_refuses(&half, &charge));
        assert!(armor_refuses(&mob(Species::Wither, 1.0), &charge));
        assert!(!armor_refuses(&half, &breeze));
        assert!(!armor_refuses(&mob(Species::Wither, 150.5), &charge));
        assert!(!armor_refuses(&mob(Species::Zombie, 150.0), &charge));

        // What `wind_charge_damage` lets through still lands on the armor...
        let mut test_level = crate::health::TestLevel::new(0);
        let mut m = mob(Species::Wither, 150.0);
        assert!(m.damage(&mut test_level.level(), 1.0, Damage::of(DamageKind::Thrown)));
        assert!(m.health < 150.0);
        // ...and arrows stay refused by the damage filter.
        let mut m = mob(Species::Wither, 150.0);
        assert!(!m.damage(&mut test_level.level(), 1.0, Damage::of(DamageKind::Arrow)));
        assert_eq!(m.health, 150.0);
    }
    /// A spawning wither rolled the three particles of `aiStep`'s
    /// `getInvulnerableTicks() > 0` block and dropped them on the floor: the
    /// potion-coloured (`0.7, 0.7, 0.9`) cloud around it never appeared (#7486).
    #[test]
    fn a_charging_wither_sheds_three_potion_coloured_particles_a_tick() {
        use crate::mobs::Species;
        use crate::mobs::sensor_scan_tests::kind;
        use std::sync::Arc;
        let mut kind = kind();
        let k = Arc::make_mut(&mut kind);
        k.id = "minecraft:wither".into();
        k.species = Species::Wither;
        let wither = |model_scale: f32| {
            let mut m = Mob::new(1, kind.clone(), Vec3::new(4.0, 64.0, -2.0), 0.0);
            m.extra.counter = INVULNERABLE;
            m.extra.model_scale = model_scale;
            m
        };
        for (model_scale, spread) in [(1.0_f32, 3.3_f64), (2.0, 6.6)] {
            let mut m = wither(model_scale);
            // The wither's own random, advanced the way vanilla's `aiStep`
            // does it, for the expected offsets.
            let mut probe = m.random.clone();
            let mut events = Vec::new();
            charging_particles(&mut m, &mut events);
            let mut want = Vec::new();
            for _ in 0..3 {
                let (dx, dy, dz) = (
                    probe.next_gaussian(),
                    f64::from(probe.next_float()) * spread,
                    probe.next_gaussian(),
                );
                want.push([4.0 + dx, 64.0 + dy, -2.0 + dz]);
            }
            let got: Vec<([f64; 3], [f32; 3])> = events
                .iter()
                .map(|e| match e {
                    MobEvent::ParticleColored { at, color } => (*at, *color),
                    other => panic!("not an entity-effect particle: {other:?}"),
                })
                .collect();
            assert_eq!(got.len(), 3, "three a tick, as many as the heads' smoke");
            for (at, color) in &got {
                assert_eq!(*color, [0.7, 0.7, 0.9]);
                // Measured against the body, gaussians on x and z and a float
                // over [0, 3.3 * getScale()) on y.
                assert!((0.0..spread).contains(&(at[1] - 64.0)), "{at:?}");
            }
            let flat: Vec<[f64; 3]> = got.iter().map(|(at, _)| *at).collect();
            assert_eq!(flat, want, "scale {model_scale}");
        }
        // Once the charge ends (`getInvulnerableTicks` back to 0) the cloud
        // stops: the block is guarded, not unconditional.
        let mut m = wither(1.0);
        m.extra.counter = 0;
        let mut events = Vec::new();
        charging_particles(&mut m, &mut events);
        assert!(events.is_empty());
    }
    /// `WitherBoss.aiStep`: a powered wither (at or below half health) adds an
    /// entity-effect particle `(0.7, 0.7, 0.5)` at a head when the level
    /// random's `nextInt(4)` is 0. A healthy wither does not roll that random.
    #[test]
    fn a_powered_wither_sheds_dim_effect_particles_one_tick_in_four() {
        use crate::mobs::sensor_scan_tests::kind;
        use horizon_core::geometry::trig::Mth;
        use horizon_core::random::LegacyRandom;
        use std::sync::Arc;
        let mut kind = kind();
        let k = Arc::make_mut(&mut kind);
        k.id = "minecraft:wither".into();
        k.species = Species::Wither;
        let mut healthy = Mob::new(1, kind.clone(), Vec3::new(4.0, 64.0, -2.0), 0.0);
        healthy.attrs.max_health = 300.0;
        healthy.health = 151.0;
        let mut untouched = LegacyRandom::new(7);
        let mut level = LegacyRandom::new(7);
        let mut events = Vec::new();
        head_particles(&mut healthy, &mut level, &mut events);
        assert!(events.iter().all(|e| !matches!(
            e,
            MobEvent::ParticleColored { color, .. } if *color == [0.7, 0.7, 0.5]
        )));
        assert_eq!(level.next_int(), untouched.next_int());

        let mut powered = Mob::new(1, kind, Vec3::new(4.0, 64.0, -2.0), 0.0);
        powered.attrs.max_health = 300.0;
        powered.health = 150.0;
        powered.body_yaw = 0.0;
        // The level random's three nextInt(4) draws, taken from a copy so the
        // expected heads are not read back out of the wither.
        let mut rolls_from = LegacyRandom::new(1);
        let rolls = [
            rolls_from.next_int_bound(4).unwrap(),
            rolls_from.next_int_bound(4).unwrap(),
            rolls_from.next_int_bound(4).unwrap(),
        ];
        let mut level = LegacyRandom::new(1);
        let mut probe = powered.random.clone();
        let mut events = Vec::new();
        head_particles(&mut powered, &mut level, &mut events);
        let radius = 0.3;
        let mut smoke = Vec::new();
        let mut effect = Vec::new();
        for i in 0..3 {
            let h = if i == 0 {
                [4.0, 67.0, -2.0]
            } else {
                let a = (180.0 * (i as f32 - 1.0)).to_radians();
                [
                    4.0 + f64::from(a.mcos()) * 1.3,
                    64.0 + 2.2,
                    -2.0 + f64::from(a.msin()) * 1.3,
                ]
            };
            smoke.push([
                h[0] + probe.next_gaussian() * radius,
                h[1] + probe.next_gaussian() * radius,
                h[2] + probe.next_gaussian() * radius,
            ]);
            if rolls[i] == 0 {
                effect.push([
                    h[0] + probe.next_gaussian() * radius,
                    h[1] + probe.next_gaussian() * radius,
                    h[2] + probe.next_gaussian() * radius,
                ]);
            }
        }
        let got_smoke: Vec<[f64; 3]> = events
            .iter()
            .filter_map(|e| match e {
                MobEvent::Particles { kind, at, count: 0 } if *kind == "smoke" => Some(*at),
                _ => None,
            })
            .collect();
        let got_effect: Vec<[f64; 3]> = events
            .iter()
            .filter_map(|e| match e {
                MobEvent::ParticleColored { at, color } if *color == [0.7, 0.7, 0.5] => Some(*at),
                _ => None,
            })
            .collect();
        assert_eq!(got_smoke, smoke);
        assert_eq!(got_effect, effect);
        assert_eq!(
            effect.len(),
            rolls.iter().filter(|roll| **roll == 0).count()
        );
    }
}
