//! The camera type (`CameraType`: first person, third person behind and
//! in front, cycled by F5), the detached camera (`Camera.setup` with
//! `getMaxZoom`), and the local player drawn as a model: in third person
//! and in the inventory (`InventoryScreen.extractEntityInInventoryFollowsMouse`).
use super::{Game, Screen, native_mob_draw::PlayerRender, shoulders::shoulder_variants};
use horizon_client::{
    blocks::BlockFacts,
    camera::{CameraEntity, CameraType, LivingCamera},
    collisions::SceneCollisions,
};
use horizon_client::{
    hud::HudBatch,
    mobs::{Anim, Brain, Mob, MobType},
    mouse::Rotation,
    pose::Pose,
};
use horizon_core::{
    geometry::{Aabb, ShapeOp, Vec3, VoxelShape},
    position::BlockPos,
};
use horizon_world::{
    collision_context::{CollisionContext, CollisionEntity, CollisionItem},
    entity_obstruction::EntityIdentity,
    registry::BlockStateId,
    world_ray::{RayBlockMode, RayFluidMode, RayWorld, clip_world},
};
use mod_api::Hand;
use std::{
    io,
    path::{Path, PathBuf},
    sync::{Arc, Mutex},
};

pub(super) fn outline_offset(
    tables: &horizon_client::mesher::MeshTables,
    state: BlockStateId,
    x: i32,
    z: i32,
    follows_offset: bool,
) -> [f64; 3] {
    if follows_offset {
        tables.offset(state, x, z).unwrap_or([0.0; 3])
    } else {
        [0.0; 3]
    }
}

pub(super) fn ray_shape_from_boxes(boxes: &[[f64; 6]]) -> io::Result<VoxelShape> {
    let mut shape = VoxelShape::empty();
    for b in boxes {
        let part = VoxelShape::from_box(Aabb::new(
            Vec3::new(b[0], b[1], b[2]),
            Vec3::new(b[3], b[4], b[5]),
        ))
        .map_err(|e| io::Error::other(format!("{e:?}")))?;
        shape = shape
            .join(&part, ShapeOp::OR)
            .map_err(|e| io::Error::other(format!("{e:?}")))?;
    }
    Ok(shape)
}

pub(super) fn ray_interaction_shape(
    registry: &horizon_world::registry::BlockRegistry,
    state: BlockStateId,
) -> io::Result<VoxelShape> {
    let state = registry
        .state(state)
        .ok_or_else(|| io::Error::other("unknown block state"))?;
    ray_shape_from_boxes(&super::interaction_shapes::boxes(
        &state.name,
        state.properties.get("facing").map(String::as_str),
    ))
}

/// `Level.clip` with `ClipContext.Block.VISUAL` and no fluids:
/// `BlockBehaviour.getVisualShape` is the collision shape except for the
/// blocks that override it.
struct VisualRays<'a, 'r> {
    inner: super::explosion::ColliderRays<'a, 'r>,
    facts: &'a BlockFacts,
}
impl RayWorld for VisualRays<'_, '_> {
    type Error = io::Error;
    type Block = BlockStateId;
    type Fluid = ();
    fn block_state(&mut self, p: BlockPos) -> io::Result<BlockStateId> {
        self.inner.block_state(p)
    }
    fn fluid_state(&mut self, _: BlockPos) -> io::Result<()> {
        Ok(())
    }
    fn block_shape(
        &mut self,
        state: BlockStateId,
        p: BlockPos,
        _: RayBlockMode,
    ) -> io::Result<VoxelShape> {
        let facts = self.facts.get(state);
        let name = &*facts.name;
        // TransparentBlock (glass, stained and tinted glass, copper grates),
        // IronBarsBlock (bars and panes) and PowderSnowBlock: nothing;
        // SoulSandBlock and MudBlock: a full block; SnowLayerBlock and
        // FenceBlock: their outline.
        if name.ends_with("glass")
            || name.ends_with("glass_pane")
            || name.ends_with("_bars")
            || name.ends_with("copper_grate")
            || name == "minecraft:powder_snow"
        {
            return Ok(VoxelShape::empty());
        }
        if name == "minecraft:soul_sand" || name == "minecraft:mud" {
            return Ok(VoxelShape::block());
        }
        if name == "minecraft:snow" || name.ends_with("_fence") {
            return ray_shape_from_boxes(&facts.outline);
        }
        self.inner.block_shape(state, p, RayBlockMode::Collider)
    }
    fn interaction_shape(&mut self, state: BlockStateId, p: BlockPos) -> io::Result<VoxelShape> {
        self.inner.interaction_shape(state, p)
    }
    fn fluid_is_source(&mut self, _: ()) -> io::Result<bool> {
        Ok(false)
    }
    fn fluid_is_empty(&mut self, _: ()) -> io::Result<bool> {
        Ok(true)
    }
    fn fluid_is_water(&mut self, _: ()) -> io::Result<bool> {
        Ok(false)
    }
    fn fluid_shape(&mut self, _: (), _: BlockPos) -> io::Result<VoxelShape> {
        Ok(VoxelShape::empty())
    }
}

/// `Entity.isInvisible` for the window's player: shared flag 5 as its server
/// sets it (`shared_flag`), with the Invisibility effect or by a plugin's
/// `setInvisible` alone, as pose plugins hide the real body under the pose
/// (#3788); a world in the frame has only the effect.
fn own_invisible(effects: &horizon_client::effects::PlayerEffects, shared_flag: bool) -> bool {
    shared_flag || effects.get("invisibility").is_some()
}
/// `LivingEntityRenderer.isBodyVisible` and `isInvisibleTo` for the player's
/// own body, seen by itself: an invisible player (`own_invisible`) hides it
/// unless its team sees friendly invisibles, where vanilla draws it
/// translucent.
fn body_visible(invisible: bool, team: Option<&horizon_client::scoreboard::Team>) -> bool {
    !horizon_client::scoreboard::invisible_to(team, team, false, invisible)
}
/// The player's model type for each resources root it was asked for.
static PLAYER_TYPES: Mutex<Vec<(PathBuf, Option<Arc<MobType>>)>> = Mutex::new(Vec::new());

/// The player's model type (`PlayerModel` with the default skin), read once
/// per resources root: `entity-models.json` doesn't change while the game
/// runs, and parsing it again held every world join for about 100 ms. The
/// world resources read it as the game starts (`load_world_rest`), so a join
/// finds it; a resource pack change's new root is read once.
pub(super) fn player_type(root: &Path) -> Option<Arc<MobType>> {
    let mut cache = PLAYER_TYPES.lock().unwrap_or_else(|e| e.into_inner());
    if let Some((_, kind)) = cache.iter().find(|(cached, _)| cached == root) {
        return kind.clone();
    }
    let models = horizon_client::mobs::EntityModelDocument::load(root).ok();
    let kind = models.as_ref().and_then(load_player_type);
    cache.push((root.to_owned(), kind.clone()));
    kind
}
/// `player_type` from a document the caller already parsed (`load_core`):
/// one parse for the whole startup rather than one more beside it.
pub(super) fn player_type_with_document(
    root: &Path,
    models: &horizon_client::mobs::EntityModelDocument,
) -> Option<Arc<MobType>> {
    let mut cache = PLAYER_TYPES.lock().unwrap_or_else(|e| e.into_inner());
    if let Some((_, kind)) = cache.iter().find(|(cached, _)| cached == root) {
        return kind.clone();
    }
    let kind = load_player_type(models);
    cache.push((root.to_owned(), kind.clone()));
    kind
}
/// `player_type` from the document: the model and its layers from one parse.
fn load_player_type(models: &horizon_client::mobs::EntityModelDocument) -> Option<Arc<MobType>> {
    models.model("minecraft:player#main").map(|model| {
        Arc::new(MobType {
            id: "minecraft:player".into(),
            // Players render as a humanoid; the species only drives local AI.
            species: horizon_client::mobs::Species::Zombie,
            width: 0.6,
            height: 1.8,
            eye_height: 1.62,
            category: "misc".into(),
            max_health: 20.0,
            speed: 0.1,
            flying_speed: 0.02,
            attack_damage: 1.0,
            attack_knockback: 0.0,
            follow_range: 0.0,
            step_height: 0.6,
            armor: 0.0,
            armor_toughness: 0.0,
            knockback_resistance: 0.0,
            jump_strength: 0.42,
            attributes: Default::default(),
            item_stack_limits: Default::default(),
            gravity: 0.08,
            safe_fall_distance: 3.0,
            fall_damage_multiplier: 1.0,
            water_efficiency: 0.0,
            water_slowdown: 0.8,
            air_speed: 0.02,
            baby_scale: 0.5,
            head_rot_speed: 10.0,
            max_head_x_rot: 40.0,
            max_head_y_rot: 75.0,
            ambient_interval: 80,
            flags: Default::default(),
            model: Arc::new(model),
            // PlayerModel's slim arms, for slim skins, and PlayerCapeModel.
            layers: ["player_slim#main", "player#cape"]
                .into_iter()
                .filter_map(|key| {
                    let model = models.model(&format!("minecraft:{key}"))?;
                    Some((key.to_owned(), Arc::new(model)))
                })
                .collect(),
            texture: "entity/player/wide/steve".into(),
            brain: Brain::Passive,
            anim: Anim::Humanoid { zombie_arms: false },
            sounds: [
                "entity.player.hurt",
                "entity.player.hurt",
                "entity.player.death",
            ],
            step_sound: None,
            food: Arc::from([]),
            tempt: Arc::from([]),
            passenger_attachments: Vec::new(),
        })
    })
}
/// What sets the body's yaw of a player riding something (`Game::ridden_body`).
#[derive(Clone, Copy)]
enum RiddenBody {
    /// The boat's yaw.
    Boat(f32),
    /// The living vehicle's body yaw.
    Living(f32),
}

/// Whether a shadow pass that draws the player (`shadow_draws_player`: shadowPlayer, or a
/// native pack's shadow) takes the player's own model in first person. A shader pack's shadow
/// pass does, except for a spectator: in our probe packs' readings of Iris 1.11.7's shadow map
/// in spectator mode, the texels at the first-person camera hold the terrain below it, where
/// Horizon drew the spectator's model (vanilla's `PlayerModel` hides a spectator's body:
/// `showBody = !state.isSpectator`). A native pack's shadow keeps it.
fn shadow_pass_takes_own_model(
    shadow_draws_player: bool,
    shader_pack: bool,
    spectator: bool,
) -> bool {
    shadow_draws_player && !(shader_pack && spectator)
}

fn wrap(d: f32) -> f32 {
    let d = d % 360.0;
    if d >= 180.0 {
        d - 360.0
    } else if d < -180.0 {
        d + 360.0
    } else {
        d
    }
}
impl Game<'_> {
    /// `key.togglePerspective`: the next camera type, as a mod's `camera_type_cycle` leaves it.
    pub(super) fn cycle_camera(&mut self) {
        self.apply_requested_camera_type();
        let previous = self.camera_type;
        let mut next = previous.cycle();
        self.native_camera_type_cycle(previous, &mut next);
        self.apply_camera_type(next);
    }
    /// `Options.setCameraType`, then `Minecraft.handleKeybinds`' check: the chain
    /// follows the first-person view.
    pub(super) fn apply_camera_type(&mut self, camera_type: CameraType) {
        self.requested_camera_type.take();
        let previous = self.camera_type;
        self.camera_type = camera_type;
        if previous.is_first_person() != camera_type.is_first_person() {
            self.check_entity_post_effect(camera_type.is_first_person());
        }
    }
    /// Apply the last shared-host request through the same path as F5.
    pub(super) fn apply_requested_camera_type(&mut self) -> bool {
        let Some(camera_type) = self.requested_camera_type.take() else {
            return false;
        };
        let changed = self.camera_type != camera_type;
        self.apply_camera_type(camera_type);
        changed
    }
    /// `Camera.update` (`alignWithEntity` and `getMaxZoom`): the
    /// interpolated eye, or a point up to the camera distance behind (or in
    /// front of) it, pulled in where visual shapes are in the way. Returns the
    /// position, yaw and pitch to render from.
    pub(super) fn camera_view(&mut self, partial: f32) -> Option<(glam::DVec3, f32, f32)> {
        if self.studio.flying() {
            return Some((
                self.studio.freecam.position,
                self.studio.freecam.yaw,
                self.studio.freecam.pitch,
            ));
        }
        // Minecraft.cameraEntity: a server's spectator camera on a mob or
        // another player.
        let (entity, descending, entity_kind) = match self.camera_mob() {
            Some(m) => (
                super::remote_camera::mob_camera_entity(m),
                false,
                horizon_world::collision_context::EntityContextKind::Living,
            ),
            None => {
                let mut entity = self.player_camera_entity()?;
                if let Some(position) = self.remote_minecart_rider_position(partial) {
                    // Already evaluated at partial: do not linearly interpolate
                    // between tick endpoints across a corner a second time.
                    entity.position = position;
                    entity.previous = position;
                }
                (
                    entity,
                    self.player.as_ref()?.shift_key_down,
                    horizon_world::collision_context::EntityContextKind::Player,
                )
            }
        };
        let mut view = self.view;
        let pull = self.hooks_camera_distance(partial);
        let kind = self.camera_type;

        let context = CollisionContext::for_entity(
            CollisionEntity {
                identity: EntityIdentity(0),
                kind: entity_kind,
                y: entity.position[1],
                descending,
                main_hand: Some(CollisionItem::EMPTY),
            },
            false,
        );
        let mut rays = VisualRays {
            inner: super::explosion::ColliderRays {
                scene: SceneCollisions {
                    world: &self.world,
                    binding: self.collision,
                    subject: None,
                },
                context,
                clip_data: None,
            },
            facts: self.res.facts(),
        };
        view.align_with_entity_distance(
            &entity,
            partial,
            kind,
            |distance| {
                let mut distance = distance * pull;
                self.native_camera_distance(partial, kind.is_mirrored(), &entity, &mut distance);
                distance
            },
            |from, to| {
                let hit = clip_world(
                    &mut rays,
                    Vec3::new(from[0], from[1], from[2]),
                    Vec3::new(to[0], to[1], to[2]),
                    RayBlockMode::Visual,
                    RayFluidMode::None,
                    4096,
                )
                .ok()?;
                (!hit.miss).then_some([hit.hit.location.x, hit.hit.location.y, hit.hit.location.z])
            },
        );
        self.view = view;
        Some((
            glam::DVec3::from_array(view.position),
            view.y_rot,
            view.x_rot,
        ))
    }
    /// The player as `Camera.alignWithEntity` sees it.
    fn player_camera_entity(&mut self) -> Option<CameraEntity> {
        let (scale, distance) = {
            let p = self.player.as_mut()?;
            (
                p.attribute("minecraft:scale").unwrap_or(1.0) as f32,
                p.attribute("minecraft:camera_distance").unwrap_or(4.0),
            )
        };
        let p = self.player.as_ref()?;
        let sleeping = self.sleeping.map(|head| {
            let state = self.world.block(head[0], head[1], head[2]);
            let props = self
                .pack
                .assets
                .registry
                .state(state)
                .map(|s| &s.properties);
            // BedBlock.getBedOrientation as Direction.toYRot.
            props.and_then(|props| match props.get("facing").map(String::as_str) {
                Some("south") => Some(0.0),
                Some("west") => Some(90.0),
                Some("north") => Some(180.0),
                Some("east") => Some(270.0),
                _ => None,
            })
        });
        // Camera.setup: the living mount's scale and camera distance
        // attributes (the happy ghast's is 8, the default 4).
        let mount = self
            .riding
            .and_then(|id| self.mobs.iter().find(|m| m.id == id))
            .map(|m| {
                let attribute = |name: &str, default: f64| {
                    m.kind.attributes.get(name).copied().unwrap_or(default)
                };
                (
                    attribute("minecraft:scale", 1.0) as f32,
                    attribute("minecraft:camera_distance", 4.0),
                )
            });
        // AbstractBoat.positionRider turns a passenger by the boat's
        // deltaRotation after its yRotO was saved, and LocalPlayer.getViewYRot
        // interpolates a passenger's yaw: the boat's turn is spread over the
        // frames of a tick.
        let ride_turn = self
            .riding
            .and_then(|id| self.boats.iter().find(|b| b.id == id))
            .map_or_else(
                || {
                    self.riding
                        .and_then(|id| self.carts.iter().find(|c| c.id == id))
                        .map_or(0.0, |c| c.passenger_yaw_delta)
                },
                |b| b.delta_rotation,
            );
        let entity = CameraEntity {
            position: [p.position.x, p.position.y, p.position.z],
            previous: [
                self.previous_position.x,
                self.previous_position.y,
                self.previous_position.z,
            ],
            // Entity.turn moves the old rotation with the new: the mouse
            // turns the view every frame without interpolation.
            x_rot: self.pitch,
            y_rot: self.yaw,
            x_rot_o: self.pitch,
            y_rot_o: self.yaw - ride_turn,
            eye_height: p.dimensions.eye_height,
            living: Some(LivingCamera {
                scale,
                camera_distance: distance,
                sleeping,
                dead: None,
            }),
            mount,
        };
        Some(entity)
    }
    /// Keep the player's model in step with the player (`LivingEntity.tick`
    /// body turning, `WalkAnimationState`, the swing and the pose).
    pub(super) fn tick_player_model(&mut self) {
        let scale = self
            .player
            .as_mut()
            .and_then(|p| p.attribute("minecraft:scale").ok())
            .unwrap_or(1.0) as f32;
        let Some(p) = self.player.as_ref() else {
            self.player_model = None;
            return;
        };
        if self.player_model.is_none() {
            let Some(kind) = self.res.player_type().clone() else {
                return;
            };
            let mut m = Mob::new(0, kind, p.position, self.yaw);
            m.head_pitch = self.pitch;
            self.player_model = Some(m);
        }
        let pose = p.pose;
        let crouching = pose == Pose::Crouching;
        let position = p.position;
        let (fall_flying, fly_ticks, velocity) = (p.fall_flying, p.fall_fly_ticks, p.velocity);
        let spinning = p.auto_spin_attack_ticks > 0;
        let using = self.using.map(|(_, ticks)| ticks as i32 + 1).unwrap_or(0);
        let using_off_hand = self
            .using
            .is_some_and(|(slot, _)| slot == super::shield::OFFHAND_SLOT);
        let use_animation = self
            .using
            .and_then(|(slot, _)| self.stack_in(slot))
            .map_or_else(Default::default, |stack| self.item_use_animation(stack));
        let charged = self.inventory[self.selected]
            .as_ref()
            .is_some_and(|s| s.data().is_some_and(|d| !d.charged.is_empty()));
        let charge_duration = self.inventory[self.selected]
            .as_ref()
            .map_or(25, |s| Self::charge_ticks(s).max(1)) as i32;
        let attack = (self.swing.old_animation, self.swing.animation);
        let swinging = self.swing.swinging();
        // currentSwing.hand().asArm(mainArm).
        let swing_right_arm = swinging.then(|| {
            (self.swing.attack_hand() == mod_api::client::first_person::Hand::Main)
                != self.settings.main_hand_left
        });
        // LivingEntity.isVisuallySwimming and Entity.isInWater.
        let visually_swimming =
            p.pose == Pose::Swimming || (!p.fall_flying && p.pose == Pose::FallFlying);
        let in_water = p.fluids.was_touching_water;
        let in_lava = p.is_in_lava();
        let ticks_frozen = p.ticks_frozen;
        let (yaw, pitch) = (self.yaw, self.pitch);
        let main = self.inventory[self.selected].clone();
        let off = self.offhand.as_ref().map(|s| s.item.clone());
        let armor = self.armor.clone();
        let riding = self.riding.is_some();
        let hurt = p.health.hurt_animation_time;
        let avatar = self.avatar;
        let previous_position = self.previous_position;
        // LivingEntity.getBedOrientation: the model lies in the bed as
        // another player's does (`villager::sleep_pose`).
        let bed = self.sleeping.map_or(0, |head| self.bed_facing(head));
        let spectator = self.spectator();
        let ridden = self.ridden_body();
        let Some(m) = self.player_model.as_mut() else {
            return;
        };
        m.extra.ints[1] = bed;
        m.extra.model_scale = scale;
        // The crouch flag is still last tick's here.
        let (from, at) =
            player_model_positions(previous_position, position, m.extra.crouching, crouching);
        m.previous = from;
        m.position = at;
        let (dx, dz) = (at.x - m.previous.x, at.z - m.previous.z);
        let walked = player_walk_distance(m.previous, at);
        m.previous_yaw = m.yaw;
        m.previous_body_yaw = m.body_yaw;
        m.previous_head_yaw = m.head_yaw;
        m.previous_head_pitch = m.head_pitch;
        m.yaw = yaw;
        m.head_yaw = yaw;
        m.head_pitch = pitch;
        match ridden {
            // AbstractBoat.positionRider (clampRotation): the passenger's body
            // is set to the boat's yaw each tick.
            Some(RiddenBody::Boat(boat)) => m.body_yaw += wrap(boat - m.body_yaw),
            // A living vehicle's rider is drawn from its body
            // (`LivingEntityRenderer.solveBodyRot`).
            Some(RiddenBody::Living(body)) => {
                m.body_yaw +=
                    wrap(horizon_client::mobs::riders::solve_body_rot(yaw, body) - m.body_yaw);
            }
            // A minecart's, a cushion's: the body turns as on foot.
            None => {
                let mut target = m.body_yaw;
                if dx * dx + dz * dz > 0.002_500_000_2 {
                    // LivingEntity.tick: walking backwards the body faces away from
                    // the walk direction, not along it.
                    let walk = (dz.atan2(dx) as f32).to_degrees() - 90.0;
                    let facing = (wrap(yaw) - walk).abs();
                    target = if 95.0 < facing && facing < 265.0 {
                        walk - 180.0
                    } else {
                        walk
                    };
                }
                if swinging {
                    target = yaw;
                }
                // tickHeadTurn: ease toward the target, within 50 degrees of the head.
                m.body_yaw += wrap(target - m.body_yaw) * 0.3;
                let diff = wrap(yaw - m.body_yaw);
                if diff.abs() > 50.0 {
                    m.body_yaw += diff - diff.signum() * 50.0;
                }
            }
        }
        if riding {
            // LivingEntity.calculateEntityAnimation: a passenger stops the
            // walk animation (WalkAnimationState.stop), so the seat moving with
            // the vehicle does not swing the legs.
            m.previous_limb_speed = 0.0;
            m.limb_speed = 0.0;
            m.limb_position = 0.0;
        } else {
            // WalkAnimationState.update(min(distance * 4, 1), 0.4).
            m.previous_limb_speed = m.limb_speed;
            m.limb_speed += ((walked * 4.0).min(1.0) - m.limb_speed) * 0.4;
            m.limb_position += m.limb_speed;
        }
        // Its idle swing holds with the world under `HORIZON_STILL`.
        if self.clock.runs_normally() || !self.clock.still() {
            m.age = m.age.wrapping_add(1);
        }
        m.anim.attack_anim_o = attack.0;
        m.anim.attack_anim = attack.1;
        m.extra.set_main_hand_stack(main);
        m.extra.set_slot_id(horizon_items::equipment::OFFHAND, off);
        // The worn stacks, for the elytra's glint (`WingsLayer`).
        for (slot, stack) in horizon_items::equipment::ARMOR.into_iter().zip(armor) {
            m.extra.set_slot_stack(slot, stack);
        }
        m.extra.crouching = crouching;
        // Guests and server players take their pose from DATA_POSE, not here.
        m.extra.avatar_pose = pose;
        // What custom entity model animations read of the fluids (`is_in_water`, crawling).
        m.fluids.in_water = in_water;
        m.fluids.in_lava = in_lava;
        // Entity.DATA_TICKS_FROZEN: `isFullyFrozen` is the shiver of
        // `LivingEntityRenderer.isShaking` (#11217).
        m.ticks_frozen = ticks_frozen;
        m.extra.passenger = riding;
        m.extra.previous_velocity = m.velocity;
        m.velocity = velocity;
        m.extra.fall_flying = fall_flying;
        m.extra.fall_fly_ticks = fly_ticks;
        m.extra.auto_spin_attack = spinning;
        // LivingEntity.DATA_ARROW_COUNT_ID and DATA_STINGER_COUNT_ID: as the
        // server synced them, else the local body's own.
        (m.extra.stuck.arrows, m.extra.stuck.stingers) = match &self.remote {
            Some(r) => (r.own_arrows, r.own_stingers),
            None => (self.combat.stuck.arrows, self.combat.stuck.stingers),
        };
        m.extra.shoulder_parrots = match &self.remote {
            Some(r) => r.own_shoulders,
            None => shoulder_variants(self.level.player_extra.as_ref()),
        };
        m.extra.main_hand_left = self.settings.main_hand_left;
        m.extra.hidden_model_parts = !self.settings.file.model_customisation() & 0x7F;
        m.extra.spectator = spectator;
        m.extra.using_item = using;
        m.extra.using_off_hand = using_off_hand;
        m.extra.use_animation = use_animation;
        m.extra.held_arm_pose = [None; 2];
        m.extra.charged = charged;
        m.extra.ints[5] = charge_duration;
        m.extra.elytra.tick(fall_flying, crouching, velocity);
        m.extra.swim.tick(visually_swimming, in_water);
        // The local player's ClientAvatarState, its cloak in the model's frame
        // (the model stands 0.125 lower while crouching).
        m.extra.avatar = avatar;
        if crouching {
            m.extra.avatar.cloak[1] -= 0.125;
            m.extra.avatar.cloak_o[1] -= 0.125;
        }
        m.extra.swing_right_arm = swing_right_arm;
        m.extra.swing_stab = self.swing.current.is_some_and(|c| c.animation.kind == 2);
        m.hurt_time = hurt;
        let poses = self.held_arm_poses_with_stacks(
            self.own_entity_id() as u32,
            self.player_model.as_ref().unwrap(),
            [self.selected, super::shield::OFFHAND_SLOT].map(|slot| self.stack_in(slot)),
        );
        self.player_model.as_mut().unwrap().extra.held_arm_pose = poses;
    }
    /// `Entity.turn` for the player, by the mouse, a pad, the arrow keys or an
    /// agent's `turn`.
    /// The model's old pitch is the player's `xRotO`, which the turn moves
    /// with `xRot` (`turn_rotation`).
    pub(super) fn turn_player(&mut self, xo: f64, yo: f64) {
        if self.studio.flying() {
            self.studio
                .freecam
                .turn((xo * 0.15) as f32, (yo * 0.15) as f32);
            return;
        }
        let pitch_o = self.player_model.as_ref().map(|m| m.previous_head_pitch);
        let rotation = turn_rotation(self.yaw, self.pitch, pitch_o, xo, yo);
        // The held lead's old look (`LocalPlayer.getRopeHoldPosition`'s
        // `yRotO`/`xRotO`) turns with the view (#10276).
        self.rope_rot_old = rope_old_after_turn(self.rope_rot_old, self.yaw, self.pitch, xo, yo);
        self.yaw = rotation.y_rot;
        self.pitch = rotation.x_rot;
        if let Some(m) = self.player_model.as_mut() {
            m.previous_head_pitch = rotation.x_rot_o;
            m.head_pitch = rotation.x_rot;
        }
        // Entity.turn ends in AbstractBoat.onPassengerTurned: clampRotation
        // keeps the view within 105 degrees of the boat at every turn, not
        // only at the tick, so it never swings past and back.
        if let Some(b) = self
            .riding
            .and_then(|id| self.boats.iter().find(|b| b.id == id))
        {
            let delta = (self.yaw - b.yaw + 180.0).rem_euclid(360.0) - 180.0;
            let clamped = delta.clamp(-105.0, 105.0) - delta;
            self.yaw += clamped;
            // clampRotation moves `yRotO` with the view.
            self.rope_rot_old.0 += clamped;
        }
    }
    /// What the player rides that sets their body's yaw: a boat's yaw, or a
    /// living vehicle's body yaw. Minecarts and cushions leave it to the
    /// player's own turn.
    fn ridden_body(&self) -> Option<RiddenBody> {
        let id = self.riding?;
        if let Some(b) = self.boats.iter().find(|b| b.id == id) {
            return Some(RiddenBody::Boat(b.yaw));
        }
        let m = self.mobs.iter().find(|m| m.id == id)?;
        Some(RiddenBody::Living(m.body_yaw))
    }
    /// `Entity.setOldRot` after a server sets the player's rotation
    /// (`handleRotatePlayer`): the model's head snaps to it instead of easing
    /// in over the next tick.
    pub(super) fn snap_player_model_pitch(&mut self) {
        let pitch = self.pitch;
        if let Some(m) = self.player_model.as_mut() {
            m.previous_head_pitch = pitch;
            m.head_pitch = pitch;
        }
    }
    /// `LevelExtractor`'s skip of the camera entity: the player's own body
    /// is drawn unless the camera is in first person, or while it sleeps.
    pub(super) fn own_body_in_view(&self) -> bool {
        !self.camera_type.is_first_person() || self.sleeping.is_some() || self.studio.flying()
    }
    /// Whether the player's own model shows in the world view (its body or,
    /// while invisible, only its armour and held items).
    pub(super) fn player_model_shown(&self) -> bool {
        (self.own_body_in_view()
            || shadow_pass_takes_own_model(
                self.pack_shadow_casters.1,
                self.pack_ids.is_some(),
                self.spectator(),
            ))
            && self
                .player
                .as_ref()
                .is_some_and(|p| !p.health.dead_or_dying())
    }
    /// The player's own team: a server's client is in it by its profile name.
    fn own_team(&self) -> Option<&horizon_client::scoreboard::Team> {
        match &self.remote {
            Some(r) => self.score.board.players_team(&r.profile_name),
            None => self.player_team(),
        }
    }
    /// `Entity.isInvisible` for the player itself (`own_invisible`).
    pub(super) fn own_invisible(&self) -> bool {
        own_invisible(
            &self.potions.effects,
            self.remote.as_ref().is_some_and(|r| r.own_invisible),
        )
    }
    /// Whether the player's own body is drawn (`body_visible`).
    pub(super) fn own_body_visible(&self) -> bool {
        body_visible(self.own_invisible(), self.own_team())
    }
    /// The player's model for the entity pass in third person.
    pub(super) fn player_model_geometry(
        &self,
        camera: glam::DVec3,
        alpha: f64,
        out: &mut Vec<mod_render::render::Vertex>,
    ) {
        if !self.player_model_shown() {
            return;
        }
        let Some(m) = self.player_model.as_ref() else {
            return;
        };
        let eye = self
            .player
            .as_ref()
            .map_or_else(|| m.eye_height(), |p| f64::from(p.dimensions.eye_height));
        let probe = entity_light_block(m.position, m.extra.crouching, eye);
        let light = self.world.light(probe[0], probe[1], probe[2]);
        let packed = (u32::from(light >> 4) * 16) | ((u32::from(light & 15) * 16) << 8);
        let atlas = &self.gui.atlas;
        let lookup = |name: &str| atlas.sprites.get(name).map(|r| [r.u0, r.v0, r.u1, r.v1]);
        let start = out.len();
        let body = self.own_body_visible();
        // `native_player_submit`: a native mod's own model for this player,
        // in place of the vanilla one and its layers (an invisible player is
        // not asked, as for the others).
        let name = self.own_profile_name();
        let who = PlayerRender {
            name: &name,
            local: true,
        };
        let (drawn, hidden) = match body {
            true => self.mod_player_geometry(m, who, alpha as f32, camera, packed, out),
            false => (false, mod_api::HiddenParts::default()),
        };
        if drawn {
            return;
        }
        // `native_mob_layer`'s posed parts, kept from the draw below while a mod listens.
        let mut parts = None;
        let listened = self.mob_render_listened();
        // A spectator still draws its own model in third person: the poses'
        // visibility (set by player_model_visibility) hides body parts, and
        // translucent_body marks the body OIT for the ghostly look. Only first
        // person and dead players skip it.
        if body || self.spectator() {
            horizon_client::mobs::render::render_with_hidden(
                m,
                alpha as f32,
                camera,
                &lookup,
                packed,
                self.res.mob_data(),
                &self.player_armor_layers(),
                hidden,
                listened.then_some(&mut parts),
                out,
            );
        } else {
            horizon_client::mobs::render::render_layers(
                m,
                alpha as f32,
                camera,
                &lookup,
                packed,
                self.res.mob_data(),
                &self.player_armor_layers(),
                listened.then_some(&mut parts),
                out,
            );
        }
        // AvatarRenderer.shouldRenderLayers: a spectator draws no layers.
        if horizon_client::mobs::render::layers_shown(m) {
            let chest = self.armor[1].as_ref().map(|s| &*s.item);
            // CapeLayer: no cape on an invisible player (`isInvisible`, whoever looks).
            if !self.own_invisible() {
                self.player_cape_geometry(m, chest, camera, alpha as f32, packed, out);
            }
            self.player_ears_geometry(
                m,
                &self.own_profile_name(),
                camera,
                alpha as f32,
                packed,
                out,
            );
            let world = horizon_hooks::players::Pass::World;
            self.own_layers_geometry(m, world, camera, alpha as f32, packed, out);
            self.player_elytra_geometry(m, chest, camera, alpha as f32, packed, out);
            self.spin_attack_geometry(m, camera, alpha as f32, packed, out);
            self.shoulder_parrots_geometry(m, camera, alpha as f32, packed, out);
            self.stuck_in_body_geometry(m, self.own_entity_id(), camera, alpha as f32, packed, out);
            self.held_item_geometry(m, camera, alpha, packed, true, None, out);
            // CustomHeadLayer: a pumpkin, skull or other head item.
            self.head_item_geometry(m, camera, alpha, packed, true, out);
            // `native_mob_layer`: a native mod's layer, over the vanilla ones.
            self.mod_mob_layer_geometry(m, Some(who), parts, alpha as f32, camera, packed, out);
        }
        // LivingEntity.isCurrentlyGlowing: the Glowing effect.
        let vanilla = self
            .potions
            .effects
            .get("glowing")
            .map(|_| super::glowing::team_color(self.own_team()));
        let id = u32::try_from(self.own_entity_id()).unwrap_or(0);
        if let Some(color) = self.entity_outline(id, "minecraft:player", vanilla) {
            // LivingEntityRenderer.getRenderType: an invisible glowing body
            // still draws its outline.
            if !body {
                let mut silhouette = Vec::new();
                horizon_client::mobs::render::render(
                    m,
                    alpha as f32,
                    camera,
                    &lookup,
                    packed,
                    self.res.mob_data(),
                    &mut silhouette,
                );
                self.mark_outline(&silhouette, color);
            }
            self.mark_outline(&out[start..], color);
        }
    }
    /// `extractEntityInInventoryFollowsMouse`: the player in the box
    /// `[x0, x1) x [y0, y1)`, `size` pixels per block, turned toward the
    /// cursor; drawn with a depth buffer and back-face culling.
    #[allow(clippy::too_many_arguments)]
    pub(super) fn draw_player_preview(
        &self,
        batch: &mut HudBatch,
        x0: f32,
        y0: f32,
        x1: f32,
        y1: f32,
        size: f32,
        offset_y: f32,
    ) {
        let (cx, cy) = ((x0 + x1) / 2.0, (y0 + y1) / 2.0);
        // On a touch screen there is no cursor to follow (the touch inventory parks it out of
        // the window): the player looks ahead, turned as far as a finger dragged it.
        let (cursor, spin) = match self.player_spin() {
            Some(spin) => ((cx, cy), spin),
            None => (self.cursor, 0.0),
        };
        self.player_preview(batch, [x0, y0, x1, y1], size, offset_y, cursor, spin);
    }
    fn player_preview(
        &self,
        batch: &mut HudBatch,
        rect: [f32; 4],
        size: f32,
        offset_y: f32,
        cursor: (f32, f32),
        spin: f32,
    ) {
        if let Some(m) = self.player_model.as_ref() {
            let data = self.res.mob_data();
            self.mob_preview(m, data, batch, rect, size, offset_y, cursor, spin, true);
        }
    }
    /// `m` as the inventory draws the player, with `data` (the title screen's player too, which
    /// may come before the world's mob data). `in_world`: as the player is now, with what they
    /// wear and hold; the title screen's has no world to bring any of it from.
    #[allow(clippy::too_many_arguments)]
    pub(super) fn mob_preview(
        &self,
        m: &Mob,
        data: &horizon_client::mobs::MobData,
        batch: &mut HudBatch,
        [x0, y0, x1, y1]: [f32; 4],
        size: f32,
        offset_y: f32,
        cursor: (f32, f32),
        spin: f32,
        in_world: bool,
    ) {
        if in_world
            && self
                .player
                .as_ref()
                .is_some_and(|p| p.health.dead_or_dying())
        {
            return;
        }
        let (cx, cy) = ((x0 + x1) / 2.0, (y0 + y1) / 2.0);
        let x_angle = ((cx - cursor.0) / 40.0).atan();
        let y_angle = ((cy - cursor.1) / 40.0).atan();
        let mut m = m.clone();
        // `extractEntityInInventory` divides the size by the entity's scale: the
        // preview is the same size whatever the player's scale.
        m.extra.model_scale = 0.0;
        // The render state: still, facing out, the head toward the cursor.
        m.previous = m.position;
        m.body_yaw = 180.0 + x_angle * 20.0 + spin;
        m.previous_body_yaw = m.body_yaw;
        m.head_yaw = m.body_yaw + x_angle * 20.0;
        m.previous_head_yaw = m.head_yaw;
        m.head_pitch = -y_angle * 20.0;
        m.previous_head_pitch = m.head_pitch;
        m.position.y += 0.125 * f64::from(u8::from(m.extra.crouching));
        m.previous = m.position;
        let camera = glam::DVec3::new(m.position.x, m.position.y, m.position.z);
        let atlas = &self.gui.atlas;
        let lookup = |name: &str| atlas.sprites.get(name).map(|r| [r.u0, r.v0, r.u1, r.v1]);
        let mut verts = Vec::new();
        // A spectator preview still draws its own model: the poses'
        // visibility hides body parts, leaving the head and its layers.
        let body = self.own_body_visible() || self.spectator();
        let armour = if in_world {
            self.player_armor_layers()
        } else {
            Vec::new()
        };
        // A screen preview: custom entity model animations see is_in_gui = 1.
        horizon_client::mobs::cem_anim::in_gui(|| {
            let light = 240 | 240 << 8;
            if body {
                horizon_client::mobs::render::render_with(
                    &m, 1.0, camera, &lookup, light, data, &armour, &mut verts,
                );
            } else {
                horizon_client::mobs::render::render_layers(
                    &m, 1.0, camera, &lookup, light, data, &armour, None, &mut verts,
                );
            }
        });
        let chest = self.armor[1]
            .as_ref()
            .filter(|_| in_world)
            .map(|s| &*s.item);
        if !self.own_invisible() {
            self.player_cape_geometry(&m, chest, camera, 1.0, 240 | 240 << 8, &mut verts);
        }
        self.player_ears_geometry(
            &m,
            &self.own_profile_name(),
            camera,
            1.0,
            240 | 240 << 8,
            &mut verts,
        );
        let picture = horizon_hooks::players::Pass::Picture;
        self.own_layers_geometry(&m, picture, camera, 1.0, 240 | 240 << 8, &mut verts);
        // `WingsLayer` draws through `RenderTypes.armorCutoutNoCull`: the
        // wings' faces show from both sides (the elytra texture is empty on
        // the face that looks at the body).
        let wings_start = verts.len();
        self.player_elytra_geometry(&m, chest, camera, 1.0, 240 | 240 << 8, &mut verts);
        let wings = wings_start..verts.len();
        self.shoulder_parrots_geometry(&m, camera, 1.0, 240 | 240 << 8, &mut verts);
        if in_world {
            self.held_item_geometry(&m, camera, 1.0, 240 | 240 << 8, false, None, &mut verts);
        }
        self.head_item_geometry(&m, camera, 1.0, 240 | 240 << 8, false, &mut verts);
        let height = if m.extra.crouching { 1.5 } else { 1.8 };
        // PictureInPictureRenderer: the box centre, (size, size, -size);
        // then the translation and Rz(pi) * Rx(y_angle * 20 degrees).
        let gui = glam::Mat4::from_translation(glam::Vec3::new(cx, cy, 0.0))
            * glam::Mat4::from_scale(glam::Vec3::new(size, size, -size))
            * glam::Mat4::from_translation(glam::Vec3::new(0.0, height / 2.0 + offset_y, 0.0))
            * glam::Mat4::from_rotation_z(std::f32::consts::PI)
            * glam::Mat4::from_rotation_x((y_angle * 20.0).to_radians());
        let fire = self
            .player
            .as_ref()
            .filter(|p| p.fire_ticks > 0 && !p.spectator)
            .map(|p| (p.dimensions.width, p.dimensions.height));
        let glints = preview_glint_quads(&verts, gui, wings.clone(), self.glint_frame);
        let quads = player_preview_quads_no_cull(verts, gui, fire, &atlas.sprites, wings);
        emit_preview(batch, quads, glints, [x0, y0, x1, y1]);
    }
    /// The survival inventory's player box (`InventoryScreen`).
    pub(super) fn draw_inventory_player(&self, batch: &mut HudBatch, ox: f32, oy: f32) {
        if self.screen == Screen::Inventory {
            self.draw_player_preview(
                batch,
                ox + 26.0,
                oy + 8.0,
                ox + 75.0,
                oy + 78.0,
                30.0,
                0.0625,
            );
        }
    }
}

impl Game<'_> {
    /// `WingsLayer` for a player wearing `chest`.
    pub(super) fn player_elytra_geometry(
        &self,
        m: &Mob,
        chest: Option<&str>,
        camera: glam::DVec3,
        partial: f32,
        light: u32,
        out: &mut Vec<mod_render::render::Vertex>,
    ) {
        let stack = m
            .extra
            .slot_stack(horizon_items::equipment::CHEST)
            .filter(|s| chest == Some(&*s.item));
        self.wings_geometry(
            chest,
            stack,
            m.cape.as_deref(),
            false,
            horizon_client::mobs::render::base_transform(m, partial, camera),
            m.extra.elytra.angles(partial),
            m.extra.crouching,
            light,
            self.wings_overlay(stack),
            out,
        );
    }
    /// `WingsLayer` draws through `EquipmentLayerRenderer.renderLayers`: the
    /// armour glint when the worn elytra `hasFoil()`.
    pub(super) fn wings_overlay(&self, stack: Option<&horizon_client::items::ItemStack>) -> u32 {
        let item_glint = |item: &str| {
            let props = &self.res.items().enchantments.props;
            props.get(item).and_then(|p| p.glint)
        };
        match stack {
            Some(s) if s.has_foil(item_glint(&s.item)) => horizon_client::mobs::render::ARMOR_GLINT,
            _ => 0,
        }
    }
    /// `WingsLayer.submit` for any wearer: the wings of `chest`'s equipment
    /// asset on `base` (the wearer's model transform), `baby` for the baby
    /// elytra model. `cape` is a player's own cape texture, which has its
    /// elytra (`WingsLayer.getPlayerElytraTexture`). `stack` is the worn
    /// stack when known: an OptiFine CIT elytra rule for it replaces the
    /// texture, the cape's too, as OptiFine's `LayerElytra` does.
    #[allow(clippy::too_many_arguments)]
    pub(super) fn wings_geometry(
        &self,
        chest: Option<&str>,
        stack: Option<&horizon_client::items::ItemStack>,
        cape: Option<&str>,
        baby: bool,
        base: glam::Mat4,
        angles: [f32; 3],
        crouching: bool,
        light: u32,
        overlay: u32,
        out: &mut Vec<mod_render::render::Vertex>,
    ) {
        // The worn stack's own `equippable`, for the chest slot, with an asset
        // (getEquipmentIfRenderable: anything else counts as nothing worn).
        let equippable = match stack {
            Some(s) => horizon_client::item_sync::equippable(s, self.items()),
            None => chest
                .and_then(|item| horizon_client::item_sync::item_equippable(item, self.items())),
        };
        let Some(asset) = equippable
            .filter(|e| e.slot == "chest")
            .and_then(|e| e.asset_id)
        else {
            return;
        };
        let assets = &self.armor_stand_assets;
        let Some((texture, _)) = assets
            .equipment_layers
            .get(&asset)
            .and_then(|k| k.get("wings"))
            .and_then(|layers| layers.first())
        else {
            return;
        };
        let sprites = &self.gui.atlas.sprites;
        let rule = stack.and_then(|s| self.cit_worn_rule(horizon_client::cit::Kind::Elytra, s));
        let rect = horizon_client::cit_armor::wings(rule, cape, |s| sprites.get(s));
        let (Some(model), Some(rect)) = (
            assets
                .player
                .get(if baby { "elytra_baby" } else { "elytra" }),
            rect.or_else(|| sprites.get(texture)),
        ) else {
            return;
        };
        let base = base * glam::Mat4::from_translation(glam::Vec3::new(0.0, 0.0, 0.125));
        let pose = |part: &horizon_client::mobs::Part| {
            let mut p = part.pose;
            if part.name == "left_wing" || part.name == "right_wing" {
                let invert = if part.name == "left_wing" { 1.0 } else { -1.0 };
                p[1] = if crouching { 3.0 } else { 0.0 };
                p[3] = angles[0];
                p[4] = invert * angles[1];
                p[5] = invert * angles[2];
            }
            p
        };
        horizon_client::mobs::render_model(
            model,
            base,
            &pose,
            [rect.u0, rect.v0, rect.u1, rect.v1],
            light,
            overlay,
            out,
        );
        // The elytra texture's OptiFine emissive overlay (not a cape's), full bright.
        let glow = cape
            .and_then(|c| sprites.get(c))
            .is_none()
            .then(|| {
                let emissive = self
                    .res
                    .mob_data()
                    .emissive
                    .read()
                    .unwrap_or_else(std::sync::PoisonError::into_inner);
                emissive
                    .overlay(texture)
                    .and_then(|e| sprites.get(e))
                    .copied()
            })
            .flatten();
        if let Some(g) = glow {
            horizon_client::mobs::render_model(
                model,
                base,
                &pose,
                [g.u0, g.v0, g.u1, g.v1],
                horizon_client::mobs::render::FULL_BRIGHT,
                0,
                out,
            );
        }
    }
    /// `CapeLayer` for a player wearing `chest`: no cape under an elytra's
    /// wings, and moved out over a chestplate.
    pub(super) fn player_cape_geometry(
        &self,
        m: &Mob,
        chest: Option<&str>,
        camera: glam::DVec3,
        partial: f32,
        light: u32,
        out: &mut Vec<mod_render::render::Vertex>,
    ) {
        let Some(rect) = m
            .cape
            .as_deref()
            .and_then(|c| self.gui.atlas.sprites.get(c))
        else {
            return;
        };
        if m.is_invisible() {
            return;
        }
        // CapeLayer.hasLayer: the worn stack's own `equippable` asset.
        let items = self.res.items();
        let equippable = match m
            .extra
            .slot_stack(horizon_items::equipment::CHEST)
            .filter(|s| chest == Some(&*s.item))
        {
            Some(s) => horizon_client::item_sync::equippable(s, items),
            None => chest.and_then(|item| horizon_client::item_sync::item_equippable(item, items)),
        };
        let layers = equippable
            .filter(|e| e.slot == "chest")
            .and_then(|e| e.asset_id)
            .and_then(|asset| self.armor_stand_assets.equipment_layers.get(&asset));
        if layers.is_some_and(|k| k.contains_key("wings")) {
            return;
        }
        let mut base = horizon_client::mobs::render::base_transform(m, partial, camera);
        if layers.is_some_and(|k| k.contains_key("humanoid")) {
            base *= glam::Mat4::from_translation(glam::Vec3::new(0.0, -0.053125, 0.06875));
        }
        horizon_client::mobs::render::cape(
            m,
            partial,
            base,
            [rect.u0, rect.v0, rect.u1, rect.v1],
            light,
            self.res.mob_data(),
            out,
        );
    }
    /// `Deadmau5EarsLayer` (`AbstractClientPlayer.showExtraEars`): the ears
    /// of a player whose profile name is `deadmau5`, in the player's skin.
    pub(super) fn player_ears_geometry(
        &self,
        m: &Mob,
        name: &str,
        camera: glam::DVec3,
        partial: f32,
        light: u32,
        out: &mut Vec<mod_render::render::Vertex>,
    ) {
        if name != "deadmau5" {
            return;
        }
        let sprites = &self.gui.atlas.sprites;
        // The body's own fallback: a skin with no sprite draws the default.
        let Some(rect) = m
            .skin
            .as_deref()
            .and_then(|s| sprites.get(s))
            .or_else(|| sprites.get(&m.kind.texture))
        else {
            return;
        };
        horizon_client::mobs::render::ears(
            m,
            partial,
            horizon_client::mobs::render::base_transform(m, partial, camera),
            [rect.u0, rect.v0, rect.u1, rect.v1],
            light,
            self.res.mob_data(),
            out,
        );
    }
    /// Decide in the render layer, fire with a ClientHost, then stage the answer
    /// on this tick's model. Stack snapshots are converted only with subscribers.
    pub(super) fn held_arm_poses(
        &self,
        entity_id: u32,
        m: &Mob,
    ) -> [Option<horizon_core::arm_pose::ArmPose>; 2] {
        self.held_arm_poses_with_stacks(
            entity_id,
            m,
            [
                horizon_items::equipment::MAINHAND,
                horizon_items::equipment::OFFHAND,
            ]
            .map(|slot| m.extra.slot_stack(slot)),
        )
    }

    fn held_arm_poses_with_stacks(
        &self,
        entity_id: u32,
        m: &Mob,
        stacks: [Option<&horizon_client::items::ItemStack>; 2],
    ) -> [Option<horizon_core::arm_pose::ArmPose>; 2] {
        use super::api_values::{TryIntoApi, TryIntoEngine};
        use horizon_client::mobs::anim::humanoid_arm_poses;
        let stacks =
            stacks.map(|stack| stack.filter(|s| s.count > 0 && &*s.item != "minecraft:air"));
        let mut poses = stacks.map(|stack| {
            stack
                .and_then(|s| self.items().get(&s.item))
                .and_then(|info| info.arm_pose)
        });
        if !mod_api::__private::listened(mod_api::HookId::GetArmPose) {
            return poses;
        }
        let [main_arm_pose, off_arm_pose] = humanoid_arm_poses(m, poses, m.anim.attack_anim);
        let api_stacks = stacks.map(|stack| stack.and_then(|stack| stack.try_into_api().ok()));
        let humanoid = mod_api::HumanoidRenderState {
            main_hand: api_stacks[0].as_ref(),
            off_hand: api_stacks[1].as_ref(),
            main_arm_left: m.main_arm_left(),
            use_hand: (m.extra.using_item > 0).then_some(if m.extra.using_off_hand {
                Hand::Off
            } else {
                Hand::Main
            }),
            ticks_using_item: m.extra.using_item,
            use_animation: m.extra.use_animation,
            main_arm_pose: main_arm_pose.try_into_api().unwrap(),
            off_arm_pose: off_arm_pose.try_into_api().unwrap(),
        };
        for ((pose, stack), hand) in poses
            .iter_mut()
            .zip(api_stacks.iter().map(Option::as_ref))
            .zip(Hand::BOTH)
        {
            let Some(stack) = stack else {
                continue;
            };
            let mut answer = None;
            self.native_get_arm_pose(entity_id, hand, stack, &humanoid, &mut answer);
            if let Some(answer) = answer
                && let Ok(answer) = answer.try_into_engine(&())
            {
                *pose = Some(answer);
            }
        }
        self.transform_selected_arm_poses(m, &mut poses, humanoid);
        poses
    }
    /// The entity id the local player has on its server: the one it was
    /// given at login on a client, else the acting player's own.
    pub(in crate::game) fn own_entity_id(&self) -> i32 {
        self.remote.as_ref().map_or_else(
            || self.player.as_ref().map_or(0, |p| p.entity_id),
            |r| r.entity_id,
        )
    }
    /// `ArrowLayer` and `BeeStingerLayer` (`StuckInBodyLayer`) for a player:
    /// the arrows and bee stingers stuck in the body, placed from the entity
    /// id `id`.
    pub(super) fn stuck_in_body_geometry(
        &self,
        m: &Mob,
        id: i32,
        camera: glam::DVec3,
        partial: f32,
        light: u32,
        out: &mut Vec<mod_render::render::Vertex>,
    ) {
        let sprites = &self.gui.atlas.sprites;
        let layers = [
            (
                m.extra.stuck.arrows,
                false,
                self.arrow_model.as_ref(),
                "entity/projectiles/arrow",
            ),
            (
                m.extra.stuck.stingers,
                true,
                self.bee_stinger_model.as_ref(),
                "entity/bee/bee_stinger",
            ),
        ];
        for (count, on_surface, model, texture) in layers {
            let (true, Some(model), Some(rect)) = (count > 0, model, sprites.get(texture)) else {
                continue;
            };
            horizon_client::mobs::render::stuck_in_body(
                m,
                id,
                partial,
                camera,
                self.res.mob_data(),
                count,
                on_surface,
                model,
                [rect.u0, rect.v0, rect.u1, rect.v1],
                light,
                out,
            );
        }
    }
    /// `ParrotOnShoulderLayer`: the parrots the player keeps in its
    /// `ShoulderEntityLeft` and `ShoulderEntityRight` (game/mobs/shoulders.rs).
    pub(super) fn shoulder_parrots_geometry(
        &self,
        m: &Mob,
        camera: glam::DVec3,
        partial: f32,
        light: u32,
        out: &mut Vec<mod_render::render::Vertex>,
    ) {
        let Some(parrot) = self.res.mob_types().get("minecraft:parrot") else {
            return;
        };
        let atlas = &self.gui.atlas;
        let lookup = |name: &str| atlas.sprites.get(name).map(|r| [r.u0, r.v0, r.u1, r.v1]);
        let base = horizon_client::mobs::render::base_transform(m, partial, camera);
        for left in [true, false] {
            if let Some(variant) = m.extra.shoulder_parrots[usize::from(!left)] {
                horizon_client::mobs::render::shoulder_parrot(
                    m, parrot, variant, left, partial, base, &lookup, light, out,
                );
            }
        }
    }
    /// `SpinAttackEffectLayer`: Riptide's two boxes turning around a spinning
    /// player (`SpinAttackEffectModel.setupAnim`).
    pub(super) fn spin_attack_geometry(
        &self,
        m: &Mob,
        camera: glam::DVec3,
        partial: f32,
        light: u32,
        out: &mut Vec<mod_render::render::Vertex>,
    ) {
        if !m.extra.auto_spin_attack {
            return;
        }
        let (Some(model), Some(rect)) = (
            self.res.spin_attack().as_ref(),
            self.gui.atlas.sprites.get("entity/trident/trident_riptide"),
        ) else {
            return;
        };
        let age = m.age as f32 + partial;
        horizon_client::mobs::render_model(
            model,
            horizon_client::mobs::render::base_transform(m, partial, camera),
            &|part| {
                let mut p = part.pose;
                if let Some(i) = part
                    .name
                    .strip_prefix("box")
                    .and_then(|i| i.parse::<u8>().ok())
                {
                    let angle = age * -(45.0 + f32::from(i + 1) * 5.0);
                    p[4] = wrap(angle).to_radians();
                }
                p
            },
            [rect.u0, rect.v0, rect.u1, rect.v1],
            light,
            0,
            out,
        );
    }
}

/// `Lighting.Entry.ENTITY_IN_UI` through the entity shader's
/// `minecraft_mix_light`: the two inventory lights, (0.2, -1, 1) and
/// (-0.2, -1, 0), with the 0.6 light power and 0.4 ambient. `normal` is the
/// face's outward normal in the preview's screen space (x right, y down, z
/// towards the viewer), where a face that looks up has a negative y.
fn entity_in_ui_shade(normal: glam::Vec3) -> f32 {
    const LIGHT_0: glam::Vec3 = glam::Vec3::new(0.2, -1.0, 1.0);
    const LIGHT_1: glam::Vec3 = glam::Vec3::new(-0.2, -1.0, 0.0);
    let light = LIGHT_0.normalize().dot(normal).max(0.0) + LIGHT_1.normalize().dot(normal).max(0.0);
    (light * 0.6 + 0.4).min(1.0)
}

pub(super) fn player_preview_quads(
    verts: Vec<mod_render::render::Vertex>,
    gui: glam::Mat4,
    fire: Option<(f32, f32)>,
    sprites: &std::collections::HashMap<String, horizon_client::hud::Rect>,
) -> Vec<(f32, [[f32; 3]; 4], [[f32; 2]; 4], u32)> {
    player_preview_quads_no_cull(verts, gui, fire, sprites, 0..0)
}

/// `player_preview_quads` where the faces of the vertices in `no_cull` are
/// kept when they look away (a `NoCull` render type); their light still comes
/// from the face's own outward normal, as the vertex normal gives it.
pub(super) fn player_preview_quads_no_cull(
    mut verts: Vec<mod_render::render::Vertex>,
    gui: glam::Mat4,
    fire: Option<(f32, f32)>,
    sprites: &std::collections::HashMap<String, horizon_client::hud::Rect>,
    no_cull: std::ops::Range<usize>,
) -> Vec<(f32, [[f32; 3]; 4], [[f32; 2]; 4], u32)> {
    let flame_start = verts.len();
    if let Some((width, height)) = fire {
        horizon_client::fire_render::flames(
            [0.0; 3],
            width,
            height,
            glam::DVec3::ZERO,
            0.0,
            sprites,
            0xff,
            &mut verts,
        );
    }
    let mut quads: Vec<(f32, [[f32; 3]; 4], [[f32; 2]; 4], u32)> = Vec::new();
    for (index, q) in verts.as_chunks::<4>().0.iter().enumerate() {
        let p: [glam::Vec3; 4] =
            std::array::from_fn(|i| gui.transform_point3(glam::Vec3::from_array(q[i].pos)));
        let n = (p[1] - p[0]).cross(p[2] - p[0]);
        // The winding gives inward normals: faces with n.z >= 0 point away.
        let back = n.z >= 0.0;
        if back && !no_cull.contains(&(index * 4)) {
            continue;
        }
        let n = n.normalize_or_zero();
        let shade = if index * 4 >= flame_start {
            1.0
        } else {
            entity_in_ui_shade(-n)
        };
        let c = q[0].color;
        let ch = |s: u32| ((((c >> s) & 255) as f32 * shade) as u32) << s;
        let color = (c & 0xFF00_0000) | ch(0) | ch(8) | ch(16);
        let depth = p.iter().map(|v| v.z).sum::<f32>() / 4.0;
        let (mut pos, mut uv) = (p.map(|v| v.to_array()), std::array::from_fn(|i| q[i].uv));
        if back {
            // Seen from behind: the same quad in the opposite winding.
            pos.reverse();
            uv.reverse();
        }
        quads.push((depth, pos, uv, color));
    }
    // Keep far-to-near order for translucent faces; opaque overlap uses depth.
    quads.sort_by(|a, b| a.0.total_cmp(&b.0));
    quads
}

/// One glint face of a GUI model: its corners, the face's atlas UV (the mask),
/// the transformed glint UV, and whether it is the armour's glint.
pub(super) type PreviewGlint = ([[f32; 3]; 4], [[f32; 2]; 4], [[f32; 2]; 4], bool);

/// `EquipmentLayerRenderer.renderLayers`' glint on a GUI model: the faces of
/// the layers drawn with a glint render type because their stack `hasFoil`,
/// `armorCutoutNoCullGlint` and the trim's `trimmedArmorGlint`
/// (`mobs::render::ARMOR_GLINT`, which `armor_layers` gives a foil piece's
/// trim too; the model UV in `glint_uv`, scrolled here by
/// `ARMOR_ENTITY_GLINT_TEXTURING`), and the items' glint (overlays 7, 8 and
/// 33; `glint_uv` already transformed). Each face is culled and turned as
/// `player_preview_quads_no_cull` does with it.
pub(super) fn preview_glint_quads(
    verts: &[horizon_client::mesher::Vertex],
    gui: glam::Mat4,
    no_cull: std::ops::Range<usize>,
    frame: horizon_client::item_render::GlintFrame,
) -> Vec<PreviewGlint> {
    let armor_glint = horizon_client::item_render::Glint {
        speed: frame.speed,
        alpha: frame.alpha,
        millis: frame.millis,
        scale: 0.16,
    };
    let mut out = Vec::new();
    for (index, q) in verts.as_chunks::<4>().0.iter().enumerate() {
        let armor = match q[0].layer & 0xffff {
            horizon_client::mobs::render::ARMOR_GLINT => true,
            7 | 8 | horizon_client::gfx::TRANSLUCENT_GLINT_ITEM_OVERLAY => false,
            _ => continue,
        };
        let p: [glam::Vec3; 4] =
            std::array::from_fn(|i| gui.transform_point3(glam::Vec3::from_array(q[i].pos)));
        let back = (p[1] - p[0]).cross(p[2] - p[0]).z >= 0.0;
        if back && !no_cull.contains(&(index * 4)) {
            continue;
        }
        let mut pos = p.map(|v| v.to_array());
        let mut uv: [[f32; 2]; 4] = std::array::from_fn(|i| q[i].uv);
        let mut glint_uv: [[f32; 2]; 4] = std::array::from_fn(|i| {
            if armor {
                armor_glint.uv(q[i].glint_uv)
            } else {
                q[i].glint_uv
            }
        });
        if back {
            pos.reverse();
            uv.reverse();
            glint_uv.reverse();
        }
        out.push((pos, uv, glint_uv, armor));
    }
    out
}

/// `GuiEntityRenderer.renderToTexture`: a GUI model into `batch` in the box
/// `clip`, its faces with a depth buffer, then their glint over them in the
/// same pass.
pub(super) fn emit_preview(
    batch: &mut horizon_client::hud::HudBatch,
    quads: Vec<(f32, [[f32; 3]; 4], [[f32; 2]; 4], u32)>,
    glints: Vec<PreviewGlint>,
    clip: [f32; 4],
) {
    let start = batch.vertices.len();
    for (_, p, uv, color) in quads {
        batch.quad_3d(p, uv, color);
    }
    let glint = batch.vertices.len();
    for (p, uv, glint_uv, armor) in glints {
        batch.quad_3d_glint(p, uv, glint_uv, armor);
    }
    batch.depth_glint_since(start, glint, clip);
}

/// `Entity.turn` adds the turn to `xRotO` as well as to `xRot`, so the local
/// player's `getXRot(partialTick)` follows the mouse every frame instead of
/// easing in over a tick (#3844), while a change the tick made itself (the
/// pitch a sleeper lies at) still eases in. `pitch_o` is the model's old
/// pitch; without a model the old pitch is the pitch.
fn turn_rotation(yaw: f32, pitch: f32, pitch_o: Option<f32>, xo: f64, yo: f64) -> Rotation {
    let mut rotation = Rotation {
        x_rot: pitch,
        y_rot: yaw,
        x_rot_o: pitch_o.unwrap_or(pitch),
        y_rot_o: yaw,
    };
    rotation.turn(xo, yo);
    rotation
}

/// `Entity.turn` adds the turn to `yRotO` and `xRotO` as well, so the look the
/// held lead's end eases from (`LocalPlayer.getRopeHoldPosition`'s
/// `Mth.lerp(partialTick * 0.5F, getYRot(), yRotO)`) follows the mouse at once;
/// only what the tick itself turned (a boat's `deltaRotation`) eases in. `old`
/// is `(yRotO, xRotO)`; the result is the pair after the turn (#10276).
fn rope_old_after_turn(old: (f32, f32), yaw: f32, pitch: f32, xo: f64, yo: f64) -> (f32, f32) {
    let mut rotation = Rotation {
        x_rot: pitch,
        y_rot: yaw,
        x_rot_o: old.1,
        y_rot_o: old.0,
    };
    rotation.turn(xo, yo);
    (rotation.y_rot_o, rotation.x_rot_o)
}

/// `EntityRenderer.getPackedLightCoords` (`Entity.getLightProbePosition`):
/// the block containing the entity's eye position, undoing
/// `AvatarRenderer.getRenderOffset`'s 0.125 crouch drop on the model position.
pub(super) fn entity_light_block(position: Vec3, crouching: bool, eye_height: f64) -> [i32; 3] {
    let y = position.y + if crouching { 0.125 } else { 0.0 } + eye_height;
    [
        position.x.floor() as i32,
        y.floor() as i32,
        position.z.floor() as i32,
    ]
}

/// The player's model's old and new positions for a tick: the player's old
/// (`Entity.xo`, `yo`, `zo`) and new positions, each 0.125 lower while
/// crouching. The model is the player itself in vanilla, so
/// `EntityRenderer.extractRenderState` lerps it from the same old position
/// `Camera.setup` does, however far it moved: at Levitation 255 (12.75 blocks
/// a tick) the body keeps up with the camera. A teleport or respawn resets
/// the old position, and the model jumps with it.
fn player_model_positions(
    previous_position: Vec3,
    position: Vec3,
    was_crouching: bool,
    crouching: bool,
) -> (Vec3, Vec3) {
    let drop =
        |p: Vec3, crouching: bool| Vec3::new(p.x, p.y - if crouching { 0.125 } else { 0.0 }, p.z);
    (
        drop(previous_position, was_crouching),
        drop(position, crouching),
    )
}

/// The distance `LivingEntity.calculateEntityAnimation` walks the player's
/// model for a move from `from` to `to`. `omnidirectionalAirMover()` is false
/// for every player (`Entity`'s, not overridden), so only the horizontal
/// distance counts, flying and gliding included: rising or sinking straight
/// up or down leaves the legs and arms still.
fn player_walk_distance(from: Vec3, to: Vec3) -> f32 {
    let (dx, dz) = (to.x - from.x, to.z - from.z);
    (dx * dx + dz * dz).sqrt() as f32
}

#[cfg(test)]
mod preview_tests {
    use super::*;
    #[test]
    fn a_spectators_own_model_stays_out_of_a_shader_packs_shadow_pass() {
        // First person, a shader pack whose shadow pass draws the player: a spectator's head
        // isn't in Iris's map (#8464); the other game modes keep the model, as before.
        assert!(!shadow_pass_takes_own_model(true, true, true));
        assert!(shadow_pass_takes_own_model(true, true, false));
        // A native pack's shadow keeps the first-person model, a spectator's too.
        assert!(shadow_pass_takes_own_model(true, false, true));
        // No shadow pass that draws the player: nothing to take.
        assert!(!shadow_pass_takes_own_model(false, true, false));
    }
    #[test]
    fn the_player_model_rises_with_the_camera_at_levitation_255() {
        // LivingEntity.travel at Levitation 255: 0.05 * 255 blocks a tick.
        let from = Vec3::new(0.5, 80.0, 0.5);
        let to = Vec3::new(0.5, 92.75, 0.5);
        // The camera lerps from the old position: so does the body.
        assert_eq!(
            player_model_positions(from, to, false, false),
            (from, to),
            "the body jumps instead of rising (#3616)"
        );
        // Any distance, crouching on both ends.
        let far = Vec3::new(40.5, 80.0, 0.5);
        assert_eq!(
            player_model_positions(from, far, true, true),
            (Vec3::new(0.5, 79.875, 0.5), Vec3::new(40.5, 79.875, 0.5)),
        );
        // A teleport resets the old position to the new one: no sweep.
        assert_eq!(player_model_positions(to, to, false, false), (to, to));
    }
    #[test]
    fn flying_straight_up_does_not_walk_the_player_model() {
        let from = Vec3::new(0.5, 80.0, 0.5);
        // Creative flight straight up (#3302) and straight down.
        assert_eq!(player_walk_distance(from, Vec3::new(0.5, 80.375, 0.5)), 0.0);
        assert_eq!(player_walk_distance(from, Vec3::new(0.5, 78.5, 0.5)), 0.0);
        // Moving sideways while rising walks only the horizontal part.
        let d = player_walk_distance(from, Vec3::new(0.8, 81.0, 0.9));
        assert!((d - 0.5).abs() < 1e-6, "{d}");
    }
    /// #3844: `getXRot(partialTick)` after `Entity.turn`, as the model's
    /// renderer lerps it, with turns before and after the tick.
    #[test]
    fn own_head_pitch_follows_the_mouse_between_ticks() {
        // (pitch, the model's previous head pitch, its head pitch), as
        // `turn_player` and `tick_player_model` move them.
        let turn = |(pitch, previous, _): (f32, f32, f32), degrees: f32| {
            let r = turn_rotation(0.0, pitch, Some(previous), 0.0, f64::from(degrees / 0.15));
            (r.x_rot, r.x_rot_o, r.x_rot)
        };
        let tick = |(pitch, _, head): (f32, f32, f32)| (pitch, head, pitch);
        let x_rot =
            |(_, previous, head): (f32, f32, f32), alpha: f32| previous + (head - previous) * alpha;
        let at = |state, pitch: f32| {
            for alpha in [0.0, 0.5, 1.0] {
                let x = x_rot(state, alpha);
                assert!((x - pitch).abs() < 1e-3, "partial tick {alpha}: {x}");
            }
        };
        // The arrow keys turn before the frame's ticks: the tick then copies
        // ends that are already in step.
        let still = (10.0, 10.0, 10.0);
        let state = tick(turn(still, 30.0));
        at(state, 40.0);
        // The mouse turns after the tick: the head is there at once.
        let state = turn(state, -30.0);
        at(state, 10.0);
        // The tick laid the head down from 30 to 0: the turn moves both
        // ends, and the tick's change still eases in.
        let state = turn((0.0, 30.0, 0.0), 10.0);
        assert!((x_rot(state, 0.5) - 25.0).abs() < 1e-3, "{state:?}");
        // xRotO is clamped as xRot is.
        let r = turn_rotation(0.0, 60.0, Some(80.0), 0.0, 200.0);
        assert_eq!((r.x_rot_o, r.x_rot), (90.0, 90.0));
        // Without a model the old pitch is the pitch.
        let r = turn_rotation(0.0, 10.0, None, 0.0, 100.0);
        assert_eq!(r.x_rot_o, r.x_rot);
    }
    /// #10276: the lead held in first person eases from `yRotO`/`xRotO`, which
    /// `Entity.turn` moves with the view: a mouse turn leaves no gap for the
    /// hand to lag by, while a boat's turn (not a `turn`) still eases in.
    #[test]
    fn the_held_leads_old_look_turns_with_the_mouse() {
        // A tick's snapshot, then a 30 degree mouse turn right and 15 down.
        let (yaw, pitch) = (40.0_f32, 10.0_f32);
        let old = (yaw, pitch);
        let r = turn_rotation(yaw, pitch, None, 200.0, 100.0);
        let old = rope_old_after_turn(old, yaw, pitch, 200.0, 100.0);
        assert_eq!(old, (r.y_rot, r.x_rot), "the old look moved by the turn");
        // The boat turned the view by 5 after the snapshot: that part eases.
        let old = rope_old_after_turn((yaw, pitch), yaw + 5.0, pitch, 200.0, 0.0);
        assert!((old.0 - (yaw + 30.0)).abs() < 1e-4, "{old:?}");
        // xRotO is clamped as xRot is.
        let old = rope_old_after_turn((0.0, 85.0), 0.0, 85.0, 0.0, 100.0);
        assert_eq!(old.1, 90.0);
    }
    #[test]
    fn preview_keeps_crossing_faces_depth_and_clips_without_dropping_faces() {
        use horizon_client::{
            hud::{Blend, HudBatch},
            mesher::Vertex,
        };
        let face = |z: [f32; 4]| {
            [[-2.0, -1.0], [-2.0, 1.0], [2.0, 1.0], [2.0, -1.0]]
                .into_iter()
                .zip(z)
                .map(|([x, y], z)| Vertex {
                    pos: [x, y, z],
                    uv: [0.0; 2],
                    layer: 0,
                    color: u32::MAX,
                    light: 0,
                    normal: [0; 4],

                    glint_uv: [0.0, 0.0],
                })
        };
        // A shield and arm can intersect: neither average depth orders both ends.
        let verts = face([1.0, 1.0, -1.0, -1.0]).chain(face([0.0; 4])).collect();
        let quads = player_preview_quads(verts, glam::Mat4::IDENTITY, None, &Default::default());
        assert_eq!(quads.len(), 2);
        let mut batch = HudBatch::scratch([320, 240]);
        for (_, p, uv, color) in quads {
            batch.quad_3d(p, uv, color);
        }
        // Its centre is outside this scissor; the visible part must still be drawn.
        batch.depth_since(0, [1.0, 0.0, 2.0, 1.0]);
        assert_eq!(batch.vertices.len(), 12);
        let shield = &batch.vertices[..6];
        let arm = &batch.vertices[6..];
        assert!(shield[0].depth < arm[0].depth);
        assert!(shield[2].depth > arm[2].depth);
        assert_eq!(batch.runs(), vec![(0..12, Blend::Depth([1, 0, 1, 1]))]);
    }

    #[test]
    fn no_cull_faces_stay_in_the_preview_when_they_look_away() {
        use mod_render::render::Vertex;
        // The wings' `armorCutoutNoCull`: a face turned from the viewer is
        // dropped by the preview's culling unless its vertices are no-cull.
        let face = |z: f32| {
            [[-1.0, -1.0], [-1.0, 1.0], [1.0, 1.0], [1.0, -1.0]].map(|[x, y]| Vertex {
                pos: [x, y, z],
                uv: [x, y],
                layer: 0,
                color: u32::MAX,
                light: 0,
                normal: [0; 4],
                glint_uv: [0.0, 0.0],
            })
        };
        // Wound one way a face looks at the viewer, the other way it looks away.
        let mut away = face(0.0);
        away.reverse();
        let verts: Vec<_> = face(0.0).into_iter().chain(away).collect();
        let sprites = Default::default();
        let gui = glam::Mat4::IDENTITY;
        let culled = player_preview_quads(verts.clone(), gui, None, &sprites);
        assert_eq!(culled.len(), 1);
        let kept = player_preview_quads_no_cull(verts.clone(), gui, None, &sprites, 4..8);
        assert_eq!(kept.len(), 2);
        // The first face is outside the range and still culled when it looks away.
        let first_away = player_preview_quads_no_cull(verts, gui, None, &sprites, 0..0);
        assert_eq!(first_away.len(), 1);
    }

    /// #12666: enchanted armour glints on the inventory's player as in the
    /// world: `armorCutoutNoCullGlint` layers and foil items get a glint face.
    #[test]
    fn the_preview_glints_its_enchanted_armour_and_items() {
        use horizon_client::{item_render::GlintFrame, mesher::Vertex, mobs::render::ARMOR_GLINT};
        let face = |layer: u32, glint_uv: [f32; 2]| {
            [[-1.0, -1.0], [-1.0, 1.0], [1.0, 1.0], [1.0, -1.0]].map(|[x, y]| Vertex {
                pos: [x, y, 0.0],
                uv: [0.5 + x / 4.0, 0.5 + y / 4.0],
                layer,
                color: u32::MAX,
                light: 0,
                normal: [0; 4],
                glint_uv,
            })
        };
        let mut away = face(ARMOR_GLINT, [0.25, 0.75]);
        away.reverse();
        let verts: Vec<_> = [
            face(0, [0.0; 2]),
            face(ARMOR_GLINT, [0.25, 0.75]),
            face(7, [3.0, 4.0]),
            // The upper bits carry the HDR tier, not the overlay.
            face(ARMOR_GLINT | 1 << 16, [0.25, 0.75]),
            away,
        ]
        .into_iter()
        .flatten()
        .collect();
        let frame = GlintFrame {
            millis: 1234.0,
            speed: 0.5,
            alpha: 0.75,
            sprite: true,
        };
        let gui = glam::Mat4::IDENTITY;
        let glints = preview_glint_quads(&verts, gui, 0..0, frame);
        // The plain face has none; the armour face looking away is culled.
        assert_eq!(glints.len(), 3);
        let armor = horizon_client::item_render::Glint {
            speed: 0.5,
            alpha: 0.75,
            millis: 1234.0,
            scale: 0.16,
        };
        let (pos, uv, glint_uv, is_armor) = glints[0];
        assert!(is_armor);
        assert_eq!(pos, std::array::from_fn(|i| verts[4 + i].pos));
        assert_eq!(uv[0], verts[4].uv);
        // ARMOR_ENTITY_GLINT_TEXTURING scrolls the model UV.
        assert_eq!(glint_uv[0], armor.uv([0.25, 0.75]));
        // The item's glint UV is already transformed.
        assert_eq!((glints[1].2[0], glints[1].3), ([3.0, 4.0], false));
        assert!(glints[2].3);
        // A no-cull (wings) face that looks away keeps its glint, turned.
        let kept = preview_glint_quads(&verts, gui, 16..20, frame);
        assert_eq!(kept.len(), 4);
        assert_eq!(kept[3].0[0], verts[16 + 3].pos);
    }

    #[test]
    fn the_inventory_preview_is_lit_as_entity_in_ui() {
        // A face looking at the viewer, up, down, to the right and to the left.
        let shade = |x, y, z| entity_in_ui_shade(glam::Vec3::new(x, y, z));
        assert!((shade(0.0, 0.0, 1.0) - 0.8195).abs() < 1e-3);
        assert_eq!(shade(0.0, -1.0, 0.0), 1.0);
        assert!((shade(0.0, 1.0, 0.0) - 0.4).abs() < 1e-6);
        assert!((shade(1.0, 0.0, 0.0) - 0.4839).abs() < 1e-3);
        assert!((shade(-1.0, 0.0, 0.0) - 0.5176).abs() < 1e-3);
        // Away from the viewer: only the ambient light.
        assert!((shade(0.0, 0.0, -1.0) - 0.4).abs() < 1e-6);
    }

    #[test]
    #[ignore = "requires prepared model data in HORIZON_TEST_RESOURCES"]
    fn player_render_transform_uses_vanilla_avatar_scale() {
        let root = std::path::PathBuf::from(
            std::env::var_os("HORIZON_TEST_RESOURCES").expect("HORIZON_TEST_RESOURCES"),
        );
        let mut m = Mob::new(1, player_type(&root).unwrap(), Vec3::ZERO, 0.0);
        for (id, expected) in [("minecraft:player", 0.9375), ("minecraft:zombie", 1.0)] {
            Arc::make_mut(&mut m.kind).id = id.into();
            let transform =
                horizon_client::mobs::render::base_transform_at(&m, 1.0, glam::Mat4::IDENTITY);
            for axis in [glam::Vec3::X, glam::Vec3::Y, glam::Vec3::Z] {
                assert!((transform.transform_vector3(axis).length() - expected).abs() < 1e-6);
            }
        }
    }

    #[test]
    fn an_invisible_player_hides_its_own_body() {
        use horizon_client::{effects::EffectInstance, scoreboard::Scoreboard};
        // The effect as a server's UpdateMobEffect or a drunk potion adds it.
        let id = horizon_client::brewing::effect("minecraft:invisibility")
            .unwrap()
            .id;
        let mut effects = horizon_client::effects::PlayerEffects::default();
        assert!(body_visible(own_invisible(&effects, false), None));
        effects.add(EffectInstance::new(id, 3600, 0));
        let invisible = own_invisible(&effects, false);
        assert!(
            !body_visible(invisible, None),
            "no team: the body is hidden"
        );
        // Entity.isInvisibleTo: a team that sees friendly invisibles sees it.
        let mut board = Scoreboard::default();
        let team = board.add_team("blue");
        assert!(body_visible(invisible, Some(team)));
        team.see_friendly_invisibles = false;
        assert!(!body_visible(invisible, Some(team)));
    }

    /// #3788: a pose plugin's `Player.setInvisible(true)` sets only the
    /// shared flag (no effect); `Entity.isInvisible` reads that flag, so the
    /// real body under the pose is not drawn.
    #[test]
    fn the_servers_invisible_flag_hides_the_own_body_without_the_effect() {
        let effects = horizon_client::effects::PlayerEffects::default();
        assert!(own_invisible(&effects, true));
        assert!(!body_visible(own_invisible(&effects, true), None));
        let mut board = horizon_client::scoreboard::Scoreboard::default();
        let team = board.add_team("blue");
        assert!(body_visible(own_invisible(&effects, true), Some(team)));
    }

    /// LivingEntityRenderer.submit: an invisible body is not drawn, its
    /// HumanoidArmorLayer is.
    #[test]
    fn an_invisible_body_keeps_its_armour() {
        let root = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("../../.local/horizon-client/26.3");
        let Some(kind) = player_type(&root) else {
            return;
        };
        let m = Mob::new(1, kind.clone(), Vec3::ZERO, 0.0);
        let armour = [(&*kind.model, [0.5, 0.5, 0.75, 0.75], u32::MAX, 0, false)];
        let atlas = |_: &str| Some([0.0, 0.0, 0.25, 0.25]);
        let data = horizon_client::mobs::MobData {
            states: Vec::new(),
            placements: Default::default(),
            heightmaps: Default::default(),
            animations: Default::default(),
            biome_tags: Default::default(),
            entity_tags: Default::default(),
            villager_hats: Default::default(),
            cem: Default::default(),
            random_textures: Default::default(),
            emissive: Default::default(),
            blinks: Default::default(),
            pois: Default::default(),
            species_placements: Default::default(),
            armor_atlases: Default::default(),
            equipment: Default::default(),
            mod_spawns: Default::default(),
            pathfindable_overrides: Default::default(),
        };
        let draw = |body: bool| {
            let mut out = Vec::new();
            let at = glam::DVec3::ZERO;
            if body {
                horizon_client::mobs::render::render_with(
                    &m, 1.0, at, &atlas, 0xF0F0, &data, &armour, &mut out,
                );
            } else {
                horizon_client::mobs::render::render_layers(
                    &m, 1.0, at, &atlas, 0xF0F0, &data, &armour, None, &mut out,
                );
            }
            out
        };
        let (shown, hidden) = (draw(true), draw(false));
        assert!(shown.iter().any(|v| v.uv[0] <= 0.25), "the body draws");
        assert!(!hidden.is_empty(), "the armour still draws");
        assert!(hidden.iter().all(|v| v.uv[0] >= 0.5), "only the armour");
        assert_eq!(hidden.len() * 2, shown.len());
        // AvatarRenderer.shouldRenderLayers: a spectator has no armour layer.
        let mut ghost = m.clone();
        ghost.extra.spectator = true;
        assert!(!horizon_client::mobs::render::layers_shown(&ghost));
        let mut with_armour = Vec::new();
        let mut without = Vec::new();
        for (armour, out) in [(&armour[..], &mut with_armour), (&[][..], &mut without)] {
            horizon_client::mobs::render::render_layers(
                &ghost,
                1.0,
                glam::DVec3::ZERO,
                &atlas,
                0xF0F0,
                &data,
                armour,
                None,
                out,
            );
        }
        assert!(without.is_empty() && with_armour.is_empty(), "no armour");
    }

    #[test]
    fn burning_inventory_preview_keeps_visible_fullbright_flames() {
        let rect = |u0| horizon_client::hud::Rect {
            u0,
            v0: 0.0,
            u1: u0 + 0.1,
            v1: 0.1,
            w: 16,
            h: 16,
        };
        let sprites = std::collections::HashMap::from([
            ("block/fire_0".into(), rect(0.0)),
            ("block/fire_1".into(), rect(0.5)),
        ]);
        for pitch in [-30.0f32, 0.0, 30.0] {
            let gui = glam::Mat4::from_scale(glam::Vec3::new(30.0, 30.0, -30.0))
                * glam::Mat4::from_rotation_z(std::f32::consts::PI)
                * glam::Mat4::from_rotation_x(pitch.to_radians());
            assert!(player_preview_quads(Vec::new(), gui, None, &sprites).is_empty());
            let quads = player_preview_quads(Vec::new(), gui, Some((0.6, 1.8)), &sprites);
            assert!(
                !quads.is_empty(),
                "inventory projection must not cull all flames"
            );
            assert!(quads.iter().all(|q| q.3 == 0xffff_ffff));
            assert!(quads.iter().any(|q| q.2[0][0] <= 0.1));
            assert!(quads.iter().any(|q| q.2[0][0] >= 0.5));
            assert!(quads.windows(2).all(|q| q[0].0 <= q[1].0));
        }
    }

    #[test]
    fn sleeping_player_light_probe_stays_below_a_two_block_ceiling() {
        // In a 2-block-high room (bed at y = 64, air at 65, solid ceiling at 66),
        // setPosToBed places the sleeper at y = 64 + 0.5625 + 0.125 = 64.6875.
        let in_bed = Vec3::new(10.5, 64.0 + 0.5625 + 0.125, -4.5);
        let sleeping_eye = f64::from(Pose::Sleeping.dimensions(1.0).eye_height);
        assert_eq!(
            entity_light_block(in_bed, false, sleeping_eye),
            [10, 64, -5]
        );
        // Using the standing eye height (1.62) while in bed probed y = 66,
        // inside the ceiling block where light is 0 (#5121).
        let standing_eye = f64::from(Pose::Standing.dimensions(1.0).eye_height);
        assert_eq!(
            entity_light_block(in_bed, false, standing_eye),
            [10, 66, -5]
        );
        // A crouching player on a 7-layer snow block (feet y = 65.75, model y
        // dropped by 0.125, crouch eye 1.27) still probes at real y + eye = 67.02.
        let (_, crouch_model) = player_model_positions(
            Vec3::new(10.5, 65.75, -4.5),
            Vec3::new(10.5, 65.75, -4.5),
            true,
            true,
        );
        let crouch_eye = f64::from(Pose::Crouching.dimensions(1.0).eye_height);
        assert_eq!(
            entity_light_block(crouch_model, true, crouch_eye),
            [10, 67, -5]
        );
    }

    /// `LivingEntityRenderer.solveBodyRot` worked by hand: the head turns at
    /// most 85 degrees from the vehicle's body, and past 50 the body follows a
    /// fifth of the turn.
    #[test]
    fn a_living_vehicles_rider_faces_its_body_within_85_degrees() {
        let body = |head, vehicle| {
            (horizon_client::mobs::riders::solve_body_rot(head, vehicle) * 1000.0).round() / 1000.0
        };
        assert_eq!(body(60.0, 40.0), 40.0);
        assert_eq!(body(100.0, 40.0), 52.0);
        assert_eq!(body(140.0, 40.0), 72.0);
        assert_eq!(body(-60.0, 40.0), 8.0);
        // Across the wrap: head at 170, vehicle at -170 (20 degrees apart).
        assert_eq!(body(170.0, -170.0), 190.0);
    }
}
