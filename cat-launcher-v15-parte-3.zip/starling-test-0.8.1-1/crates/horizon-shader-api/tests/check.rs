//! `check`: the sample pack passes, and each kind of mistake is reported
//! with the pack's own file and line.
use horizon_shader_api::{MANIFEST, Pack, Problem, StageKind, check};
use std::path::Path;

fn sample() -> Pack {
    Pack::read(Path::new(concat!(
        env!("CARGO_MANIFEST_DIR"),
        "/tests/samples/schema-1"
    )))
    .unwrap()
}

/// The sample with `file` replaced by `text`, checked.
fn problems(file: &str, text: &str) -> Vec<Problem> {
    let mut files = sample().files;
    files.insert(file.into(), text.as_bytes().to_vec());
    check(&Pack::from_files(files).unwrap()).expect_err("should fail")
}

fn one(file: &str, text: &str, needle: &str) -> Problem {
    let p = problems(file, text);
    assert!(
        p.iter().any(|p| p.message.contains(needle)),
        "{needle:?} not in {p:#?}"
    );
    p.into_iter().find(|p| p.message.contains(needle)).unwrap()
}

const GRADE: &str = "post/grade.wgsl";

#[test]
fn the_sample_passes() {
    let pack = sample();
    let report = check(&pack).unwrap();
    let labels: Vec<_> = report.stages.iter().map(|s| s.label.as_str()).collect();
    assert_eq!(
        labels,
        ["sky.wgsl", "Terrain", "Colour grade", "post/vignette.wgsl"]
    );
    assert!(report.stages.iter().all(|s| s.expressions > 0));
    let post = &report.stages[2];
    assert!(post.texture_reads >= 2, "the entry point samples and loads");
    let sha = pack.sha256().unwrap();
    assert_eq!(sha.len(), 64);
    assert_eq!(sha, sample().sha256().unwrap());
}

#[test]
fn a_syntax_error_points_at_its_line() {
    let p = one(
        GRADE,
        "override saturation: f32 = 1.1;\noverride tonemap: u32 = 1u;\nfn post(input: PostInput) -> vec4<f32> {\n    return input.color +;\n}\n",
        "expected",
    );
    assert_eq!((p.file.as_str(), p.line), (GRADE, 4), "{p}");
    assert!(p.to_string().starts_with("post/grade.wgsl:4:"), "{p}");
}

#[test]
fn the_stage_function_must_have_its_signature() {
    let header = "override saturation: f32 = 1.1;\noverride tonemap: u32 = 1u;\n";
    one(
        GRADE,
        &format!("{header}fn post(input: PostInput) -> vec3<f32> {{ return input.color.rgb; }}\n"),
        "`fn post(PostInput) -> vec3<f32>` should be `fn post(input: PostInput) -> vec4<f32>`",
    );
    one(
        GRADE,
        &format!("{header}fn grade(input: PostInput) -> vec4<f32> {{ return input.color; }}\n"),
        "defines no `fn post(input: PostInput) -> vec4<f32>`",
    );
}

#[test]
fn a_pack_declares_no_bindings_entry_points_or_horizon_names() {
    let body = "override saturation: f32 = 1.1;\noverride tonemap: u32 = 1u;\nfn post(input: PostInput) -> vec4<f32> { return input.color; }\n";
    one(
        GRADE,
        &format!("@group(3) @binding(9) var extra: texture_2d<f32>;\n{body}"),
        "declares the binding `extra`",
    );
    one(
        GRADE,
        &format!(
            "{body}@fragment fn main() -> @location(0) vec4<f32> {{ return vec4<f32>(1.0); }}\n"
        ),
        "declares the entry point `main`",
    );
    one(
        GRADE,
        &format!("{body}fn horizon_mine() {{}}\n"),
        "`horizon_mine`: names starting with horizon_",
    );
}

#[test]
fn the_options_sizing_the_shadow_map_need_no_override() {
    let manifest = |keys: &str| {
        let text = String::from_utf8(sample().files[MANIFEST].clone()).unwrap();
        let text = text.replace("distance = 96.0", &format!("distance = 96.0\n{keys}"));
        format!(
            "{text}\n[[options]]\nid = \"shadow_size\"\nname = \"Size\"\ntype = \"choice\"\n\
             values = [\"1024\", \"2048\"]\ndefault = \"1024\"\n"
        )
    };
    let mut files = sample().files;
    files.insert(
        MANIFEST.into(),
        manifest("resolution_option = \"shadow_size\"\n").into_bytes(),
    );
    let report = check(&Pack::from_files(files).unwrap()).unwrap();
    let shadow = report.shadow.unwrap();
    assert_eq!(shadow.resolution_option.as_deref(), Some("shadow_size"));
    one(
        MANIFEST,
        &manifest(""),
        "option \"shadow_size\": no stage declares `override shadow_size: u32`",
    );
}

#[test]
fn overrides_match_the_options() {
    let post = "fn post(input: PostInput) -> vec4<f32> { return input.color; }\n";
    one(
        GRADE,
        &format!("override saturation: i32 = 1;\noverride tonemap: u32 = 1u;\n{post}"),
        "option \"saturation\" is a float, so its override is `f32`",
    );
    one(
        GRADE,
        &format!(
            "override saturation: f32 = 1.1;\noverride tonemap: u32 = 1u;\noverride extra: f32;\n{post}"
        ),
        "`override extra` has no default and no [[options]] entry",
    );
    let p = one(
        GRADE,
        &format!("override saturation: f32 = 1.1;\n{post}"),
        "option \"tonemap\": no stage declares `override tonemap: u32`",
    );
    assert_eq!(p.file, MANIFEST);
}

#[test]
fn validation_errors_point_into_the_pack() {
    // A compute-only barrier in a fragment stage passes the parser, not the validator.
    let p = one(
        GRADE,
        "override saturation: f32 = 1.1;\noverride tonemap: u32 = 1u;\n\
         fn post(input: PostInput) -> vec4<f32> {\n    \
         workgroupBarrier();\n    \
         return input.color;\n}\n",
        "forbidden at this stage",
    );
    assert_eq!(p.file, GRADE, "{p}");
}

#[test]
fn texture_reads_have_a_budget() {
    let reads: String = (0..70)
        .map(|i| format!("    c += textureLoad(previous, vec2<i32>({i}, 0), 0);\n"))
        .collect();
    one(
        GRADE,
        &format!(
            "override saturation: f32 = 1.1;\noverride tonemap: u32 = 1u;\nfn post(input: PostInput) -> vec4<f32> {{\n    var c = input.color;\n{reads}    return c;\n}}\n"
        ),
        "texture reads; a stage may write 64",
    );
}

#[test]
fn reads_follows_the_stage_function_through_its_calls() {
    let material = |text: &str| {
        // The sample's `[reflection] option` is an override of the material.
        let text = format!("override reflections: bool = true;\n{text}");
        let mut files = sample().files;
        files.insert("material.wgsl".into(), text.into_bytes());
        let report = check(&Pack::from_files(files).unwrap()).unwrap();
        let stage = report.stages.into_iter().find(|s| s.label == "Terrain");
        stage.unwrap()
    };
    let sample = material(
        "fn material(input: MaterialInput) -> Surface {\n    return Surface(input.albedo);\n}\n",
    );
    assert!(!sample.reads("reflection"));
    let mirror = material(
        "fn mirrored(uv: vec2<f32>) -> vec4<f32> {\n    return textureSampleLevel(reflection, reflection_sampler, uv, 0.0);\n}\nfn material(input: MaterialInput) -> Surface {\n    return Surface(mix(input.albedo, mirrored(input.screen), 0.5));\n}\n",
    );
    assert!(mirror.reads("reflection"));
    assert!(mirror.reads("reflection_sampler"));
    assert!(!mirror.reads("opaque_color"));
}

/// A stage's `files` come before its own file, and no other stage sees them.
#[test]
fn a_stages_files_are_its_own() {
    let mut pack = sample();
    pack.files.insert(
        "only_post.wgsl".into(),
        b"fn only_post() -> f32 { return 1.0; }\n".to_vec(),
    );
    pack.manifest.post[0].files.push("only_post.wgsl".into());
    let file = pack.manifest.post[0].file.clone();
    let post = horizon_shader_api::compose(&pack, horizon_shader_api::StageKind::Post, &file);
    let names: Vec<_> = post.parts.iter().map(|p| p.0.as_str()).collect();
    let (extra, own) = (
        names.iter().position(|n| *n == "only_post.wgsl").unwrap(),
        names.iter().position(|n| *n == file).unwrap(),
    );
    assert!(extra < own, "{names:?}");
    let material = pack.manifest.material.clone().unwrap().file;
    let other =
        horizon_shader_api::compose(&pack, horizon_shader_api::StageKind::Material, &material);
    assert!(other.parts.iter().all(|p| p.0 != "only_post.wgsl"));
    assert!(pack.manifest.files().contains(&"only_post.wgsl"));
    check(&pack).unwrap();
}

#[test]
fn a_vertex_stage_checks_alone_and_joins_the_material() {
    let mut files = sample().files;
    let manifest = String::from_utf8(files[MANIFEST].clone()).unwrap();
    files.insert(
        MANIFEST.into(),
        format!("{manifest}\n[vertex]\nfile = \"wave.wgsl\"\n").into_bytes(),
    );
    files.insert(
        "wave.wgsl".into(),
        b"fn vertex(input: VertexInput) -> vec3<f32> {
    return input.position + vec3(0.0, sin(frame.time) * f32(input.material), 0.0);
}
"
        .to_vec(),
    );
    let report = check(&Pack::from_files(files).unwrap()).unwrap();
    let source = |kind| {
        let stage = report.stages.iter().find(|s| s.kind == kind).unwrap();
        stage.source.contains("fn vertex(input: VertexInput)")
    };
    assert!(source(StageKind::Vertex));
    assert!(source(StageKind::Material));
}

#[test]
fn a_material_reads_its_block_texture() {
    let mut files = sample().files;
    let pack = Pack::from_files(files.clone()).unwrap();
    let file = pack.manifest.material.as_ref().unwrap().file.clone();
    files.insert(
        file,
        b"override reflections: bool = true;
fn material(input: MaterialInput) -> Surface {
    let lod = block_texture_lod() + block_texture_size().x;
    return Surface(block_texture(input.uv) + block_texture_level(input.uv, lod));
}
"
        .to_vec(),
    );
    check(&Pack::from_files(files).unwrap()).unwrap();
}

#[test]
fn only_a_material_that_calls_set_surface_needs_its_target() {
    let calls = |pack: &Pack| {
        let report = check(pack).unwrap();
        let material = report.stages.iter().find(|s| s.kind == StageKind::Material);
        horizon_shader_api::stages::calls_set_surface(&material.unwrap().source)
    };
    let mut files = sample().files;
    let pack = Pack::from_files(files.clone()).unwrap();
    assert!(!calls(&pack));
    let material = pack.manifest.material.as_ref().unwrap().file.clone();
    files.insert(
        material,
        b"override reflections: bool = true;
fn material(input: MaterialInput) -> Surface {
    set_surface(input.normal, 0.5, 7.0);
    return Surface(input.albedo);
}
"
        .to_vec(),
    );
    assert!(calls(&Pack::from_files(files).unwrap()));
}

/// The sample with `[displacement]` added to its manifest and `material.wgsl` replaced.
fn displaced(material: &str) -> Result<horizon_shader_api::Report, Vec<Problem>> {
    let mut files = sample().files;
    let manifest = String::from_utf8(files[MANIFEST].clone()).unwrap() + "\n[displacement]\n";
    files.insert(MANIFEST.into(), manifest.into_bytes());
    let own = String::from_utf8(files["material.wgsl"].clone()).unwrap() + material;
    files.insert("material.wgsl".into(), own.into_bytes());
    check(&Pack::from_files(files).unwrap())
}

#[test]
fn displacement_is_checked_with_its_signature() {
    // Depth below the face by the LabPBR height: 1/8 of a block at the bottom of the relief.
    let good = "fn displacement(input: DisplacementInput) -> f32 { return (1.0 - input.height) * 0.125; }\n";
    assert!(displaced(good).is_ok(), "{:#?}", displaced(good).err());
    let missing = displaced("").expect_err("should fail");
    assert!(
        missing.iter().any(|p| p
            .message
            .contains("defines no `fn displacement(input: DisplacementInput) -> f32`")),
        "{missing:#?}"
    );
    let wrong = displaced(
        "fn displacement(input: DisplacementInput) -> vec3<f32> { return input.normal; }\n",
    )
    .expect_err("should fail");
    assert!(
        wrong.iter().any(|p| p
            .message
            .contains("`fn displacement(DisplacementInput) -> vec3<f32>` should be")),
        "{wrong:#?}"
    );
}

/// A 0.2 pack of a post pass and a tonemap stage, with `extra` appended to the manifest.
fn pack_0_2(
    post: &str,
    tonemap: &str,
    extra: &str,
) -> Result<horizon_shader_api::Report, Vec<Problem>> {
    let manifest = format!(
        "schema = 1\nid = \"p\"\nname = \"P\"\nversion = \"1\"\napi = \"0.2\"\n\
         [[post]]\nfile = \"post.wgsl\"\n[tonemap]\nfile = \"tonemap.wgsl\"\n{extra}"
    );
    let files = [
        (MANIFEST, manifest.as_str()),
        ("post.wgsl", post),
        ("tonemap.wgsl", tonemap),
    ]
    .map(|(n, t)| (n.to_owned(), t.as_bytes().to_vec()))
    .into();
    check(&Pack::from_files(files).unwrap())
}

const POST: &str = "fn post(input: PostInput) -> vec4<f32> { return input.color; }\n";
const TONEMAP: &str =
    "fn tonemap(input: TonemapInput) -> vec3<f32> { return input.color / frame.headroom; }\n";

#[test]
fn a_0_2_pack_is_checked_against_its_own_line() {
    let report = pack_0_2(POST, TONEMAP, "[frame]\nblend = \"linear\"\n").unwrap();
    let kinds: Vec<_> = report.stages.iter().map(|s| s.kind).collect();
    assert_eq!(kinds, [StageKind::Post, StageKind::Tonemap]);
    // The 0.2 prelude's display fields and colour boundary are there to use.
    let source = &report.stages[1].source;
    assert!(source.contains("    black_level: f32,\n") && source.contains("fn horizon_decode("));
    let wrong = pack_0_2(
        POST,
        "fn tonemap(input: TonemapInput) -> vec4<f32> { return vec4<f32>(input.color, 1.0); }\n",
        "",
    )
    .expect_err("should fail");
    assert!(
        wrong.iter().any(|p| p.message.contains(
            "`fn tonemap(TonemapInput) -> vec4<f32>` should be `fn tonemap(input: TonemapInput) -> vec3<f32>`"
        )),
        "{wrong:#?}"
    );
    let named = pack_0_2(
        POST,
        &format!("fn horizon_decode_mine(c: vec3<f32>) -> vec3<f32> {{ return c; }}\n{TONEMAP}"),
        "",
    )
    .expect_err("should fail");
    assert!(
        named
            .iter()
            .any(|p| p.message.contains("`horizon_decode_mine`")),
        "{named:#?}"
    );
}

/// A 0.2 pack of a material, a post pass and a tonemap stage.
fn pack_0_2_with_material(
    material: &str,
    post: &str,
    tonemap: &str,
) -> Result<horizon_shader_api::Report, Vec<Problem>> {
    let manifest = "schema = 1\nid = \"p\"\nname = \"P\"\nversion = \"1\"\napi = \"0.2\"\n\
                    [material]\nfile = \"material.wgsl\"\n[[post]]\nfile = \"post.wgsl\"\n\
                    [tonemap]\nfile = \"tonemap.wgsl\"\n";
    let files = [
        (MANIFEST, manifest),
        ("material.wgsl", material),
        ("post.wgsl", post),
        ("tonemap.wgsl", tonemap),
    ]
    .map(|(n, t)| (n.to_owned(), t.as_bytes().to_vec()))
    .into();
    check(&Pack::from_files(files).unwrap())
}

const MATERIAL: &str =
    "fn material(input: MaterialInput) -> Surface { return Surface(input.albedo); }\n";

fn refused(problems: &[Problem], name: &str) -> Vec<(String, usize)> {
    let needle = format!("constructs `{name}`: it is Horizon's and may gain fields");
    problems
        .iter()
        .filter(|p| p.message.contains(&needle))
        .map(|p| (p.file.clone(), p.line))
        .collect()
}

#[test]
fn a_0_2_pack_constructs_no_struct_horizon_hands_it() {
    let post = "fn post(input: PostInput) -> vec4<f32> {\n    \
                let moved = PostInput(input.uv * 0.5, input.pixel, input.color, input.depth);\n    \
                return moved.color;\n}\n";
    let p = pack_0_2(post, TONEMAP, "").expect_err("should fail");
    assert_eq!(
        refused(&p, "PostInput"),
        [("post.wgsl".into(), 2)],
        "{p:#?}"
    );

    // Inside a helper, at the module's level, and the frame too.
    let tonemap = "fn darker(c: vec3<f32>) -> TonemapInput {\n    \
                   return TonemapInput(vec2<f32>(0.0), vec2<f32>(0.0), c * 0.5);\n}\n\
                   fn tonemap(input: TonemapInput) -> vec3<f32> { return darker(input.color).color; }\n";
    let p = pack_0_2(POST, tonemap, "").expect_err("should fail");
    assert_eq!(
        refused(&p, "TonemapInput"),
        [("tonemap.wgsl".into(), 2)],
        "{p:#?}"
    );
    let fields: Vec<String> = horizon_shader_api::Frame::WGSL
        .fields
        .iter()
        .map(|f| format!("{}()", f.ty))
        .collect();
    let tonemap = format!(
        "const still = Frame({});\n\
         fn tonemap(input: TonemapInput) -> vec3<f32> {{ return input.color * still.headroom; }}\n",
        fields.join(", ")
    );
    let p = pack_0_2(POST, &tonemap, "").expect_err("should fail");
    assert_eq!(refused(&p, "Frame"), [("tonemap.wgsl".into(), 1)], "{p:#?}");

    let material = "fn material(input: MaterialInput) -> Surface {\n    \
                    let again = MaterialInput(input.albedo, input.tint, input.light, input.lightmap, \
                    input.position, input.uv, input.translucent, input.tags, input.material, input.screen, \
                    input.face, input.fluid, input.emission, input.normal, input.tangent, input.colored_light, \
                    input.displaced);\n    \
                    return Surface(again.albedo);\n}\n";
    let p = pack_0_2_with_material(material, POST, TONEMAP).expect_err("should fail");
    assert_eq!(
        refused(&p, "MaterialInput"),
        [("material.wgsl".into(), 2)],
        "{p:#?}"
    );

    // `surface_at`'s result: Horizon's helper builds it, the pack doesn't.
    let post = "fn post(input: PostInput) -> vec4<f32> {\n    \
                let s = SurfaceData(true, vec3<f32>(0.0, 1.0, 0.0), 0.5, 0.0);\n    \
                return input.color * s.smoothness * surface_at(vec2<i32>(input.pixel)).smoothness;\n}\n";
    let p = pack_0_2(post, TONEMAP, "").expect_err("should fail");
    assert_eq!(
        refused(&p, "SurfaceData"),
        [("post.wgsl".into(), 2)],
        "{p:#?}"
    );
}

#[test]
fn a_0_2_pack_reads_horizon_s_structs_passes_them_along_and_builds_its_surface() {
    // A name that merely contains a struct's, a comment and a field read are no construction.
    let post = "// PostInput(input.uv) would be refused\n\
                struct MyPostInput { color: vec4<f32> }\n\
                fn graded(input: PostInput) -> MyPostInput { return MyPostInput(input.color * frame.headroom); }\n\
                fn post(input: PostInput) -> vec4<f32> { return graded(input).color; }\n";
    let tonemap = "fn curve(input: TonemapInput) -> vec3<f32> { return input.color / (input.color + 1.0); }\n\
                   fn tonemap(input: TonemapInput) -> vec3<f32> { return curve(input); }\n";
    pack_0_2_with_material(MATERIAL, post, tonemap).unwrap();
    // The tonemap prelude has no `SurfaceData`: one of the pack's own is the pack's to build.
    let tonemap = "struct SurfaceData { gain: f32 }\n\
                   fn tonemap(input: TonemapInput) -> vec3<f32> { return input.color * SurfaceData(0.5).gain; }\n";
    pack_0_2_with_material(MATERIAL, POST, tonemap).unwrap();
    // Nor is an alias of the pack's own by that name.
    let tonemap = "alias SurfaceData = vec3<f32>;\n\
                   fn tonemap(input: TonemapInput) -> vec3<f32> { return SurfaceData(input.color.r, 0.0, 0.0); }\n";
    pack_0_2_with_material(MATERIAL, POST, tonemap).unwrap();
}

#[test]
fn a_0_1_pack_may_still_construct_its_inputs() {
    let mut files = sample().files;
    files.insert(
        GRADE.into(),
        b"override saturation: f32 = 1.1;\noverride tonemap: u32 = 1u;\n\
          fn post(input: PostInput) -> vec4<f32> { return PostInput(input.uv, input.pixel, input.color, input.depth).color; }\n"
            .to_vec(),
    );
    check(&Pack::from_files(files).unwrap()).unwrap();
}

#[test]
fn a_0_1_pack_doesn_t_see_0_2_s_names() {
    let p = one(
        GRADE,
        "override saturation: f32 = 1.1;\noverride tonemap: u32 = 1u;\nfn post(input: PostInput) -> vec4<f32> { return input.color * frame.headroom; }\n",
        "headroom",
    );
    assert_eq!(p.file, GRADE, "{p}");
}
