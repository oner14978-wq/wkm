//! Monster spawners in the game: `SpawnerBlockEntity.serverTick` and
//! `clientTick` for every spawner (`mobs::spawner`), the mobs they add, a
//! spawn egg used on one (`SpawnEggItem.useOn`), their events and the mob
//! spinning inside (`SpawnerRenderer`).
use super::{
    Game,
    creatures::{Finalized, SpawnReason},
};
use horizon_client::{
    Result,
    containers::BlockEntity,
    mobs::{
        Mob, Who,
        spawner::{SpawnDataExt, Spawner, SpawnerAdded, SpawnerEvent, SpawnerExt, SpawnerSpawn},
        trial_spawner::{TrialSpawnerExt, TrialState},
    },
    particles::{ParticleOptions, ParticleType},
};
use horizon_core::nbt::Tag;
use horizon_core::{
    geometry::Vec3,
    random::{LegacyRandom, RandomSource},
};
use std::collections::{HashMap, HashSet};

type Pos = (i32, i32, i32);

/// What a spawner tick decided to add, created once the level is free.
pub(super) enum Planned {
    /// `finalizeSpawn` ran on a fresh mob (its provisional id in `Mob::id`);
    /// the spawn data's `equipment`.
    Finalized(Mob, Option<Tag>),
    /// A mob loaded from the spawn data (with its passengers) and its
    /// `equipment`; the provisional id its events carry.
    Loaded(Tag, Option<Tag>, u32),
}

/// What the spawner code keeps between ticks.
#[derive(Default)]
pub(super) struct SpawnerState {
    /// Every entity type id (`EntityType.byString`), read once.
    entity_types: Option<HashSet<String>>,
    /// The mob shown in each spawner and the id it was made for
    /// (`getOrCreateDisplayEntity`).
    displays: HashMap<Pos, (String, Mob)>,
}

impl Game<'_> {
    /// `EntityType.byString`: the type is in the registry.
    pub(super) fn entity_type_exists(&self, id: &str) -> bool {
        self.spawners
            .entity_types
            .as_ref()
            .is_some_and(|t| t.contains(id))
    }
    /// Whether `entity_type_exists` has a registry to answer from.
    pub(super) fn entity_types_loaded(&self) -> bool {
        self.spawners
            .entity_types
            .as_ref()
            .is_some_and(|t| !t.is_empty())
    }
    pub(super) fn load_entity_types(&mut self) {
        if self.spawners.entity_types.is_some() {
            return;
        }
        let path = self.options.resources.join("entity-types.json");
        let types = std::fs::read(path)
            .ok()
            .and_then(|b| serde_json::from_slice::<serde_json::Value>(&b).ok())
            .and_then(|v| {
                v.as_object().map(|o| {
                    o.keys()
                        .map(|k| horizon_client::command::args::normalize(k))
                        .collect()
                })
            })
            .unwrap_or_default();
        self.spawners.entity_types = Some(types);
    }
    /// The server tick of the spawner at `key`. Its client tick comes after
    /// every block entity's (`client_tick_spawners`).
    ///
    /// The caller only reaches this for a `BlockEntity::Spawner`, and changing
    /// the block removes or replaces that entity, so the block is not read
    /// again here.
    pub(super) fn tick_spawner(&mut self, key: Pos) -> Result<()> {
        let Some((lease, BlockEntity::Spawner(mut spawner))) = self.world.block_entities.take(&key)
        else {
            return Ok(());
        };
        let result = self.server_tick_spawner(key, &mut spawner);
        self.world
            .block_entities
            .put(lease, BlockEntity::Spawner(spawner));
        result
    }
    /// The client ticks of these spawners, then the shown mobs of spawners
    /// that are gone go.
    pub(super) fn client_tick_spawners(&mut self, keys: &[Pos]) {
        for &key in keys {
            self.client_tick_spawner(key);
        }
        let entities = &self.world.block_entities;
        self.spawners.displays.retain(|k, _| {
            matches!(
                entities.get(k),
                Some(BlockEntity::Spawner(_) | BlockEntity::TrialSpawner(_))
            )
        });
    }
    fn server_tick_spawner(&mut self, key: Pos, spawner: &mut Spawner) -> Result<()> {
        self.server_tick_spawner_of(key, spawner, None)
    }
    /// `BaseSpawner.serverTick` at `key`: a spawner block's, or the spawner minecart
    /// `cart` is at (its `broadcastEvent` is an entity event on the cart).
    pub(super) fn server_tick_spawner_of(
        &mut self,
        key: Pos,
        spawner: &mut Spawner,
        cart: Option<u32>,
    ) -> Result<()> {
        // `BaseSpawner.serverTick` does nothing without an alive player in
        // range (`isNearPlayer`) or with the rule off: no level to build for it.
        let at = [key.0, key.1, key.2].map(|c| f64::from(c) + 0.5);
        let range = f64::from(spawner.required_player_range);
        if !self.alive_player_near(at[0], at[1], at[2], range)
            || !self
                .ui
                .rules
                .bool_at(horizon_client::gamerules::vanilla::SPAWNER_BLOCKS_WORK)
        {
            return Ok(());
        }
        // While its delay counts down, `serverTick` only takes one off it: no
        // level, random or event (a server with hundreds of dungeons near its
        // players built the level for every one of them, every tick).
        if spawner.spawn_delay > 0 {
            spawner.spawn_delay -= 1;
            return Ok(());
        }
        let pos = [key.0, key.1, key.2];
        let mut random = std::mem::replace(
            &mut self.world.random,
            horizon_core::random::LegacyRandom::new(0),
        );
        let mut events = Vec::new();
        let mut planned: Vec<Planned> = Vec::new();
        // A minecart spawner has no block.
        let source = cart
            .is_none()
            .then(|| mod_api::SpawnSource::Block(mod_api::BlockPos::new(key.0, key.1, key.2)));
        let extras = {
            let mut level = self.natural_level();
            // A minecart spawner has no block to tell the spawn checks of.
            level.spawner = cart.is_none().then_some(mod_api::Spawner::Block {
                pos: mod_api::BlockPos::new(key.0, key.1, key.2),
            });
            let mut spawn = |l: &super::natural_spawning::GameLevel,
                             r: &SpawnerSpawn,
                             rng: &mut LegacyRandom| {
                l.game.plan_spawner_mob(l, r, source, &mut planned, rng)
            };
            spawner.server_tick(&level, &mut random, pos, &mut spawn, &mut events);
            (
                std::mem::take(&mut *level.spawned.borrow_mut()),
                std::mem::take(&mut *level.rides.borrow_mut()),
            )
        };
        self.world.random = random;
        let (created, rides) = extras;
        let ids = self.add_planned(planned, created, rides);
        self.apply_spawner_events(key, events, &ids, cart)
    }
    /// Creates the mobs a spawner tick planned; their provisional ids
    /// (counting down from u32::MAX) map to the mobs' ids.
    /// (counting down from `u32::MAX`) map to the mobs' ids.
    pub(super) fn add_planned(
        &mut self,
        planned: Vec<Planned>,
        mut created: Vec<Mob>,
        rides: Vec<(u32, u32)>,
    ) -> HashMap<u32, u32> {
        let _save_lease = horizon_client::join_seq::visibility::PassLease::enter();
        let mut finalized: Vec<Mob> = Vec::new();
        let mut gears: Vec<Option<Tag>> = Vec::new();
        let mut loads: Vec<(Tag, Option<Tag>, u32)> = Vec::new();
        for plan in planned {
            match plan {
                Planned::Finalized(mob, equipment) => {
                    finalized.push(mob);
                    gears.push(equipment);
                }
                Planned::Loaded(tag, equipment, key) => loads.push((tag, equipment, key)),
            }
        }
        // Real ids for finalizeSpawn's provisional mobs, in spawn order, the
        // links that ride by id rewritten after them: the map the spawner's
        // events resolve their provisional ids with.
        let mut ids = self.resolve_spawn_ids([&mut finalized, &mut created], &rides);
        for (mob, equipment) in finalized.into_iter().zip(gears) {
            let id = mob.id;
            let i = self.mobs.len();
            self.mobs.push(mob);
            self.native_mobs_joined(i, false);
            // `nextSpawnData.getEquipment().ifPresent(mob::equip)`.
            if let Some(table) = equipment {
                self.equip_from_table(id, &table);
            }
        }
        for mob in created {
            let i = self.mobs.len();
            self.mobs.push(mob);
            self.native_mobs_joined(i, false);
        }
        for (tag, equipment, key) in loads {
            if let Some(id) = self.load_mob(tag, None) {
                // `nextSpawnData.getEquipment().ifPresent(mob::equip)`.
                if let Some(table) = equipment {
                    self.equip_from_table(id, &table);
                }
                ids.insert(key, id);
            }
        }
        ids
    }
    /// The spawner's `loadEntityRecursive` and `tryAddFreshEntityWithPassengers`:
    /// the mob it will add (created after the tick) and its box.
    pub(super) fn plan_spawner_mob(
        &self,
        l: &super::natural_spawning::GameLevel,
        r: &SpawnerSpawn,
        source: Option<mod_api::SpawnSource>,
        planned: &mut Vec<Planned>,
        random: &mut horizon_core::random::LegacyRandom,
    ) -> Option<SpawnerAdded> {
        let kind = self.res.mob_types().get(r.id)?.clone();
        let [x, y, z] = r.position;
        let at = Vec3::new(x, y, z);
        let (bounds, key) = if r.finalize {
            // The mob a listened position check created, else a new one.
            let mut mob = l
                .take_checked(r.id, r.position, r.yaw)
                .unwrap_or_else(|| Mob::new(l.provisional_id(), kind, at, r.yaw));
            let reason = if r.trial {
                SpawnReason::TrialSpawner
            } else {
                SpawnReason::Spawner
            };
            // TrialSpawner.spawnMob: setPersistenceRequired.
            mob.persistent = r.trial;
            let mut group = None;
            match self.finalize_spawn_event(&mut mob, reason, source, &mut group) {
                (Finalized::Cancelled, _) => return None,
                (outcome, difficulty) => {
                    if outcome == Finalized::Done {
                        let mut level = super::natural_spawning::PassLevel::new(l);
                        let mut cx = horizon_client::mobs::finalize::Ctx {
                            level: &mut level,
                            random,
                            difficulty,
                            created: Vec::new(),
                            jockey_rider: None,
                        };
                        horizon_client::mobs::finalize::finalize(&mut cx, &mut mob, reason, group);
                        for m in cx.created {
                            let bounds = m.bounds();
                            l.pending.borrow_mut().push(bounds);
                            l.pending_ids.borrow_mut().push((m.kind.id.clone(), bounds));
                            l.spawned.borrow_mut().push(m);
                        }
                    }
                }
            }
            // Shulker.finalizeSpawn faces it south.
            if mob.species() == horizon_client::mobs::Species::Shulker {
                mob.yaw = 0.0;
                mob.previous_yaw = 0.0;
                mob.body_yaw = 0.0;
                mob.previous_body_yaw = 0.0;
                mob.head_yaw = 0.0;
                mob.previous_head_yaw = 0.0;
            }
            let bounds = mob.bounds();
            let key = mob.id;
            planned.push(Planned::Finalized(mob, r.equipment.cloned()));
            (bounds, key)
        } else {
            // A UUID already in the level is refused.
            let mut tag = r.entity.clone();
            if let Some(uuid) = horizon_client::entity_nbt::uuid(&Tag::Compound(tag.clone()))
                && self.persist.uuids.values().any(|u| *u == uuid)
            {
                return None;
            }
            let double = |v: f64| Tag::Double(v.to_bits());
            tag.insert(
                "Pos".into(),
                Tag::List(vec![double(x), double(y), double(z)]),
            );
            tag.insert(
                "Rotation".into(),
                Tag::List(vec![
                    Tag::Float(r.yaw.to_bits()),
                    Tag::Float(0f32.to_bits()),
                ]),
            );
            if r.trial {
                tag.insert("PersistenceRequired".into(), Tag::Byte(1));
            }
            let mut tag = Tag::Compound(tag);
            // EntityType.loadEntityRecursive applies the spawner's placement
            // callback to every passenger as well as the root.
            super::commands::place_summoned(&mut tag, r.position);
            let mob = horizon_client::entity_nbt::mob_from_nbt(
                &tag,
                self.res.mob_types(),
                0,
                Some(self.pack.assets.registry),
            )?;
            let bounds = mob.bounds();
            let key = l.provisional_id();
            planned.push(Planned::Loaded(tag, r.equipment.cloned(), key));
            (bounds, key)
        };
        l.pending.borrow_mut().push(bounds);
        l.pending_ids.borrow_mut().push((r.id.to_owned(), bounds));
        Some(SpawnerAdded {
            id: key,
            bounds,
            mob: true,
        })
    }
    /// What a spawner's tick or a spawn egg did, shown and sent.
    fn apply_spawner_events(
        &mut self,
        key: Pos,
        events: Vec<SpawnerEvent>,
        ids: &HashMap<u32, u32>,
        cart: Option<u32>,
    ) -> Result<()> {
        let pos = [key.0, key.1, key.2];
        for event in events {
            match event {
                // A cart has no block to update: `sendBlockUpdated` finds nothing to send.
                SpawnerEvent::BlockUpdated if cart.is_some() => {}
                SpawnerEvent::BlockUpdated => self.spawner_block_updated(key),
                // `broadcastEvent`: `level.broadcastEntityEvent(cart, id)`.
                SpawnerEvent::BlockEvent(id) if cart.is_some() => {
                    let at = pos.map(|c| f64::from(c) + 0.5);
                    self.lan_entity_event(cart.unwrap_or_default() as i32, id as i8, at);
                }
                SpawnerEvent::BlockEvent(id) => {
                    self.lan_block_event(pos, id, 0);
                    // The client copy's onEventTriggered.
                    if let Some(BlockEntity::Spawner(s)) = self.world.block_entities.get_mut(&key) {
                        s.client_event(id);
                    }
                }
                SpawnerEvent::LevelEvent(id) => self.level_event_at(id, pos, 0),
                SpawnerEvent::EntityPlace(mob, at) => {
                    let who = ids.get(&mob).map(|id| Who::Mob(*id));
                    self.post_block_game_event("minecraft:entity_place", at, who, None);
                }
                SpawnerEvent::SpawnAnim(mob) => {
                    if let Some(id) = ids.get(&mob) {
                        self.mob_poof(*id);
                    }
                }
            }
        }
        Ok(())
    }
    /// `sendBlockUpdated`: the clients load the new update tag (the client
    /// copy's delay follows it, its display mob is made again).
    fn spawner_block_updated(&mut self, key: Pos) {
        if let Some(BlockEntity::Spawner(s)) = self.world.block_entities.get_mut(&key) {
            s.client_loaded();
        }
        self.spawners.displays.remove(&key);
        if let Some(log) = self.world.block_log.as_mut() {
            log.push(key);
        }
        self.world.modified.insert((key.0 >> 4, key.2 >> 4));
    }
    /// `LivingEntity.makePoofParticles` (entity event 20) for a mob.
    pub(super) fn mob_poof(&mut self, id: u32) {
        let Some(m) = self.mobs.iter().find(|m| m.id == id) else {
            return;
        };
        let at = m.position;
        self.lan_entity_event(id as i32, 20, [at.x, at.y, at.z]);
        self.poof_particles(id);
    }
    /// `Mob.handleEntityEvent` 20 (`spawnAnim` on a client): the poof about
    /// mob `id`.
    pub(super) fn poof_particles(&mut self, id: u32) {
        let Some(m) = self.mobs.iter().find(|m| m.id == id) else {
            return;
        };
        let (at, w, h) = (m.position, f64::from(m.width()), f64::from(m.height()));
        let options = ParticleOptions::simple(ParticleType::Poof);
        for _ in 0..20 {
            let r = self.particles.level_random();
            let xa = r.next_gaussian() * 0.02;
            let ya = r.next_gaussian() * 0.02;
            let za = r.next_gaussian() * 0.02;
            let x = at.x + w * (2.0 * r.next_double() - 1.0) - xa * 10.0;
            let y = at.y + h * r.next_double() - ya * 10.0;
            let z = at.z + w * (2.0 * r.next_double() - 1.0) - za * 10.0;
            self.particles.add(&options, [x, y, z], [xa, ya, za]);
        }
    }
    /// `LevelEventHandler` 2004: twenty smoke and flame pairs around the spawner.
    pub(super) fn spawner_burst(&mut self, pos: [i32; 3]) {
        let (smoke, flame) = (
            ParticleOptions::simple(ParticleType::Smoke),
            ParticleOptions::simple(ParticleType::Flame),
        );
        for _ in 0..20 {
            let r = self.particles.level_random();
            let x = f64::from(pos[0]) + 0.5 + (r.next_double() - 0.5) * 2.0;
            let y = f64::from(pos[1]) + 0.5 + (r.next_double() - 0.5) * 2.0;
            let z = f64::from(pos[2]) + 0.5 + (r.next_double() - 0.5) * 2.0;
            self.particles.add(&smoke, [x, y, z], [0.0; 3]);
            self.particles.add(&flame, [x, y, z], [0.0; 3]);
        }
    }
    /// The client copy's tick: particles and the spin while a player is near.
    fn client_tick_spawner(&mut self, key: Pos) {
        let near = {
            let Some(BlockEntity::Spawner(s)) = self.world.block_entities.get(&key) else {
                return;
            };
            let range = f64::from(s.required_player_range);
            let center = [
                f64::from(key.0) + 0.5,
                f64::from(key.1) + 0.5,
                f64::from(key.2) + 0.5,
            ];
            self.player.as_ref().is_some_and(|p| {
                let d = (p.position.x - center[0]).powi(2)
                    + (p.position.y - center[1]).powi(2)
                    + (p.position.z - center[2]).powi(2);
                !p.health.dead_or_dying() && !self.spectator() && (range < 0.0 || d < range * range)
            })
        };
        let display = self.update_spawner_display(key);
        let pos = [key.0, key.1, key.2];
        let random = self.particles.level_random();
        let Some(BlockEntity::Spawner(s)) = self.world.block_entities.get_mut(&key) else {
            return;
        };
        if let Some(p) = s.client_tick(near, display, random, pos) {
            self.particles
                .add(&ParticleOptions::simple(ParticleType::Smoke), p, [0.0; 3]);
            self.particles
                .add(&ParticleOptions::simple(ParticleType::Flame), p, [0.0; 3]);
        }
    }
    /// `getOrCreateDisplayEntity`: the mob shown in the spawner, made again
    /// when its type changes. False when there is none.
    pub(super) fn update_spawner_display(&mut self, key: Pos) -> bool {
        let Some(kind) = self.spawner_display_kind(key) else {
            self.spawners.displays.remove(&key);
            return false;
        };
        if self
            .spawners
            .displays
            .get(&key)
            .is_none_or(|(k, _)| *k != kind)
        {
            let Some(t) = self.res.mob_types().get(&kind).cloned() else {
                return false;
            };
            let mob = Mob::new(u32::MAX, t, Vec3::ZERO, 0.0);
            self.spawners.displays.insert(key, (kind, mob));
        }
        true
    }
    /// The type of the mob a spawner shows: its next data's id, when the game
    /// knows the mob.
    /// A trial spawner shows one only in the states with a spinning mob.
    fn spawner_display_kind(&self, key: Pos) -> Option<String> {
        let id = match self.world.block_entities.get(&key)? {
            BlockEntity::Spawner(s) => s.next_data()?.id()?,
            BlockEntity::TrialSpawner(s) => {
                self.trial_spawner_block(key)?.0.spinning_mob_speed()?;
                s.next_spawn_data.as_ref()?.id()?
            }
            _ => return None,
        };
        self.res.mob_types().contains_key(&id).then_some(id)
    }
    /// `SpawnEggItem.useOn` on a spawner: the egg sets its mob, and an op's
    /// egg its entity `data` too (`block_entity_item::spawn_egg_on_spawner`).
    /// None when the clicked block has no spawner.
    pub(super) fn use_spawn_egg_on_spawner(
        &mut self,
        pos: [i32; 3],
        kind: &str,
        data: Option<&horizon_core::nbt::Compound>,
    ) -> Option<bool> {
        let key = (pos[0], pos[1], pos[2]);
        let trial = match self.world.block_entities.get(&key) {
            Some(BlockEntity::Spawner(_)) => false,
            Some(BlockEntity::TrialSpawner(_)) => true,
            _ => return None,
        };
        if !self
            .ui
            .rules
            .bool_at(horizon_client::gamerules::vanilla::SPAWNER_BLOCKS_WORK)
        {
            self.system_message(horizon_client::text::Text::translate(
                "advMode.notEnabled.spawner",
                &[],
            ));
            return Some(false);
        }
        if trial {
            // TrialSpawnerBlockEntity.setEntityId and setEntityData:
            // overrideEntityToSpawn, which ends in setState(INACTIVE).
            if let Some(BlockEntity::TrialSpawner(t)) = self.world.block_entities.get_mut(&key) {
                match data {
                    Some(data) => t.override_entity_data(kind, data),
                    None => t.override_entity(kind),
                }
            }
            let ominous = self.trial_spawner_block(key).is_some_and(|(_, o)| o);
            let _ = self.set_trial_spawner_state(key, TrialState::Inactive, ominous);
        } else {
            let mut events = Vec::new();
            let mut random = std::mem::replace(
                &mut self.world.random,
                horizon_core::random::LegacyRandom::new(0),
            );
            if let Some(BlockEntity::Spawner(s)) = self.world.block_entities.get_mut(&key) {
                match data {
                    Some(data) => s.set_entity_data(kind, data, &mut random, &mut events),
                    None => s.set_entity_id(kind, &mut random, &mut events),
                }
            }
            self.world.random = random;
            let _ = self.apply_spawner_events(key, events, &HashMap::new(), None);
        }
        // sendBlockUpdated(3) and the player's block_change game event.
        self.spawner_block_updated(key);
        self.update_spawner_display(key);
        self.post_block_game_event("minecraft:block_change", pos, Some(Who::Player), None);
        Some(true)
    }
    /// `PlayerList.isOp` for the player acting now: a server's guest by their
    /// own level, else the window's player.
    pub(super) fn acting_player_is_op(&self) -> bool {
        self.lan_acting_permission
            .unwrap_or(self.ui.registries.permission)
            > 0
    }
    /// Ticks spawners, trial spawners and vaults near the player on a remote
    /// client (`tick_remote`).
    pub(super) fn tick_remote_spawners(&mut self) {
        let Some(p) = self.player.as_ref() else {
            return;
        };
        let center = [
            p.position.x.floor() as i32,
            p.position.y.floor() as i32,
            p.position.z.floor() as i32,
        ];
        let (keys, trial_keys, vault_keys) =
            nearby_remote_spawner_keys(&self.world.block_entities, center);
        self.client_tick_spawners(&keys);
        for key in trial_keys {
            self.client_tick_trial_spawner(key);
        }
        // VaultBlock.getTicker on the client: VaultBlockEntity.Client.tick.
        for key in vault_keys {
            self.client_tick_vault(key);
        }
    }
    /// `SpawnerRenderer` and `TrialSpawnerRenderer`: the next mob of every
    /// spawner near the camera, small and turning.
    pub(super) fn spawner_geometry(
        &self,
        camera: glam::DVec3,
        alpha: f64,
        out: &mut Vec<mod_render::render::Vertex>,
    ) {
        let atlas = &self.gui.atlas;
        let lookup = |name: &str| atlas.sprites.get(name).map(|r| [r.u0, r.v0, r.u1, r.v1]);
        // A shader pack's shadow pass draws a block entity only in the sections it draws
        // (`Renderer::shadow_pass_block_entities`, #8464): a spawner's mob out of the view and
        // out of those sections isn't drawn, where it would have gone to the shadow pass alone.
        let shadow_sections = self
            .renderer
            .as_ref()
            .filter(|_| self.pack_ids.is_some() && self.pack_shadow_casters.0);
        for (key, (_, mob)) in &self.spawners.displays {
            let at = glam::DVec3::new(f64::from(key.0), f64::from(key.1), f64::from(key.2));
            if at.distance_squared(camera) >= 64.0 * 64.0 {
                continue;
            }
            if let Some(r) = shadow_sections
                && !r.shadow_pass_drew([key.0, key.1, key.2])
                && self.view_frustum.is_some_and(|v| {
                    let o = (at - camera).as_vec3();
                    !v.intersects(o - glam::Vec3::ONE, o + glam::Vec3::splat(2.0))
                })
            {
                continue;
            }
            let (spin, scale) = match self.world.block_entities.get(key) {
                Some(BlockEntity::Spawner(s)) => {
                    s.display_pose(alpha as f32, mob.width(), mob.height())
                }
                Some(BlockEntity::TrialSpawner(s)) => horizon_client::mobs::spawner::display_pose(
                    s.o_spin,
                    s.spin,
                    alpha as f32,
                    mob.width(),
                    mob.height(),
                ),
                _ => continue,
            };
            let origin = glam::Mat4::from_translation(
                (at - camera).as_vec3() + glam::Vec3::new(0.5, 0.4, 0.5),
            ) * glam::Mat4::from_rotation_y(spin.to_radians())
                * glam::Mat4::from_translation(glam::Vec3::new(0.0, -0.2, 0.0))
                * glam::Mat4::from_rotation_x((-30.0_f32).to_radians())
                * glam::Mat4::from_scale(glam::Vec3::splat(scale));
            let light = self.world.light(key.0, key.1, key.2);
            let packed = (u32::from(light >> 4) * 16) | ((u32::from(light & 15) * 16) << 8);
            if mob.species() == horizon_client::mobs::Species::SulfurCube {
                self.sulfur_cube_body_geometry(
                    mob,
                    alpha as f32,
                    horizon_client::mobs::render::base_transform_at(mob, alpha as f32, origin),
                    packed,
                    out,
                );
            }
            horizon_client::mobs::render::render_posed(
                mob,
                alpha as f32,
                origin,
                &lookup,
                packed,
                self.res.mob_data(),
                out,
            );
        }
    }
}

/// `SpawnerBlockEntity.clientTick` / `BaseSpawner.clientTick`: spawner, trial
/// spawner and vault keys within 64 blocks (Chebyshev distance) of `center`
/// among `entities`. Non-spawner block entities are ignored before distance
/// calculation, and coordinate difference uses `abs_diff` to prevent overflow.
pub(super) fn nearby_remote_spawner_keys<'a>(
    entities: impl IntoIterator<Item = (&'a Pos, &'a BlockEntity)>,
    center: [i32; 3],
) -> (Vec<Pos>, Vec<Pos>, Vec<Pos>) {
    let mut keys = Vec::new();
    let mut trial_keys = Vec::new();
    let mut vault_keys = Vec::new();
    for (&pos, be) in entities {
        let target = match be {
            BlockEntity::Spawner(_) => &mut keys,
            BlockEntity::TrialSpawner(_) => &mut trial_keys,
            BlockEntity::Vault(_) => &mut vault_keys,
            _ => continue,
        };
        let d = pos
            .0
            .abs_diff(center[0])
            .max(pos.1.abs_diff(center[1]))
            .max(pos.2.abs_diff(center[2]));
        if d <= 64 {
            target.push(pos);
        }
    }
    (keys, trial_keys, vault_keys)
}

#[cfg(test)]
mod tests {
    use super::*;

    /// `BaseSpawner.serverTick` with a player in range: a running delay only
    /// goes down by one a tick, drawing nothing from the level random and
    /// adding no mob. At 0 the spawn runs: with nothing to spawn it calls
    /// `delay`, which draws the next delay in [MinSpawnDelay, MaxSpawnDelay).
    #[test]
    #[ignore = "needs prepared resources (HORIZON_TEST_RESOURCES)"]
    fn a_running_delay_counts_down_without_drawing() {
        crate::game::native_entity_refs::tests::with_game(|game| {
            game.options.dedicated = Some(Vec::new());
            game.world.chunks.insert(
                (0, 0),
                std::sync::Arc::new(horizon_client::chunk::Chunk::empty(0, 0)),
            );
            game.player = Some(
                horizon_client::motion::PlayerMotion::new(game.motion, Vec3::new(8.5, 64.0, 8.5))
                    .unwrap(),
            );
            let key = (8, 64, 12);
            let spawner = Spawner {
                spawn_delay: 3,
                ..Spawner::default()
            };
            game.world
                .block_entities
                .insert(key, BlockEntity::Spawner(Box::new(spawner)));
            let delay = |game: &Game<'_>| match game.world.block_entities.get(&key) {
                Some(BlockEntity::Spawner(s)) => s.spawn_delay,
                _ => panic!("the spawner is gone"),
            };
            for expected in [2, 1, 0] {
                let mut before = game.world.random.clone();
                game.tick_spawner(key).unwrap();
                assert_eq!(delay(game), expected);
                assert_eq!(
                    game.world.random.next_long(),
                    before.next_long(),
                    "no draw at delay {expected}"
                );
                assert!(game.mobs.is_empty());
            }
            let mut before = game.world.random.clone();
            game.tick_spawner(key).unwrap();
            assert!((200..800).contains(&delay(game)), "{}", delay(game));
            assert_ne!(game.world.random.next_long(), before.next_long());
        });
    }

    #[test]
    fn dummy_container_at_min_coordinate_does_not_panic_or_tick() {
        let mut entities = HashMap::new();
        // Client dummy container menu placed at (i32::MIN, 0, 0) when remote
        // container lacks target block position (remote.rs:9393).
        entities.insert((i32::MIN, 0, 0), BlockEntity::Chest(Vec::new()));
        entities.insert(
            (i32::MIN, i32::MIN, i32::MIN),
            BlockEntity::Chest(Vec::new()),
        );
        entities.insert(
            (i32::MAX, i32::MAX, i32::MAX),
            BlockEntity::Chest(Vec::new()),
        );

        // Player at x = 1024: (pos.0 - center[0]) would be i32::MIN - 1024.
        let (keys, trial_keys, vault_keys) = nearby_remote_spawner_keys(&entities, [1024, 64, -50]);
        assert!(keys.is_empty());
        assert!(trial_keys.is_empty());
        assert!(vault_keys.is_empty());

        // Player at x = 0: (pos.0 - center[0]) would be i32::MIN - 0, and i32::MIN.abs() panics.
        let (keys, trial_keys, vault_keys) = nearby_remote_spawner_keys(&entities, [0, 0, 0]);
        assert!(keys.is_empty());
        assert!(trial_keys.is_empty());
        assert!(vault_keys.is_empty());
    }

    #[test]
    fn spawner_outside_64_block_chebyshev_range_is_not_ticked() {
        let mut entities = HashMap::new();
        entities.insert((65, 0, 0), BlockEntity::Spawner(Box::default()));
        entities.insert((0, -65, 0), BlockEntity::TrialSpawner(Box::default()));
        entities.insert((0, 0, 65), BlockEntity::Vault(Box::default()));
        entities.insert((-65, 65, -65), BlockEntity::Spawner(Box::default()));

        let (keys, trial_keys, vault_keys) = nearby_remote_spawner_keys(&entities, [0, 0, 0]);
        assert!(
            keys.is_empty(),
            "spawners outside 64 blocks must not be ticked"
        );
        assert!(
            trial_keys.is_empty(),
            "trial spawners outside 64 blocks must not be ticked"
        );
        assert!(
            vault_keys.is_empty(),
            "vaults outside 64 blocks must not be ticked"
        );
    }

    #[test]
    fn spawners_within_64_block_chebyshev_range_are_ticked() {
        let mut entities = HashMap::new();
        let spawner_at_boundary = (164, 64, -200);
        let spawner_near_player = (110, 69, -202);
        let trial_at_boundary = (36, 128, -264); // Chebyshev dx=64, dy=64, dz=64
        let vault_at_center = (100, 64, -200);

        entities.insert(spawner_at_boundary, BlockEntity::Spawner(Box::default()));
        entities.insert(spawner_near_player, BlockEntity::Spawner(Box::default()));
        entities.insert(trial_at_boundary, BlockEntity::TrialSpawner(Box::default()));
        entities.insert(vault_at_center, BlockEntity::Vault(Box::default()));

        let (mut keys, trial_keys, vault_keys) =
            nearby_remote_spawner_keys(&entities, [100, 64, -200]);
        keys.sort_unstable();
        let mut expected_spawners = vec![spawner_at_boundary, spawner_near_player];
        expected_spawners.sort_unstable();

        assert_eq!(keys, expected_spawners);
        assert_eq!(trial_keys, vec![trial_at_boundary]);
        assert_eq!(vault_keys, vec![vault_at_center]);
    }

    #[test]
    fn extreme_coordinate_boundary_does_not_overflow() {
        let mut entities = HashMap::new();
        let max_pos = (i32::MAX, i32::MAX, i32::MAX);
        let min_pos = (i32::MIN, i32::MIN, i32::MIN);
        let in_range_max = (i32::MAX, 10, -5);

        entities.insert(max_pos, BlockEntity::Spawner(Box::default()));
        entities.insert(min_pos, BlockEntity::Spawner(Box::default()));
        entities.insert(in_range_max, BlockEntity::Spawner(Box::default()));

        // Player at i32::MIN: distance to i32::MAX would overflow signed 32-bit arithmetic.
        let (keys, _, _) = nearby_remote_spawner_keys(&entities, [i32::MIN, i32::MIN, i32::MIN]);
        assert_eq!(keys, vec![min_pos]);

        // Player at i32::MAX: distance to i32::MIN would overflow signed 32-bit arithmetic.
        let (keys, _, _) = nearby_remote_spawner_keys(&entities, [i32::MAX, i32::MAX, i32::MAX]);
        assert_eq!(keys, vec![max_pos]);

        // Player at i32::MAX - 64: in_range_max should be included.
        let (keys, _, _) = nearby_remote_spawner_keys(&entities, [i32::MAX - 64, 10, -5]);
        assert!(keys.contains(&in_range_max));
    }
}
