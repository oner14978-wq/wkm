//! Allays on the game side: spotting and picking up matching drops,
//! throwing their load to the player or note block, dancing to jukeboxes,
//! and the hand-over interaction (`Allay.mobInteract`).
use super::Game;
use super::level_sounds::LevelSound;
use horizon_client::{
    containers::BlockEntity,
    first_person::Hand,
    items::ItemStack,
    mobs::{Species, allay},
};
use horizon_core::random::RandomSource;
use mod_api::SoundSource;

impl Game<'_> {
    /// `Allay.mobInteract`'s `level().playSound(player, this, sound, NEUTRAL,
    /// 2, 1)`, bound to allay `allay`. Vanilla leaves the player out because
    /// their client played it; Horizon's own client plays it from the
    /// packet, so every player gets it.
    fn play_allay_sound(&mut self, sound: &str, at: [f64; 3], allay: u32) {
        let sound = LevelSound::new(sound, at, 2.0, 1.0).in_source(SoundSource::Neutral);
        self.play_bound_sound(sound, allay, None);
    }
    /// The client's `Allay.mobInteract` runs before the server's response.
    /// Whether `predict_allay_interaction` would act, on a copy of the allay.
    pub(super) fn allay_would_take(
        &self,
        index: usize,
        hand: Hand,
        offered: Option<ItemStack>,
    ) -> bool {
        let duplicates = offered.as_ref().is_some_and(|s| {
            self.items()
                .item_tags
                .get("minecraft:duplicates_allays")
                .is_some_and(|tag| tag.contains(&*s.item))
        });
        allay::interaction::predict(
            &mut self.mobs[index].clone(),
            offered.as_ref(),
            hand == Hand::Main,
            duplicates,
            self.acting_uuid(),
        )
        .is_some()
    }

    pub(super) fn predict_allay_interaction(
        &mut self,
        index: usize,
        hand: Hand,
        offered: Option<ItemStack>,
    ) -> bool {
        use allay::interaction::{Interaction, predict};
        let duplicates = offered.as_ref().is_some_and(|s| {
            self.items()
                .item_tags
                .get("minecraft:duplicates_allays")
                .is_some_and(|tag| tag.contains(&*s.item))
        });
        let actor = self.acting_uuid();
        let Some(result) = predict(
            &mut self.mobs[index],
            offered.as_ref(),
            hand == Hand::Main,
            duplicates,
            actor,
        ) else {
            return false;
        };
        self.play_mob_bound_sound(index, result.sound(), 6, 2.0, 1.0, false);
        match result {
            Interaction::Duplicate | Interaction::Give => {
                self.with_hand(hand, Self::consume_held);
            }
            Interaction::Take(stack) => {
                // Player.addItem returns leftovers on the client without
                // spawning an item entity; the server owns any dropped stack.
                let _ = self.add_stack_to_inventory(stack);
            }
        }
        true
    }

    pub(super) fn tick_allays(&mut self) {
        let griefing = self
            .ui
            .rules
            .bool_at(horizon_client::gamerules::vanilla::MOB_GRIEFING);
        // The playing jukeboxes, found at the first allay: no allay starts
        // or stops one, and the block entities run into the thousands.
        let mut jukeboxes: Option<Vec<(i32, i32, i32)>> = None;
        for i in 0..self.mobs.len() {
            if self.mobs[i].species() != Species::Allay
                || !self.mobs[i].alive()
                || !self.creatures.ticked.contains(&self.mobs[i].id)
            {
                continue;
            }
            let pos = self.mobs[i].position;
            // Dancing: a playing jukebox within 10 blocks.
            let jukeboxes = jukeboxes.get_or_insert_with(|| {
                self.world
                    .block_entities
                    .iter()
                    .filter(|(_, e)| matches!(e, BlockEntity::Jukebox(j) if j.playing))
                    .map(|(k, _)| *k)
                    .collect()
            });
            let nearest = jukeboxes
                .iter()
                .map(|k| {
                    (f64::from(k.0) + 0.5 - pos.x).powi(2)
                        + (f64::from(k.1) + 0.5 - pos.y).powi(2)
                        + (f64::from(k.2) + 0.5 - pos.z).powi(2)
                })
                .fold(f64::INFINITY, f64::min);
            // `Allay.setDancing` wants effective AI: a `NoAI` allay never dances.
            let panicking = horizon_client::mobs::goals::should_panic(&self.mobs[i]);
            self.mobs[i].extra.flag = allay::dances(self.mobs[i].no_ai, panicking, nearest);
            let Some(held) = self.mobs[i].extra.main_hand_stack().cloned() else {
                self.mobs[i].extra.point = None;
                continue;
            };
            // The held filter chooses item types; the pocket independently
            // decides whether the candidate's full components can fit.
            // `Mob.aiStep`'s looting loop asks for no AI: `canPickUpLoot` and
            // mob_griefing are its gates, the latter through `entity_grief`.
            let wants =
                self.mobs[i].can_pick_up_loot() && self.entity_grief(self.mobs[i].id, griefing);
            let room = |stack: &ItemStack| {
                self.mobs[i].extra.allay.as_ref().map_or(0, |st| {
                    st.room(stack, self.mobs[i].kind.inventory_stack_limit(stack))
                })
            };
            let reach = allay::pickup_reach(self.mobs[i].bounds());
            // GoToWantedItem: a stack it considers equal within 32 that the
            // allay sees (NearestItemSensor's hasLineOfSight, eye to eye). The
            // sensor is the brain's, so without AI only `Mob.aiStep`'s looting
            // loop runs: it takes an equal drop already in `getPickupReach`.
            let wanted = if !wants {
                None
            } else if self.mobs[i].no_ai {
                self.dropped.iter().position(|e| {
                    e.pickup_delay == 0
                        && allay::considers_item_equal(&held, &e.stack)
                        && room(&e.stack) > 0
                        && reach.contains(e.position)
                })
            } else {
                let w = self.mob_world_base(&[]);
                let eye = horizon_core::geometry::Vec3::new(pos.x, self.mobs[i].eye_y(), pos.z);
                // The sensor looks in the allay's box grown by (32, 16, 32).
                let b = self.mobs[i].bounds();
                let (low, high) = (b.min_position().y - 16.0, b.max_position().y + 16.0);
                self.dropped
                    .iter()
                    .enumerate()
                    .filter(|(_, e)| {
                        e.pickup_delay == 0
                            && allay::considers_item_equal(&held, &e.stack)
                            && room(&e.stack) > 0
                    })
                    .map(|(j, e)| (j, e.position.distance_squared(pos)))
                    .filter(|(_, d)| *d < 32.0 * 32.0)
                    .filter(|(j, _)| {
                        let y = self.dropped[*j].position.y;
                        y <= high && y + 0.25 >= low
                    })
                    .filter(|(j, _)| {
                        // ItemEntity's eye height is 0.2125.
                        let e = &self.dropped[*j];
                        let at = horizon_core::geometry::Vec3::new(
                            e.position.x,
                            e.position.y + 0.2125,
                            e.position.z,
                        );
                        w.line_of_sight(eye, at)
                    })
                    .min_by(|a, b| a.1.total_cmp(&b.1))
                    .map(|(j, _)| j)
            };
            let Some(j) = wanted else {
                self.mobs[i].extra.point = None;
                // `GiveInventoryToLookTargetPlayer` is the brain's too.
                if !self.mobs[i].no_ai {
                    self.allay_deliver(i);
                }
                continue;
            };
            let e = &self.dropped[j];
            if reach.contains(e.position) {
                let (item, id) = (e.clone(), self.mobs[i].id);
                let max = self.mobs[i].kind.inventory_stack_limit(&e.stack);
                let take = self.mobs[i]
                    .extra
                    .allay
                    .as_mut()
                    .unwrap()
                    .add(e.stack.clone(), max);
                self.add_pickup(
                    super::pickups::Taken::Item(Box::new(item)),
                    super::pickups::Collector::Mob(id),
                );
                let e = &mut self.dropped[j];
                e.stack.count -= take;
                if e.stack.count == 0 {
                    self.remove_dropped(j);
                }
                let at = [pos.x, pos.y, pos.z];
                let pitch =
                    (self.world.random.next_float() - self.world.random.next_float()) * 1.4 + 2.0;
                self.audio
                    .play("minecraft:entity.item.pickup", Some(at), 0.2, pitch);
                self.mobs[i].extra.point = None;
            } else {
                self.mobs[i].extra.point = Some([e.position.x, e.position.y, e.position.z]);
            }
        }
    }
    /// The UUID of the player an allay likes (`LIKED_PLAYER`).
    fn allay_liked_uuid(&self, i: usize) -> [i32; 4] {
        // An allay saved before its player was kept belongs to the host.
        self.mobs[i]
            .extra
            .owner
            .filter(|u| *u != [0, 0, 0, 1])
            .or(self.level.player_uuid)
            .unwrap_or([0, 0, 0, 1])
    }
    /// `AllayAi.getLikedPlayer`: the player the allay was given an item by,
    /// found by UUID among the host and the guests of the level (the window
    /// is a guest on the server thread), when they are not a spectator and
    /// within 64 blocks.
    fn allay_liked_player(&self, i: usize) -> Option<horizon_core::geometry::Vec3> {
        let m = &self.mobs[i];
        if !m.extra.tame {
            return None;
        }
        let uuid = self.allay_liked_uuid(i);
        let host = self
            .player_view()
            .filter(|p| !p.spectator && self.level.player_uuid.unwrap_or([0, 0, 0, 1]) == uuid)
            .map(|p| (p.position, p.eye));
        let found = host.or_else(|| {
            self.lan_present()
                .into_iter()
                .find(|p| p.uuid == uuid && !p.spectator)
                .map(|p| {
                    (
                        horizon_core::geometry::Vec3::new(
                            p.position[0],
                            p.position[1],
                            p.position[2],
                        ),
                        p.eye,
                    )
                })
        });
        // The 64-block search uses the feet; the deposit point is the eyes
        // (`new EntityTracker(player, true)`).
        found
            .filter(|(feet, _)| feet.distance_squared(m.position) < 64.0 * 64.0)
            .map(|(_, eye)| horizon_core::geometry::Vec3::new(eye[0], eye[1], eye[2]))
    }
    /// `GoAndGiveItemsToTarget` / `AllayAi.throwItem`: within 3 blocks of
    /// the deposit, one item a tick, each restarting the three-second pause
    /// before it picks anything up again.
    fn allay_deliver(&mut self, i: usize) {
        let m = &self.mobs[i];
        if allay::inventory(m).is_none() {
            return;
        }
        // AllayAi.getItemDepositPosition: the liked note block, else the player.
        let dimension = self.dim.id();
        let noteblock = allay::noteblock_deposit(&mut self.mobs[i], dimension, |p| {
            &*self
                .res
                .facts()
                .get(self.world.block(p[0], p[1], p[2]))
                .name
                == "minecraft:note_block"
        });
        let player = self.allay_liked_player(i);
        let m = &self.mobs[i];
        let target = match noteblock {
            Some(p) => horizon_core::geometry::Vec3::new(p[0], p[1], p[2]),
            None => match player.filter(|_| m.extra.tame) {
                Some(p) => p,
                None => return,
            },
        };
        let eye = horizon_core::geometry::Vec3::new(m.position.x, m.eye_y(), m.position.z);
        if target.distance_squared(eye) >= 9.0 {
            return;
        }
        let Some(item) = allay::inventory(m).cloned() else {
            return;
        };
        let from = [
            m.position.x,
            m.position.y + m.eye_height() - 0.2,
            m.position.z,
        ];
        // BehaviorUtils.throwItem: the vector runs from the allay's feet.
        let d = [
            target.x - m.position.x,
            target.y + 1.0 - m.position.y,
            target.z - m.position.z,
        ];
        let len = (d[0] * d[0] + d[1] * d[1] + d[2] * d[2]).sqrt().max(1e-6);
        let v = [d[0] / len * 0.2, d[1] / len * 0.3, d[2] / len * 0.2];
        // AllayAi.throwItem: the liked player hears of the block below the deposit.
        let below = [
            target.x.floor() as i32,
            (target.y - 1.0).floor() as i32,
            target.z.floor() as i32,
        ];
        let uuid = self.allay_liked_uuid(i);
        // AllayAi.throwItem: one item of the pocket stack, its components and all.
        let stack = ItemStack { count: 1, ..item };
        self.for_each_player(|g| {
            if g.acting_uuid() == uuid && !g.spectator() {
                g.trigger_block("minecraft:allay_drop_item_on_block", below, &stack);
            }
        });
        let m = &mut self.mobs[i];
        m.extra.allay.as_mut().unwrap().take(1);
        m.extra.ints[3] = 60;
        // ItemEntity.setDefaultPickUpDelay.
        self.spawn_item(stack, from, v, 10);
        // BehaviorUtils.throwItem: ItemEntity.setThrower(the allay).
        let allay = self.mob_uuid(self.mobs[i].id);
        if let Some(thrown) = self.just_spawned_item() {
            thrown.thrower = Some(allay);
        }
        if self.world.game_time % 7 == 0 && self.world.random.next_double() < 0.9 {
            const PITCHES: [f32; 16] = [
                0.5625, 0.625, 0.75, 0.9375, 1.0, 1.0, 1.125, 1.25, 1.5, 1.875, 2.0, 2.25, 2.5,
                3.0, 3.75, 4.0,
            ];
            let pitch = PITCHES[self.world.random.next_int_bound(16).unwrap_or(4) as usize];
            self.play_mob_bound_sound(
                i,
                "minecraft:entity.allay.item_thrown",
                6,
                1.0,
                pitch,
                false,
            );
        }
    }
    /// `Allay.mobInteract`: duplicate when dancing with an amethyst shard,
    /// take the held item, or hand back what it holds.
    pub(super) fn interact_allay(&mut self, index: usize, item: Option<&ItemStack>) -> bool {
        let m = &self.mobs[index];
        if m.species() != Species::Allay || !m.alive() {
            return false;
        }
        let at = [m.position.x, m.position.y, m.position.z];
        let shard = item.is_some_and(|s| {
            self.items()
                .item_tags
                .get("minecraft:duplicates_allays")
                .is_some_and(|tag| tag.contains(&*s.item))
        });
        if m.extra.flag && shard && m.extra.egg_time == 0 {
            let pos = at;
            self.mobs[index].extra.egg_time = 6000;
            if let Some(id) = self.spawn_mob_raw("minecraft:allay", pos, true)
                && let Some(c) = self.mobs.iter_mut().find(|m| m.id == id)
            {
                c.extra.egg_time = 6000;
            }
            // Allay.duplicateAllay: entity event 18, three spawnHeartParticle.
            let id = self.mobs[index].id;
            self.mob_event_particles(id, 18);
            self.play_allay_sound("minecraft:block.amethyst_block.chime", at, id);
            self.consume_held();
            return true;
        }
        let acting = self.acting_uuid();
        let holds = m.extra.main_hand_id().is_some();
        if !holds && let Some(mut given) = item.cloned() {
            let m = &mut self.mobs[index];
            // `Allay.mobInteract` hands over one item, its components and all.
            given.count = 1;
            m.extra.set_main_hand_stack(Some(given));
            // `Allay.mobInteract` remembers LIKED_PLAYER by UUID.
            allay::like_player(m, acting);
            let id = m.id;
            self.play_allay_sound("minecraft:entity.allay.item_given", at, id);

            self.consume_held();
            return true;
        }
        // Allay.mobInteract takes the item back only through an empty main hand.
        if holds && item.is_none() && self.hand == Hand::Main {
            let m = &mut self.mobs[index];
            // The hand's stack keeps the components (a potion) the items came with.
            let held = m
                .extra
                .main_hand_stack()
                .cloned()
                .unwrap_or_else(|| ItemStack::new("minecraft:air", 1));
            m.extra.set_main_hand(None);
            let carried = m.extra.allay.as_mut().and_then(|st| st.inventory.take());
            allay::forget_liked_player(m);
            let id = m.id;
            self.play_allay_sound("minecraft:entity.allay.item_taken", at, id);

            // Allay.mobInteract ends with swing(MAIN_HAND, ...).
            self.mobs[index].swing();
            if let Some(stack) = carried {
                self.spawn_item(stack, at, [0.0, 0.2, 0.0], 40);
            }
            if let Some(rest) = self.add_stack_to_inventory(ItemStack { count: 1, ..held })
                && let Some(eye) = self.eye_position()
            {
                self.spawn_item(rest, eye, [0.0; 3], 0);
            }
            return true;
        }
        false
    }
}
