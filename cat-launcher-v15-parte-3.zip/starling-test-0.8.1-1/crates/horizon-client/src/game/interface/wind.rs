//! Wind charges: the item a player throws (`WindChargeItem`), the charges
//! breezes shoot, and the burst they make (`ServerExplosion` with
//! `TRIGGER_BLOCK`: no damage, only knockback and the blocks that react).
use super::Game;
use super::entity::{Blast, Entity as _, for_each_entity_mut};
use horizon_client::advancements::EntityView;
use horizon_client::join_seq::Joined as _;
use horizon_client::{
    Result,
    items::ItemStack,
    mobs::{Damage, DamageKind, Species, Who},
    particles::{ParticleOptions, ParticleType},
    projectiles::{Hit, Projectile, ProjectileKind},
};
use horizon_core::{
    geometry::{Direction, Vec3},
    position::BlockPos,
    random::RandomSource,
};
use horizon_world::level::PlayerContext;
use std::collections::BTreeSet;

/// `WindCharge.RADIUS` and the knockback multiplier of its damage calculator.
const PLAYER_RADIUS: f32 = 1.2;
const PLAYER_KNOCKBACK: f32 = 1.22;
/// `BreezeWindCharge.RADIUS`.
const BREEZE_RADIUS: f32 = 3.0;

/// A burst `wind_burst` puts off until a guest's turn is over.
pub(super) struct Burst {
    center: [f64; 3],
    radius: f32,
    multiplier: f32,
    breeze: bool,
    wind_charge: bool,
    cause: BurstCause,
}
/// Who a burst's `ServerExplosion` names, as entity ids: the entity that
/// bursts (`getDirectSourceEntity`: a wind charge, the bearer of Wind
/// Charged, a mace's wielder with `attribute_to_user`) and its living
/// `getIndirectSourceEntity` (the charge's thrower, the bearer or wielder).
#[derive(Clone, Copy, Debug, Default)]
pub(super) struct BurstCause {
    pub source: Option<u32>,
    pub owner: Option<u32>,
}
/// Whether a wind push must wait for the entity's own tick: it joined before
/// the charge (`id` below the charge's), so vanilla has ticked it already this
/// game tick, and its kind ticks after the projectiles here.
fn push_waits_for_tick<T: PartialOrd>(
    ticks_after_projectiles: bool,
    joined: T,
    charge: Option<T>,
) -> bool {
    ticks_after_projectiles && charge.is_some_and(|c| joined < c)
}
/// `Projectile.deflect(REVERSE, entity, owner, false, 1.0)` of a breeze's
/// deflection, through the one engine path (`Projectile::deflect`). The turn's
/// float comes from the projectile's random. The owner stays; a hurting
/// projectile's acceleration power halves (`onDeflection`).
pub(super) fn reverse(p: &mut Projectile) {
    let owner = (p.owner, p.owner_uuid, p.guest);
    p.deflect(
        horizon_client::projectiles::Turn::Reverse,
        [1.0; 3],
        owner,
        false,
    );
}
/// Whether a block reacts to a wind charge's burst by being used.
fn triggers(name: &str) -> bool {
    let n = name.trim_start_matches("minecraft:");
    // Doors and trapdoors open unless iron; gates, buttons, levers and bells react.
    (n.ends_with("_door") || n.ends_with("_trapdoor")) && !n.starts_with("iron_")
        || n.ends_with("_fence_gate")
        || n.ends_with("_button")
        || n == "lever"
        || n == "bell"
}
impl Game<'_> {
    /// `WindChargeItem.use`.
    pub(super) fn throw_wind_charge(&mut self, stack: &ItemStack) -> Result<bool> {
        let (Some(eye), Some(p)) = (self.eye_position(), self.player.as_ref()) else {
            return Ok(false);
        };
        let (on_ground, pos) = (p.ground.on_ground, p.position);
        let velocity = self.known_player_movement();
        let start = Vec3::new(pos.x, eye[1], pos.z);
        let mut proj = Projectile::new(ProjectileKind::WindCharge, start, Some(Who::Player));
        proj.shoot_from_rotation(
            &mut self.world.random,
            self.pitch,
            self.yaw,
            0.0,
            1.5,
            1.0,
            velocity,
            on_ground,
        );
        self.spawn_projectile(proj, stack);
        let pitch = 0.4 / (self.world.random.next_float() * 0.4 + 0.8);
        self.audio
            .play("minecraft:entity.wind_charge.throw", Some(eye), 0.5, pitch);
        self.award_stat("used", "minecraft:wind_charge", 1);
        self.swing_arm();
        if !self.creative
            && let Some(s) = self.held_mut().as_mut()
        {
            s.count -= 1;
            if s.count == 0 {
                *self.held_mut() = None;
            }
        }
        Ok(true)
    }
    /// A wind charge meeting an entity or a block (or flying too high).
    pub(super) fn wind_charge_hit(&mut self, p: &Projectile, hit: Hit) -> Result<()> {
        let breeze = p.kind == ProjectileKind::BreezeWindCharge;
        let (radius, knockback) = if breeze {
            (BREEZE_RADIUS, 1.0)
        } else {
            (PLAYER_RADIUS, PLAYER_KNOCKBACK)
        };
        let center = match hit {
            Hit::Entity { who, at } => {
                self.wind_charge_damage(p, who);
                [at.x, at.y, at.z]
            }
            // onHitBlock: a quarter of a block out along the face.
            Hit::Block { at, face, .. } => [
                at.x + f64::from(face[0]) * 0.25,
                at.y + f64::from(face[1]) * 0.25,
                at.z + f64::from(face[2]) * 0.25,
            ],
            Hit::None => return Ok(()),
        };
        // The charge owner is the indirect source of the explosion.
        let owner = match p.owner {
            Some(Who::Player) => Some(self.own_entity_id() as u32),
            Some(Who::Mob(id)) => self.mobs.iter().any(|m| m.id == id).then_some(id),
            None => None,
        };
        let cause = BurstCause {
            source: Some(p.id),
            owner,
        };
        self.creatures.wind_source = Some(p.join_seq());
        let burst = self.wind_burst(center, radius, knockback, breeze, !breeze, cause);
        self.creatures.wind_source = None;
        burst
    }
    /// `AbstractWindCharge.onHitEntity`: one point of damage.
    fn wind_charge_damage(&mut self, p: &Projectile, who: Who) {
        let owner_breeze = matches!(p.owner, Some(Who::Mob(id))
            if self.mobs.iter().any(|m| m.id == id && m.species() == Species::Breeze));
        match who {
            Who::Player => {
                self.mob_hits_player_kind(
                    1.0,
                    [p.previous.x, p.previous.y, p.previous.z],
                    "minecraft:wind_charge",
                );
            }
            // An ender dragon part takes the point of damage too; a crystal is
            // not hit (`AbstractWindCharge.canHitEntity`).
            Who::Mob(id) if id >= super::dragon::SPECIAL => {
                if id < super::dragon::SPECIAL + 8 {
                    self.hit_special(
                        id,
                        1.0,
                        p.owner == Some(Who::Player),
                        horizon_client::mobs::DamageKind::WindCharge,
                        Some(p),
                    );
                }
            }
            Who::Mob(id) => {
                let source = Damage {
                    kind: DamageKind::Thrown,
                    attacker: p.owner,
                    from: Some([p.previous.x, p.previous.y, p.previous.z]),
                    attacker_species: owner_breeze.then_some(Species::Breeze),
                };
                let mut hurt = false;
                if let Some(m) = self.mobs.iter_mut().find(|m| m.id == id) {
                    // Breeze.isInvulnerableTo: its own kind's charges.
                    if owner_breeze && m.species() == Species::Breeze {
                        return;
                    }
                    // Refused before the hurt, so the kill is not credited
                    // either; the burst of `wind_charge_hit` still goes off.
                    if horizon_client::mobs::wither::armor_refuses(m, &p.kind) {
                        return;
                    }
                    hurt = m.damage(
                        crate::game::entity::damage_level_of!(self, scoped),
                        1.0,
                        source,
                    );
                }
                if p.owner == Some(Who::Player) {
                    self.remember_mob_player_credit(id);
                }
                if hurt {
                    self.shot_post_attack(p, who, p.kind.id(), "minecraft:wind_charge");
                }
            }
        }
    }
    /// The exploded positions: rays through everything but the blocks that
    /// stop wind (`blocks_wind_charge_explosions`).
    fn wind_positions(&mut self, center: [f64; 3], radius: f32) -> Vec<[i32; 3]> {
        let stops = self
            .res
            .items()
            .block_tags
            .get("minecraft:blocks_wind_charge_explosions")
            .cloned()
            .unwrap_or_default();
        let (min_y, max_y) = (self.world.bottom_y(), self.world.top_y());
        let mut set: BTreeSet<[i32; 3]> = BTreeSet::new();
        for xx in 0..16 {
            for yy in 0..16 {
                for zz in 0..16 {
                    if !(xx == 0 || xx == 15 || yy == 0 || yy == 15 || zz == 0 || zz == 15) {
                        continue;
                    }
                    let mut d = [
                        f64::from(xx as f32 / 15.0 * 2.0 - 1.0),
                        f64::from(yy as f32 / 15.0 * 2.0 - 1.0),
                        f64::from(zz as f32 / 15.0 * 2.0 - 1.0),
                    ];
                    let len = (d[0] * d[0] + d[1] * d[1] + d[2] * d[2]).sqrt();
                    for c in &mut d {
                        *c /= len;
                    }
                    let mut power = radius * (0.7 + self.world.random.next_float() * 0.6);
                    let mut at = center;
                    while power > 0.0 {
                        let pos = [
                            at[0].floor() as i32,
                            at[1].floor() as i32,
                            at[2].floor() as i32,
                        ];
                        if pos[1] < min_y || pos[1] >= max_y {
                            break;
                        }
                        let name = &self
                            .res
                            .facts()
                            .get(self.world.block(pos[0], pos[1], pos[2]))
                            .name;
                        if stops.contains(&**name) {
                            power -= (3_600_000.0_f32 + 0.3) * 0.3;
                        }
                        if power > 0.0 {
                            set.insert(pos);
                        }
                        for i in 0..3 {
                            at[i] += d[i] * f64::from(0.3_f32);
                        }
                        power -= 0.225_000_01;
                    }
                }
            }
        }
        set.into_iter().collect()
    }
    /// `ServerExplosion.hurtEntities` for a calculator that damages nothing:
    /// knockback scaled by distance, exposure and the multiplier. Returns the
    /// guests it pushed and by how much (`hitPlayers`), which their clients
    /// apply from the burst's packet.
    fn wind_knockback(
        &mut self,
        center: [f64; 3],
        radius: f32,
        multiplier: f32,
        breeze: bool,
        wind_charge: bool,
        blocks: &[[i32; 3]],
    ) -> Vec<(u32, [f64; 3])> {
        // ServerExplosion.shouldAffectBlocklikeEntities
        let blocklike = !breeze
            && !wind_charge
            && self
                .ui
                .rules
                .bool_at(horizon_client::gamerules::vanilla::MOB_GRIEFING);
        let diameter = f64::from(radius * 2.0);
        let distance = |p: [f64; 3]| {
            ((p[0] - center[0]).powi(2) + (p[1] - center[1]).powi(2) + (p[2] - center[2]).powi(2))
                .sqrt()
        };
        let direction = |origin: [f64; 3]| {
            let d = [
                origin[0] - center[0],
                origin[1] - center[1],
                origin[2] - center[2],
            ];
            let l = (d[0] * d[0] + d[1] * d[1] + d[2] * d[2]).sqrt();
            if l < 1.0e-5 {
                [0.0; 3]
            } else {
                [d[0] / l, d[1] / l, d[2] / l]
            }
        };
        // The player, then every other player in the level (LAN guests),
        // each swapped in as the player. In a guest's turn (a mace's wind
        // burst) the player is that guest.
        let own = self.wind_push_player(center, radius, multiplier, breeze, wind_charge, blocks);
        let mut pushed: Vec<_> = self.lan_acting.zip(own).into_iter().collect();
        if let Some(host) = self.lan.as_ref() {
            let guests: Vec<u32> = host
                .hub
                .guests
                .iter()
                .filter(|g| host.hub.here(g) && g.loaded && !g.dead)
                .map(|g| g.conn)
                .collect();
            for conn in guests {
                let push = self.as_guest(conn, |g| {
                    g.wind_push_player(center, radius, multiplier, breeze, wind_charge, blocks)
                });
                if let Some(Some(push)) = push {
                    pushed.push((conn, push));
                }
            }
        }
        let multiplier = f64::from(multiplier);
        // Every other entity takes `Entity.pushFromExplosion` alike: its
        // distance is from its feet, its direction from its eyes. A kind sits
        // out where its `ignoreExplosion` says (items and visible stands for a
        // charge, vehicles for a mob's burst with mob griefing off).
        let burst = Blast {
            vehicles_ignore: breeze
                && !self
                    .ui
                    .rules
                    .bool_at(horizon_client::gamerules::vanilla::MOB_GRIEFING),
            items_ignore: !blocklike,
            spared: None,
        };
        let source = self.creatures.wind_source;
        let done = self.ordered.done;
        let mut late = Vec::new();
        let mut entities = self.take_entities();
        for_each_entity_mut!(entities, entity => {
            if entity.ignores_explosion(&burst) || !entity.pushed_by_wind() {
                return;
            }
            let feet = entity.position();
            let feet = [feet.x, feet.y, feet.z];
            let dist = distance(feet) / diameter;
            if dist > 1.0 {
                return;
            }
            let b = entity.explosion_box();
            let (lo, hi) = (b.min_position(), b.max_position());
            let exposure = self.seen_percent(center, [lo.x, lo.y, lo.z], [hi.x, hi.y, hi.z]);
            let power = (1.0 - dist) * f64::from(exposure) * multiplier;
            let dir = direction([feet[0], feet[1] + entity.explosion_eye_height(), feet[2]]);
            let mut push = [dir[0] * power, dir[1] * power, dir[2] * power];
            let id = Some(entity.id());
            self.native_explosion_knockback(self.dim.id(), center, blocks, id, &mut push);
            let push = Vec3::new(push[0], push[1], push[2]);
            // ServerLevel ticks entities in the order they joined. One that
            // joined before the charge has ticked by now in vanilla, so the
            // push is for its next tick; here its kind ticks after the
            // projectiles, so the push waits for that tick to run.
            // Joined before the charge and not ticked yet: the push is for its next tick.
            let waiting = entity.ticks_after_projectiles()
                && done.is_none_or(|d| entity.join_seq() > d);
            if push_waits_for_tick(waiting, entity.join_seq(), source) {
                late.push((entity.id(), push));
            } else {
                entity.push_from_explosion(push);
            }
        });
        self.restore_entities(entities);
        self.creatures.late_wind_pushes.extend(late);
        pushed
    }
    /// The pushes `wind_knockback` held for entities that tick after the
    /// projectiles, applied once those entities have ticked.
    pub(super) fn apply_late_wind_pushes(&mut self) {
        let late = std::mem::take(&mut self.creatures.late_wind_pushes);
        if late.is_empty() {
            return;
        }
        let mut entities = self.take_entities();
        for_each_entity_mut!(entities, entity => {
            if let Some((_, push)) = late.iter().find(|(id, _)| *id == entity.id()) {
                entity.push_from_explosion(*push);
            }
        });
        self.restore_entities(entities);
    }
    /// `ServerExplosion.hurtEntities` for the player: the push, less
    /// explosion knockback resistance, and `ServerPlayer.onExplosionHit`.
    /// Returns the push for players eligible for the explosion packet.
    fn wind_push_player(
        &mut self,
        center: [f64; 3],
        radius: f32,
        multiplier: f32,
        breeze: bool,
        wind_charge: bool,
        blocks: &[[i32; 3]],
    ) -> Option<[f64; 3]> {
        if self.spectator() {
            return None;
        }
        let resistance = self
            .player
            .as_mut()
            .and_then(|p| p.attribute("minecraft:explosion_knockback_resistance").ok())
            .unwrap_or(0.0);
        let creative = self.creative;
        let p = self.player.as_ref()?;
        let feet = [p.position.x, p.position.y, p.position.z];
        let dist = ((feet[0] - center[0]).powi(2)
            + (feet[1] - center[1]).powi(2)
            + (feet[2] - center[2]).powi(2))
        .sqrt()
            / f64::from(radius * 2.0);
        let flying = creative && p.flying;
        if dist > 1.0 {
            return None;
        }
        let w = f64::from(p.dimensions.width) / 2.0;
        let h = f64::from(p.dimensions.height);
        let eye = [
            feet[0] - center[0],
            feet[1] + f64::from(p.dimensions.eye_height) - center[1],
            feet[2] - center[2],
        ];
        let exposure = self.seen_percent(
            center,
            [feet[0] - w, feet[1], feet[2] - w],
            [feet[0] + w, feet[1] + h, feet[2] + w],
        );
        let power = (1.0 - dist) * f64::from(exposure) * f64::from(multiplier) * (1.0 - resistance);
        let l = (eye[0] * eye[0] + eye[1] * eye[1] + eye[2] * eye[2]).sqrt();
        let mut push = if l < 1.0e-5 {
            [0.0; 3]
        } else {
            eye.map(|d| d / l * power)
        };
        self.native_explosion_knockback(self.dim.id(), center, blocks, None, &mut push);
        let p = self.player.as_mut()?;
        p.velocity = Vec3::new(
            p.velocity.x + push[0],
            p.velocity.y + push[1],
            p.velocity.z + push[2],
        );
        // ServerPlayer.onExplosionHit: a wind charge's burst cancels the
        // fall; any other burst ends the grace of the last impulse.
        let at = p.position;
        p.impulse.set_ignore_fall_damage(wind_charge, Some(at));
        // The cause is the charge that burst (`ServerExplosion.source`); a mace's
        // burst has none.
        let cause = if wind_charge {
            Some("minecraft:wind_charge")
        } else if breeze {
            Some("minecraft:breeze_wind_charge")
        } else {
            None
        }
        .map(|kind| EntityView {
            kind: kind.into(),
            position: center,
            ..EntityView::default()
        });
        self.adv.marks.blast = Some(([at.x, at.y, at.z], cause));
        (!flying).then_some(push)
    }
    /// The burst: knockback, the blocks that react, the gust and the sound.
    pub(super) fn wind_burst(
        &mut self,
        center: [f64; 3],
        radius: f32,
        multiplier: f32,
        breeze: bool,
        wind_charge: bool,
        cause: BurstCause,
    ) -> Result<()> {
        // In a guest's turn (their charge landing, their mace's burst) the
        // host holds the other players (`as_guest`): the burst waits for the
        // turn to end so that it reaches every player, the guest too.
        if self.lan_acting.is_some() && self.lan.is_none() {
            self.creatures.wind_bursts.push(Burst {
                center,
                radius,
                multiplier,
                breeze,
                wind_charge,
                cause,
            });
            return Ok(());
        }
        if self.serving.is_some() || self.options.dedicated.is_some() {
            let start = mod_api::ExplosionStart::from(mod_api::__private::built::ExplosionStart {
                dimension: self.dim.id(),
                center,
                radius,
                fire: false,
                interaction: mod_api::BlockInteraction::TriggerBlock,
                // `DamageSources.explosion(source, owner)`.
                damage_type: if cause.source.is_some() && cause.owner.is_some() {
                    "minecraft:player_explosion"
                } else {
                    "minecraft:explosion"
                },
                source: cause.source,
                owner: cause.owner,
            });
            if self.explosion_start_cancelled(&start) {
                return Ok(());
            }
        }
        // ServerExplosion.explode: the blast is heard first.
        let ctx = horizon_client::sculk::Context::default();
        self.post_game_event("minecraft:explode", center, ctx);
        let mut targets = self.wind_positions(center, radius);
        let pushed = self.wind_knockback(center, radius, multiplier, breeze, wind_charge, &targets);
        let block_count = targets.len();
        // Explosion.canTriggerBlocks: a breeze's charge needs mob griefing.
        if !breeze
            || self
                .ui
                .rules
                .bool_at(horizon_client::gamerules::vanilla::MOB_GRIEFING)
        {
            // Util.shuffle(list, level.random)
            for i in (2..=targets.len()).rev() {
                let swap = self.world.random.next_int_bound(i as i32).unwrap_or(0) as usize;
                targets.swap(i - 1, swap);
            }
            let dimension = self.dim.id();
            self.native_wind_burst(dimension, center, &mut targets);
            for pos in targets {
                self.wind_trigger_block(pos)?;
            }
        }
        let sound = if breeze {
            "minecraft:entity.breeze.wind_burst"
        } else {
            "minecraft:entity.wind_charge.wind_burst"
        };
        let pitch = (1.0
            + (super::explosion::client_float() - super::explosion::client_float()) * 0.2)
            * 0.7;
        self.audio.play(sound, Some(center), 4.0, pitch);
        // Explosion.isSmall: below a radius of 2.
        let ty = if radius < 2.0 {
            ParticleType::GustEmitterSmall
        } else {
            ParticleType::GustEmitterLarge
        };
        self.particles
            .add(&ParticleOptions::simple(ty), center, [1.0, 0.0, 0.0]);
        self.lan_wind_burst(center, radius, sound, block_count, &pushed);
        Ok(())
    }
    /// The bursts guests' turns put off.
    pub(super) fn flush_wind_bursts(&mut self) -> Result<()> {
        self.flush_smash_pushes();
        for b in std::mem::take(&mut self.creatures.wind_bursts) {
            self.wind_burst(
                b.center,
                b.radius,
                b.multiplier,
                b.breeze,
                b.wind_charge,
                b.cause,
            )?;
        }
        Ok(())
    }
    /// `BlockBehaviour.onExplosionHit` for `TRIGGER_BLOCK`: doors, gates,
    /// buttons, levers and bells react as if used; candles go out.
    fn wind_trigger_block(&mut self, pos: [i32; 3]) -> Result<()> {
        let state = self.world.block(pos[0], pos[1], pos[2]);
        let name = self.res.facts().get(state).name.clone();
        let prop = |game: &Self, key: &str| {
            game.pack
                .assets
                .registry
                .state(state)
                .and_then(|s| s.properties.get(key).cloned())
        };
        if name.ends_with("candle") || name.ends_with("candle_cake") {
            // AbstractCandleBlock.onExplosionHit: extinguish(null, ...), the
            // candle's own sound and a block-change game event (the smoke is a
            // client-level particle, which a server level never draws).
            self.with_level(|b, level, ticks| {
                b.extinguish_candle(level, ticks, BlockPos::new(pos[0], pos[1], pos[2]))
            });
            self.process_level_events()?;
            return Ok(());
        }
        if !triggers(&name) {
            return Ok(());
        }
        // BellBlock.onExplosionHit: attemptToRing with no direction, so the bell
        // rings toward its facing, not the face the burst came from,
        // powered or not.
        if &*name == "minecraft:bell" {
            self.with_level(|b, level, ticks| {
                b.bell_attempt_to_ring(level, ticks, BlockPos::new(pos[0], pos[1], pos[2]))
            });
            self.process_level_events()?;
            return Ok(());
        }
        // Doors react in their lower half only; powered ones and pressed
        // buttons stay as they are.
        if name.ends_with("_door") && prop(self, "half").as_deref() != Some("lower") {
            return Ok(());
        }
        if prop(self, "powered").as_deref() == Some("true") && &*name != "minecraft:lever" {
            return Ok(());
        }
        // FenceGateBlock.onExplosionHit toggles the gate without turning it
        // towards anyone, as a click would.
        if name.ends_with("_fence_gate") {
            self.with_level(|b, level, ticks| {
                b.fence_gate_exploded(level, ticks, BlockPos::new(pos[0], pos[1], pos[2]))
            });
            self.process_level_events()?;
            return Ok(());
        }
        let at = Vec3::new(
            f64::from(pos[0]) + 0.5,
            f64::from(pos[1]) + 0.5,
            f64::from(pos[2]) + 0.5,
        );
        let player = PlayerContext {
            yaw: self.yaw,
            pitch: self.pitch,
            may_build: true,
            can_eat: false,
            game_master: false,
        };
        self.with_level(|b, level, ticks| {
            b.use_without_item(
                level,
                ticks,
                state,
                horizon_core::geometry::BlockHit {
                    block: BlockPos::new(pos[0], pos[1], pos[2]),
                    direction: Direction::Up,
                    location: at,
                    inside: false,
                },
                player,
            )
        });
        self.process_level_events()?;
        Ok(())
    }
    /// `WindChargeRenderer`: the spinning charge and its wind.
    pub(super) fn wind_charge_geometry(
        &self,
        p: &Projectile,
        at: glam::Vec3,
        light: u32,
        partial: f32,
        out: &mut Vec<mod_render::render::Vertex>,
    ) {
        let Some(model) = self.entity_models.wind_charge.as_ref() else {
            return;
        };
        let Some(r) = self
            .gui
            .atlas
            .sprites
            .get("entity/projectiles/wind_charge")
            .copied()
        else {
            return;
        };
        // `EntityRenderState.ageInTicks`: the tick count plus the partial tick.
        let age = p.age as f32 + partial;
        let mut poses = horizon_client::mobs::anim::Poses::new(model);
        poses.yrot("wind_charge", -age * 16.0_f32.to_radians());
        poses.yrot("wind", age * 16.0_f32.to_radians());
        let base = glam::Mat4::from_translation(at)
            * glam::Mat4::from_scale(glam::Vec3::new(-1.0, -1.0, 1.0));
        let start = out.len();
        horizon_client::mobs::render::draw_scrolled(
            model,
            base,
            &poses,
            [r.u0, r.v0, r.u1, r.v1],
            horizon_client::mobs::render::scroll_offset(
                age,
                horizon_client::mobs::render::WIND_CHARGE_SCROLL,
            ),
            0xFFFF_FFFF,
            light,
            0,
            out,
        );
        // `RenderTypes.breezeWind` has an `OitPipelineSet`.
        for vertex in &mut out[start..] {
            vertex.layer |= horizon_client::gfx::OIT_ENTITY;
        }
    }
}
#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn a_burst_opens_wooden_doors_but_not_iron_ones() {
        assert!(triggers("minecraft:oak_door"));
        assert!(triggers("minecraft:copper_trapdoor"));
        assert!(!triggers("minecraft:iron_door"));
        assert!(!triggers("minecraft:iron_trapdoor"));
        assert!(triggers("minecraft:lever"));
        assert!(triggers("minecraft:stone_button"));
        assert!(triggers("minecraft:bell"));
        assert!(!triggers("minecraft:stone"));
    }
    /// ServerLevel ticks entities in join order: an orb, falling block or TNT that
    /// joined before the charge has moved by the time the charge bursts, so the
    /// push belongs to its next tick; one that joined after has not.
    #[test]
    fn a_push_waits_only_for_late_ticking_kinds_that_joined_before_the_charge() {
        use crate::game::entity::Entity;
        assert!(push_waits_for_tick(true, 3, Some(7)));
        assert!(!push_waits_for_tick(true, 9, Some(7)), "joined after");
        assert!(!push_waits_for_tick(false, 3, Some(7)), "ticks before it");
        assert!(!push_waits_for_tick(true, 3, None), "not a charge's burst");
        let tnt = crate::game::tnt::PrimedTnt {
            attachment_lifetime: Default::default(),
            rotation: [0.0, 0.0],
            id: 1,
            position: Vec3::ZERO,
            previous: Vec3::ZERO,
            velocity: Vec3::ZERO,
            fuse: 80,
            on_ground: false,
            fall_distance: 0.0,
            stuck: Vec3::ZERO,
            in_water: false,
            owner: None,
            guest: None,
            no_gravity: false,
            power: 4.0,
            block_state: None,
            join: Default::default(),
        };
        assert!(Entity::ticks_after_projectiles(&tnt));
        let arrow = Projectile::new(ProjectileKind::Snowball, Vec3::ZERO, None);
        assert!(!Entity::ticks_after_projectiles(&arrow));
    }
    #[test]
    fn a_deflected_projectile_turns_around_at_half_speed() {
        let mut p = Projectile::new(ProjectileKind::Snowball, Vec3::ZERO, None);
        p.velocity = Vec3::new(2.0, -1.0, 0.0);
        reverse(&mut p);
        assert!((p.velocity.x + 1.0).abs() < 1e-9 && (p.velocity.y - 0.5).abs() < 1e-9);
        assert!((170.0..190.0).contains(&p.yaw));
    }
}
