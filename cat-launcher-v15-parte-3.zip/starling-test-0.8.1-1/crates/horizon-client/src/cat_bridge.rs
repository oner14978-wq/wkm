//! Cat Launcher's bridge into the real Starling systems, for the HTML launcher (assets/cat).
//!
//! HTML/JS `CatNative.core(method, args)` -> `CatCore.call` (Java) -> JNI (`android_lib.rs`) ->
//! [`call`] here -> the systems the game itself uses: `accounts.rs` (profiles, offline names,
//! Microsoft device-code and Ely.by sign-in, the Keystore-sealed secrets, the official files'
//! download from Mojang with hash checks) and the own-skin store (`own_skin`). Nothing here
//! pretends: every answer is `{"ok":true,..}` from the system, or `{"ok":false,"error":..}` with
//! the system's own reason.
//!
//! Runs in the launcher's process (`:cat`), where the game's NativeActivity does not exist: the
//! platform hooks are registered here against `CatCore`'s static methods (the same Keystore key
//! as the game's, so what is sealed here opens in the game). The two processes share the
//! app's private folder (accounts, secrets, the downloaded files); only one writes at a time,
//! because the launcher hands over to the game when the player taps Play.
use crate::{accounts, platform};
use jni::objects::{GlobalRef, JByteArray, JClass, JValue};
use jni::{JNIEnv, JavaVM};
use serde_json::{Value, json};
use std::path::{Path, PathBuf};
use std::sync::OnceLock;
use std::time::{Duration, Instant};

/// The skin file this launcher keeps in the game's `skins/` folder.
const SKIN_FILE: &str = "cat-skin.png";
/// The largest skin picture taken (as the game's own import does).
const MAX_SKIN: u64 = 1024 * 1024;

struct Host {
    vm: JavaVM,
    /// `io.github.juanluci.starling.CatCore`, whose static methods are the platform's.
    class: GlobalRef,
    game_home: PathBuf,
}

static HOST: OnceLock<Host> = OnceLock::new();

fn with_host<R>(
    f: impl FnOnce(&mut JNIEnv, &JClass) -> jni::errors::Result<R>,
) -> Option<R> {
    let host = HOST.get()?;
    let mut env = host.vm.attach_current_thread().ok()?;
    let local = env.new_local_ref(host.class.as_obj()).ok()?;
    let class = JClass::from(local);
    let result = f(&mut env, &class);
    if env.exception_check().unwrap_or(false) {
        let _ = env.exception_describe();
        let _ = env.exception_clear();
    }
    result.ok()
}

fn secret_call(method: &str, data: &[u8]) -> Option<Vec<u8>> {
    with_host(|env, class| {
        let input = env.byte_array_from_slice(data)?;
        let out = env
            .call_static_method(class, method, "([B)[B", &[JValue::Object(&input)])?
            .l()?;
        if out.is_null() {
            return Ok(None);
        }
        Ok(Some(env.convert_byte_array(JByteArray::from(out))?))
    })
    .flatten()
}

fn seal(data: &[u8]) -> Option<Vec<u8>> {
    secret_call("sealSecret", data)
}

fn open(sealed: &[u8]) -> Option<Vec<u8>> {
    secret_call("openSecret", sealed)
}

fn open_link(url: &str) -> bool {
    with_host(|env, class| {
        let url = env.new_string(url)?;
        env.call_static_method(
            class,
            "openLink",
            "(Ljava/lang/String;)Z",
            &[JValue::Object(&url)],
        )?
        .z()
    })
    .unwrap_or(false)
}

fn library_dir() -> Option<PathBuf> {
    with_host(|env, class| {
        let dir = env
            .call_static_method(class, "libraryDir", "()Ljava/lang/String;", &[])?
            .l()?;
        if dir.is_null() {
            return Ok(None);
        }
        Ok(Some(PathBuf::from(String::from(env.get_string(&dir.into())?))))
    })
    .flatten()
}

fn keep_working(reason: &str, line: &str, on: bool) {
    with_host(|env, class| {
        let reason = env.new_string(reason)?;
        let line = env.new_string(line)?;
        env.call_static_method(
            class,
            "keepWorking",
            "(Ljava/lang/String;Ljava/lang/String;Z)V",
            &[
                JValue::Object(&reason),
                JValue::Object(&line),
                JValue::Bool(u8::from(on)),
            ],
        )
        .map(drop)
    });
}

// What the launcher has no window for: the game's own screens do these.
fn open_folder(_: &Path) -> bool {
    false
}
fn pick_file() -> bool {
    false
}
fn clipboard_get() -> Option<String> {
    None
}
fn clipboard_set(_: &str) -> bool {
    false
}
/// A file of the APK's `assets/` (the preparer's kit, the low-budget skin): CatCore.asset reads it.
/// The install needs them here, in the launcher's process, where there is no NativeActivity.
fn asset(name: &str) -> Option<Vec<u8>> {
    with_host(|env, class| {
        let name = env.new_string(name)?;
        let out = env
            .call_static_method(
                class,
                "asset",
                "(Ljava/lang/String;)[B",
                &[JValue::Object(&name)],
            )?
            .l()?;
        if out.is_null() {
            return Ok(None);
        }
        Ok(Some(env.convert_byte_array(JByteArray::from(out))?))
    })
    .flatten()
}

/// Called once from `CatCore.init` (a Java thread): the folders, the platform hooks, and the
/// renewal of the saved sign-in. `private` is the app's files folder; `game_home` the game folder
/// (shared storage when the player allowed it, else `private`).
pub fn init(vm: JavaVM, class: GlobalRef, private: PathBuf, game_home: PathBuf) -> Result<(), String> {
    if HOST.get().is_some() {
        return Ok(());
    }
    std::fs::create_dir_all(&private).map_err(|e| format!("{}: {e}", private.display()))?;
    let _ = std::fs::create_dir_all(&game_home);
    // SAFETY: called once, before the bridge starts any thread of its own.
    unsafe {
        std::env::set_var("HORIZON_HOME", &game_home);
        std::env::set_var("HORIZON_PRIVATE", &private);
        for (name, value) in [("HORIZON_TELEMETRY_URL", "off"), ("HORIZON_NO_DISCORD", "1")] {
            if std::env::var_os(name).is_none() {
                std::env::set_var(name, value);
            }
        }
    }
    crate::logging::set_console(crate::android::logcat);
    HOST.set(Host {
        vm,
        class,
        game_home,
    })
    .map_err(|_| "the bridge was already started".to_owned())?;
    platform::set(platform::Hooks {
        open_folder,
        pick_file,
        clipboard_get,
        clipboard_set,
        open_link,
        seal,
        open,
        library_dir,
        asset,
        keep_working,
    });
    // The saved sign-in renews in the background, as it does when the game starts.
    accounts::resume();
    log::info!(
        "Cat Launcher bridge ready: private {}, game folder {}",
        private_display(),
        HOST.get().map(|h| h.game_home.display().to_string()).unwrap_or_default()
    );
    Ok(())
}

fn private_display() -> String {
    crate::logging::private_home().display().to_string()
}

fn ok(extra: Value) -> Value {
    let mut out = json!({ "ok": true });
    if let (Some(base), Value::Object(more)) = (out.as_object_mut(), extra) {
        base.extend(more);
    }
    out
}

fn fail(error: impl std::fmt::Display) -> Value {
    json!({ "ok": false, "error": translate(&error.to_string()) })
}

/// The account crate reports some failures as language keys (the game's own screens translate
/// them); the launcher shows plain words for the ones a player can meet.
fn translate(error: &str) -> String {
    match error {
        "starling.account.error.name_error" => {
            "Nome inválido para o jogo: use de 3 a 16 letras, números ou _.".into()
        }
        "starling.account.error.cancelled" => "Operação cancelada.".into(),
        other => other.to_owned(),
    }
}

fn text(args: &Value, key: &str) -> Result<String, String> {
    args.get(key)
        .and_then(Value::as_str)
        .map(str::to_owned)
        .ok_or_else(|| format!("falta o argumento \"{key}\""))
}

/// The state the account actions leave: they run on a thread and say "resuming" until done.
fn settled() -> accounts::State {
    let until = Instant::now() + Duration::from_secs(15);
    loop {
        let state = accounts::state();
        if !matches!(state, accounts::State::Resuming) || Instant::now() > until {
            return state;
        }
        std::thread::sleep(Duration::from_millis(40));
    }
}

fn after_account_action() -> Value {
    match settled() {
        accounts::State::Failed(e) => fail(e),
        _ => ok(json!({ "account": account_json() })),
    }
}

fn account_json() -> Value {
    use accounts::{Provider, State};
    match accounts::state() {
        State::Offline => json!({ "kind": "offline" }),
        State::Resuming => json!({ "kind": "resuming" }),
        State::Starting => json!({ "kind": "starting" }),
        State::Progress(stage) => json!({ "kind": "progress", "stage": stage.key() }),
        State::Code { code, link } => json!({ "kind": "code", "code": code, "link": link }),
        State::SignedIn(a) => json!({
            "kind": "signed_in",
            "name": a.name,
            "key": a.key(),
            "provider": match a.provider { Provider::Microsoft => "microsoft", Provider::Ely => "ely" },
        }),
        State::OfflineProfile(name) => json!({ "kind": "offline_profile", "name": name }),
        State::Failed(e) => json!({ "kind": "failed", "error": translate(&e) }),
    }
}

fn files_json() -> Value {
    use accounts::Files;
    match accounts::files() {
        Files::Missing => json!({ "kind": "missing" }),
        Files::Checking => json!({ "kind": "checking" }),
        Files::Downloading(p) => json!({
            "kind": "downloading",
            "files": p.files,
            "files_total": p.files_total,
            "bytes": p.bytes,
            "bytes_total": p.bytes_total,
        }),
        Files::Ready => json!({ "kind": "ready" }),
        Files::Failed(e) => json!({ "kind": "failed", "error": e }),
    }
}

fn profiles_json() -> Value {
    let list = accounts::profiles();
    json!({
        "accounts": list.accounts.iter().map(|a| json!({
            "key": a.key(),
            "name": a.name,
            "provider": format!("{:?}", a.provider).to_lowercase(),
        })).collect::<Vec<_>>(),
        "offline": list.offline,
        "uuids": list.offline.iter().map(|n| (n.clone(), json!(offline_uuid_string(n)))).collect::<serde_json::Map<_, _>>(),
        "selected": list.selected,
        "offline_selected": list.offline_selected,
    })
}

/// Where the prepared game resources go: the game folder's `resources` (android.rs `command_line`).
fn resources() -> PathBuf {
    HOST.get()
        .map(|h| h.game_home.join("resources"))
        .unwrap_or_else(|| crate::logging::private_home().join("resources"))
}

/// Whether the version is really installed: the official files are on the phone AND the game's
/// resources were prepared from them (the sounds are the preparing's last piece). Not before.
fn installed() -> bool {
    matches!(accounts::files(), accounts::Files::Ready)
        && !crate::preparer::running()
        && resources().join("assets/minecraft/sounds.json").is_file()
}

/// Where the preparing is (preparer.rs), as the install screen follows it.
fn prepare_json() -> Value {
    use crate::preparer::Stage;
    match crate::preparer::stage() {
        Stage::Idle => json!({ "kind": "idle" }),
        Stage::Java(done, total) => json!({ "kind": "java", "bytes": done, "bytes_total": total }),
        Stage::Unpacking => json!({ "kind": "unpacking" }),
        Stage::Preparing(line) => json!({ "kind": "preparing", "line": line }),
        Stage::Done => json!({ "kind": "done" }),
        Stage::Failed(error) => json!({ "kind": "failed", "error": error }),
    }
}

/// The one version the engine runs (`Pins::starling`), and whether it is installed.
fn versions_json() -> Value {
    let pins = starling_account::files::Pins::starling();
    json!([{
        "id": pins.version,
        "type": "release",
        "cat": "recent",
        "installed": installed(),
    }])
}

static INSTALLING: std::sync::atomic::AtomicBool = std::sync::atomic::AtomicBool::new(false);

/// Install = download the official files (accounts.rs), then prepare them (preparer.rs). The
/// version counts as installed only when both are done (`installed`). A thread follows the
/// download into the preparing, so the install finishes even if the screen is left meanwhile.
fn install() -> Value {
    use std::sync::atomic::Ordering;
    if installed() {
        return ok(json!({ "installed": true }));
    }
    accounts::download_files();
    if !INSTALLING.swap(true, Ordering::SeqCst) {
        let spawned = std::thread::Builder::new().name("cat-install".into()).spawn(|| {
            keep_working("cat-install", "Instalando o Minecraft", true);
            std::thread::sleep(Duration::from_millis(500));
            loop {
                match accounts::files() {
                    accounts::Files::Ready => {
                        if !crate::preparer::running() && !installed() {
                            crate::preparer::start(resources());
                        }
                        break;
                    }
                    accounts::Files::Checking | accounts::Files::Downloading(_) => {}
                    // Failed, or cancelled (Missing): nothing to prepare.
                    _ => {
                        keep_working("cat-install", "", false);
                        INSTALLING.store(false, Ordering::SeqCst);
                        return;
                    }
                }
                std::thread::sleep(Duration::from_millis(500));
            }
            while crate::preparer::running() {
                std::thread::sleep(Duration::from_millis(500));
            }
            keep_working("cat-install", "", false);
            INSTALLING.store(false, Ordering::SeqCst);
        });
        if spawned.is_err() {
            INSTALLING.store(false, Ordering::SeqCst);
            return fail("não foi possível iniciar a instalação");
        }
    }
    ok(json!({ "files": files_json() }))
}

/// The stable offline UUID the engine itself uses (`UUID.nameUUIDFromBytes("OfflinePlayer:<name>")`).
fn offline_uuid_string(name: &str) -> String {
    horizon_protocol::crypto::uuid_string(horizon_protocol::crypto::offline_uuid(name))
}

/// Keeps the profile (name + UUID) in the launcher's private folder, beside the engine's own list.
fn store_profile(name: &str, uuid: &str) {
    let path = crate::logging::private_home().join("cat-offline-profile.json");
    let body = json!({ "name": name, "uuid": uuid }).to_string();
    if let Err(e) = std::fs::write(&path, body) {
        log::warn!("could not keep {}: {e}", path.display());
    }
}

fn valid_name(name: &str) -> bool {
    (3..=16).contains(&name.len()) && name.bytes().all(|b| b.is_ascii_alphanumeric() || b == b'_')
}

/// The launcher's skin, from a PNG the Java side wrote, onto the playing profile: checked and
/// decoded by the game's own reader (`own_skin::decode`), kept in the game's `skins/` folder, and
/// chosen for the profile the way Options > Skin Customization chooses (`SkinChoice`), so the
/// game wears it at its next start.
fn apply_skin(args: &Value) -> Value {
    let path = match text(args, "png_path") {
        Ok(p) => PathBuf::from(p),
        Err(e) => return fail(e),
    };
    let slim = args.get("slim").and_then(Value::as_bool).unwrap_or(false);
    let Some(host) = HOST.get() else {
        return fail("a ponte nativa não foi iniciada");
    };
    let bytes = match std::fs::metadata(&path) {
        Ok(m) if m.len() > MAX_SKIN => return fail("a skin tem mais de 1 MiB"),
        Ok(_) => match std::fs::read(&path) {
            Ok(b) => b,
            Err(e) => return fail(format!("não foi possível ler a skin: {e}")),
        },
        Err(e) => return fail(format!("não foi possível ler a skin: {e}")),
    };
    if let Err(e) = crate::own_skin::decode(&bytes) {
        return fail(format!("skin inválida: {e}"));
    }
    let skins = host.game_home.join(crate::own_skin::DIR);
    if let Err(e) = std::fs::create_dir_all(&skins).and_then(|()| std::fs::write(skins.join(SKIN_FILE), &bytes)) {
        return fail(format!("não foi possível guardar a skin em {}: {e}", skins.display()));
    }
    let choice = crate::own_skin::SkinChoice {
        file: Some(SKIN_FILE.to_owned()),
        slim,
    };
    let key = accounts::player_key();
    match choice.save_for_profile(&host.game_home, key.as_deref()) {
        Ok(()) => ok(json!({ "file": SKIN_FILE, "slim": slim })),
        Err(e) => fail(format!("não foi possível escolher a skin: {e}")),
    }
}

/// Deletes the official files from the disk (versions, libraries, assets) and forgets them.
fn remove_files() -> Value {
    if matches!(
        accounts::files(),
        accounts::Files::Checking | accounts::Files::Downloading(_)
    ) || crate::preparer::running()
    {
        return fail("uma instalação está em andamento; cancele o download ou espere terminar antes de remover");
    }
    // The prepared resources go with the files they were made from; worlds and settings stay.
    let _ = std::fs::remove_dir_all(resources());
    let root = accounts::files_root();
    match std::fs::remove_dir_all(&root) {
        Ok(()) => {}
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => {}
        Err(e) => return fail(format!("não foi possível remover {}: {e}", root.display())),
    }
    accounts::forget_files();
    ok(json!({}))
}

/// One request from the launcher. `args` is a JSON object; the answer is a JSON object with
/// `ok`, and `error` when it is false.
pub fn call(method: &str, args: &str) -> String {
    let args: Value = serde_json::from_str(args).unwrap_or(Value::Null);
    log::info!("Cat Launcher -> {method}");
    let out = match method {
        "state" => ok(json!({
            "account": account_json(),
            "profiles": profiles_json(),
            "files": files_json(),
            "prepare": prepare_json(),
            "installed": installed(),
            "version": starling_account::files::Pins::starling().version,
        })),
        "versions" => ok(json!({ "versions": versions_json() })),
        "add_offline" => match text(&args, "name") {
            Ok(name) if valid_name(name.trim()) => {
                let name = name.trim().to_owned();
                accounts::add_offline(name.clone());
                let mut answer = after_account_action();
                if answer["ok"] == json!(true) {
                    let uuid = offline_uuid_string(&name);
                    store_profile(&name, &uuid);
                    answer["name"] = json!(name);
                    answer["uuid"] = json!(uuid);
                }
                answer
            }
            Ok(_) => fail("starling.account.error.name_error"),
            Err(e) => fail(e),
        },
        "select" => match text(&args, "key") {
            Ok(key) => {
                accounts::select(key);
                after_account_action()
            }
            Err(e) => fail(e),
        },
        "remove" => match text(&args, "key") {
            Ok(key) => {
                accounts::remove(key);
                after_account_action()
            }
            Err(e) => fail(e),
        },
        "install" => install(),
        "prepare_ack" => {
            crate::preparer::clear();
            ok(json!({}))
        }
        "download_files" => {
            accounts::download_files();
            ok(json!({ "files": files_json() }))
        }
        "cancel_download" => {
            accounts::cancel_download();
            ok(json!({}))
        }
        "remove_files" => remove_files(),
        "apply_skin" => apply_skin(&args),
        other => fail(format!("método desconhecido: {other}")),
    };
    out.to_string()
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn offline_uuid_matches_java() {
        assert_eq!(offline_uuid_string("Steve"), "5627dd98-e6be-3c21-b8a8-e92344183641");
    }
    #[test]
    fn names_are_checked() {
        assert!(valid_name("Gatinho_01"));
        assert!(!valid_name("ab") && !valid_name("a b c") && !valid_name(&"a".repeat(17)));
    }
}
