//! `AbstractFurnaceBlockEntity`'s cooking over the furnace data the chunk
//! holds (`containers::Furnace`): it needs the recipes, so it lives above them.
use crate::{
    containers::{Furnace, recipe_used_key},
    crafting::Recipes,
    items::{ItemStack, Items},
    providers::Providers,
};
use horizon_world::native_load_context::LoopContext;

/// The furnace methods that read the recipes.
pub trait FurnaceCooking {
    /// `AbstractFurnaceBlockEntity.setItem` on the input slot: anything but
    /// the same item with the same components restarts cooking, with the
    /// total time of the new input's recipe (200 ticks without one).
    fn set_input(&mut self, context: &LoopContext, recipes: &Recipes, stack: Option<ItemStack>);
    /// `recipesUsed`, each recipe with its `experience` (0 for one this data pack does
    /// not have), in the order `getRecipesToAwardAndPopExperience` pays them.
    fn recipe_experience(&self, recipes: &Recipes) -> Vec<(u32, f32)>;
    /// A menu click wrote its slots into `items`, and `before` was the input
    /// slot until then: the menu called `setItem` on it only if it changed
    /// (`Slot.setByPlayer`; partial takes and merges keep the stack).
    fn input_clicked(
        &mut self,
        context: &LoopContext,
        recipes: &Recipes,
        before: Option<ItemStack>,
    );
    /// One server tick. Returns `Some(lit)` when the LIT block state must change.
    /// `drops` collects what the furnace lets fall at its position
    /// (`Containers.dropItemStack`): the remainder of a fuel when more of it is left.
    fn tick(
        &mut self,
        context: &LoopContext,
        recipes: &Recipes,
        items: &Items,
        providers: &Providers,
        drops: &mut Vec<ItemStack>,
        remainder: &dyn Fn(&ItemStack) -> Option<ItemStack>,
    ) -> Option<bool>;
    fn idle(&self) -> bool;
}
impl FurnaceCooking for Furnace {
    fn set_input(&mut self, context: &LoopContext, recipes: &Recipes, stack: Option<ItemStack>) {
        let same = match (&self.items[0], &stack) {
            (Some(old), Some(new)) => old.same_item_same_components(new),
            _ => false,
        };
        self.items[0] = stack;
        if !same {
            self.cooking_total = self.items[0]
                .as_ref()
                .and_then(|input| recipes.cook(context, self.kind.recipe_type(), input))
                .map_or(200, |recipe| total_time(recipe.time, self.speed));
            self.cooking_timer = 0;
        }
    }
    fn recipe_experience(&self, recipes: &Recipes) -> Vec<(u32, f32)> {
        self.recipes_used
            .iter()
            .map(|(id, count)| (*count, recipes.cooking_experience(id)))
            .collect()
    }
    fn input_clicked(
        &mut self,
        context: &LoopContext,
        recipes: &Recipes,
        before: Option<ItemStack>,
    ) {
        if self.items[0] != before {
            let after = std::mem::replace(&mut self.items[0], before);
            self.set_input(context, recipes, after);
        }
    }
    fn tick(
        &mut self,
        context: &LoopContext,
        recipes: &Recipes,
        items: &Items,
        providers: &Providers,
        drops: &mut Vec<ItemStack>,
        remainder: &dyn Fn(&ItemStack) -> Option<ItemStack>,
    ) -> Option<bool> {
        let was_lit = self.lit_remaining > 0;
        let mut lit = false;
        if self.lit_remaining > 0 {
            self.lit_remaining -= 1;
            lit = self.lit_remaining > 0;
        }
        let fast = self.kind.fast();
        let has_ingredient = self.items[0].is_some();
        let has_fuel = self.items[1].is_some();
        if lit || has_fuel && has_ingredient {
            if let Some(ingredient) = self.items[0].clone() {
                if let Some(recipe) = recipes.cook(context, self.kind.recipe_type(), &ingredient) {
                    let max = items.get(&recipe.result.item).map_or(64, |i| i.max_stack);
                    let can_burn = match &self.items[2] {
                        None => true,
                        Some(out) => {
                            out.same_item_same_components(&recipe.result)
                                && out.count + recipe.result.count <= max
                        }
                    };
                    if can_burn {
                        if !lit {
                            let fuel = self.items[1].clone();
                            let time = fuel
                                .as_ref()
                                .map_or(0, |f| providers.burn_time(items, f, fast));
                            let speed = fuel
                                .as_ref()
                                .map_or(1.0, |f| providers.speed(items, f, fast));
                            self.lit_remaining = time;
                            self.lit_total = time;
                            self.speed = speed;
                            if self.cooking_total > 0 && self.cooking_timer < self.cooking_total {
                                let ratio = self.cooking_timer as f32 / self.cooking_total as f32;
                                self.cooking_total = total_time(recipe.time, self.speed);
                                self.cooking_timer =
                                    (ratio * self.cooking_total as f32).ceil() as i32;
                            }
                            if time > 0 {
                                // AbstractFurnaceBlockEntity.consumeFuel: the fuel's crafting
                                // remainder takes the slot once the stack is used up, else
                                // it is dropped.
                                if let Some(f) = self.items[1].as_mut() {
                                    let remainder = remainder(f);
                                    f.count -= 1;
                                    if f.count == 0 {
                                        self.items[1] = remainder;
                                    } else if let Some(remainder) = remainder {
                                        drops.push(remainder);
                                    }
                                }
                                lit = true;
                            }
                        }
                        if lit {
                            self.cooking_timer += 1;
                            if self.cooking_timer >= self.cooking_total {
                                self.cooking_timer = 0;
                                self.cooking_total = total_time(recipe.time, self.speed);
                                match &mut self.items[2] {
                                    Some(out) => out.count += recipe.result.count,
                                    None => self.items[2] = Some(recipe.result.clone()),
                                }
                                *self
                                    .recipes_used
                                    .entry(recipe_used_key(&recipe.id))
                                    .or_insert(0) += 1;
                                // AbstractFurnaceBlockEntity.burn: drying a wet sponge fills
                                // the bucket in the fuel slot.
                                if self.items[0]
                                    .as_ref()
                                    .is_some_and(|i| &*i.item == "minecraft:wet_sponge")
                                    && self.items[1]
                                        .as_ref()
                                        .is_some_and(|f| &*f.item == "minecraft:bucket")
                                {
                                    self.items[1] =
                                        Some(ItemStack::new("minecraft:water_bucket", 1));
                                }
                                if let Some(i) = self.items[0].as_mut() {
                                    i.count -= 1;
                                    if i.count == 0 {
                                        self.items[0] = None;
                                    }
                                }
                            }
                        } else {
                            self.cooking_timer = 0;
                        }
                    } else {
                        self.cooking_timer = 0;
                    }
                }
            } else {
                self.cooking_timer = 0;
            }
        } else if self.cooking_timer > 0 {
            self.cooking_timer = (self.cooking_timer - 2).clamp(0, self.cooking_total);
        }
        (was_lit != lit).then_some(lit)
    }
    fn idle(&self) -> bool {
        self.lit_remaining <= 0
            && self.cooking_timer <= 0
            && !(self.items[0].is_some() && self.items[1].is_some())
    }
}
fn total_time(time: u32, speed: f32) -> i32 {
    if speed > 0.0 {
        (time as f32 / speed).ceil() as i32
    } else {
        time as i32
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{containers::FurnaceKind, items::Items};
    use horizon_world::loot::PackOverlay;
    use std::{collections::HashMap, fs};

    #[test]
    fn a_furnace_is_idle_only_while_its_tick_changes_nothing() {
        let stack = |id: &str| Some(ItemStack::new(id, 1));
        let furnace = |input, fuel, lit_remaining, cooking_timer| Furnace {
            kind: FurnaceKind::Furnace,
            items: [input, fuel, stack("minecraft:iron_ingot")],
            lit_remaining,
            lit_total: 0,
            cooking_timer,
            cooking_total: 200,
            speed: 1.0,
            recipes_used: HashMap::new(),
        };
        assert!(furnace(None, None, 0, 0).idle());
        assert!(furnace(stack("minecraft:iron_ore"), None, 0, 0).idle());
        assert!(furnace(None, stack("minecraft:coal"), 0, 0).idle());
        assert!(!furnace(stack("minecraft:iron_ore"), stack("minecraft:coal"), 0, 0).idle());
        assert!(!furnace(None, None, 1, 0).idle());
        assert!(!furnace(stack("minecraft:iron_ore"), None, 0, 5).idle());
    }

    /// A data root holding one recipe, `test:ore` into `test:ingot`, and an item table
    /// with two fuels: `test:coal` (no remainder) and `test:cell` (a content mod's item
    /// that leaves `test:husk`). The folder is gone when this returns.
    pub(super) fn data(name: &str) -> (Items, Recipes, Providers) {
        let root =
            std::env::temp_dir().join(format!("horizon-furnace-{name}-{}", std::process::id(),));
        let _ = fs::remove_dir_all(&root);
        fs::create_dir_all(root.join("data/minecraft/recipe")).unwrap();
        fs::write(
            root.join("data/minecraft/recipe/test_ingot.json"),
            br#"{"type":"minecraft:smelting","ingredient":"test:ore","result":{"id":"test:ingot"}}"#,
        )
        .unwrap();
        fs::create_dir_all(root.join("data/minecraft/loot_table")).unwrap();
        let fuel_component =
            r#"{"minecraft:cooking_fuel": {"burn_time": 200, "speed_multiplier": 1.0}}"#;
        fs::write(
            root.join("items.json"),
            format!(
                r#"{{"test:ore": {{}}, "test:ingot": {{}}, "test:coal": {fuel_component}, "test:cell": {fuel_component}, "test:husk": {{}}}}"#
            ),
        )
        .unwrap();
        fs::write(
            root.join(horizon_items::items::MOD_CRAFT_REMAINDERS),
            r#"{"test:cell": "test:husk"}"#,
        )
        .unwrap();
        let defaults = horizon_world::item_defaults::read(&root).unwrap();
        let items = Items::catalog(&root, &PackOverlay::NONE, &defaults).unwrap();
        let recipes = Recipes::load(
            &root,
            &items,
            &PackOverlay::NONE,
            &crate::test_resources::server_load(),
        )
        .unwrap();
        let providers = Providers::load(&root);
        let _ = fs::remove_dir_all(&root);
        (items, recipes, providers)
    }

    #[test]
    fn loaded_totals_survive_until_actual_completion() {
        let (items, recipes, providers) = data("loaded-total");
        let context = crate::test_resources::server_loop_context();
        assert_eq!(
            recipes
                .cook(
                    context,
                    FurnaceKind::Furnace.recipe_type(),
                    &ItemStack::new("test:ore", 3)
                )
                .unwrap()
                .time,
            200
        );
        // Fresh Java's five-case Game fixture independently admits the loaded
        // zero (including a missing saved field), five and normal totals.
        for (total, timer, completion) in [(0, 0, 1), (5, 0, 5), (200, 0, 200), (5, 1, 4)] {
            let mut f = Furnace {
                kind: FurnaceKind::Furnace,
                items: [Some(ItemStack::new("test:ore", 3)), None, None],
                lit_remaining: 20,
                lit_total: 20,
                cooking_timer: timer,
                cooking_total: total,
                speed: 1.0,
                recipes_used: HashMap::new(),
            };
            for elapsed in 1..=6 {
                let mut drops = Vec::new();
                assert!(!f.idle());
                assert_eq!(
                    f.tick(context, &recipes, &items, &providers, &mut drops, &|s| {
                        crate::crafting::CraftingRemainder::crafting_remainder(&items, s)
                    }),
                    None
                );
                assert!(drops.is_empty());
                assert_eq!((f.lit_remaining, f.lit_total), (20 - elapsed, 20));
                assert!(f.items[1].is_none());
                let complete = elapsed >= completion;
                assert_eq!(
                    f.items[0].as_ref().unwrap().count,
                    if complete { 2 } else { 3 },
                    "loaded {total}/{timer}, tick {elapsed}"
                );
                assert_eq!(
                    f.items[2].as_ref().map(|s| (&*s.item, s.count)),
                    if complete {
                        Some(("test:ingot", 1))
                    } else {
                        None
                    }
                );
                assert_eq!(f.cooking_total, if complete { 200 } else { total });
                assert_eq!(
                    f.cooking_timer,
                    if complete {
                        elapsed - completion
                    } else {
                        timer + elapsed
                    }
                );
            }
            // A changed input still goes through setItem's independent reset.
            f.set_input(context, &recipes, Some(ItemStack::new("test:ingot", 1)));
            assert_eq!((f.cooking_timer, f.cooking_total), (0, 200));
        }
    }

    #[test]
    fn cooking_requires_output_components_and_capacity() {
        let (items, recipes, providers) = data("output-components");
        let context = crate::test_resources::server_loop_context();
        let mut different = ItemStack::new("test:ingot", 1);
        different.data_mut().custom_name = Some(horizon_core::nbt::Tag::String("Cold".into()));
        for (output, eligible) in [
            (Some(different), false),
            (None, true),
            (Some(ItemStack::new("test:ingot", 1)), true),
            (Some(ItemStack::new("test:ingot", 64)), false),
            (Some(ItemStack::new("test:ingot", 63)), true),
        ] {
            let before = output.clone();
            let mut f = Furnace {
                kind: FurnaceKind::Furnace,
                items: [
                    Some(ItemStack::new("test:ore", 3)),
                    Some(ItemStack::new("test:coal", 1)),
                    output,
                ],
                lit_remaining: 0,
                lit_total: 0,
                cooking_timer: 0,
                cooking_total: 200,
                speed: 1.0,
                recipes_used: HashMap::new(),
            };
            let recipe = recipes
                .cook(context, f.kind.recipe_type(), f.items[0].as_ref().unwrap())
                .unwrap();
            assert_eq!(
                (&*recipe.result.item, recipe.result.count, recipe.time),
                ("test:ingot", 1, 200)
            );
            let mut drops = Vec::new();
            assert_eq!(
                f.tick(context, &recipes, &items, &providers, &mut drops, &|s| {
                    crate::crafting::CraftingRemainder::crafting_remainder(&items, s)
                }),
                eligible.then_some(true),
                "output {before:?}"
            );
            assert!(drops.is_empty());
            if eligible {
                assert!(f.items[1].is_none());
                for _ in 1..200 {
                    f.tick(context, &recipes, &items, &providers, &mut drops, &|s| {
                        crate::crafting::CraftingRemainder::crafting_remainder(&items, s)
                    });
                }
                assert_eq!(f.items[0].as_ref().unwrap().count, 2);
                assert_eq!(
                    f.items[2].as_ref().unwrap().count,
                    before.as_ref().map_or(0, |s| s.count) + 1
                );
            } else {
                assert_eq!(f.items[0].as_ref().unwrap().count, 3);
                assert_eq!(f.items[1].as_ref().unwrap().count, 1);
                assert_eq!(f.items[2], before);
                assert_eq!((f.lit_remaining, f.cooking_timer), (0, 0));
            }
        }
    }

    /// The furnace sleeps while `idle`, so its tick must change nothing then: run the
    /// real tick on every idle case and compare, and check a furnace that can smelt
    /// isn't idle and does change.
    #[test]
    fn an_idle_furnace_tick_changes_nothing() {
        let (items, recipes, providers) = data("idle");
        let stack = |id: &str| Some(ItemStack::new(id, 1));
        let furnace = |input, fuel, output| Furnace {
            kind: FurnaceKind::Furnace,
            items: [input, fuel, output],
            lit_remaining: 0,
            lit_total: 0,
            cooking_timer: 0,
            cooking_total: 200,
            speed: 1.0,
            recipes_used: HashMap::new(),
        };
        let idle = [
            furnace(None, None, None),
            furnace(stack("test:ore"), None, None),
            furnace(None, stack("test:coal"), None),
            furnace(None, None, stack("test:ingot")),
            furnace(stack("test:ingot"), None, stack("test:ingot")),
        ];
        for before in idle {
            assert!(before.idle(), "{before:?}");
            let mut after = before.clone();
            let mut drops = Vec::new();
            let lit = after.tick(
                crate::test_resources::server_loop_context(),
                &recipes,
                &items,
                &providers,
                &mut drops,
                &|s| crate::crafting::CraftingRemainder::crafting_remainder(&items, s),
            );
            assert_eq!(lit, None, "{before:?}");
            assert!(drops.is_empty(), "{before:?}");
            assert_eq!(format!("{after:?}"), format!("{before:?}"));
        }
        let mut busy = furnace(stack("test:ore"), stack("test:coal"), None);
        assert!(!busy.idle());
        let before = format!("{busy:?}");
        assert_eq!(
            busy.tick(
                crate::test_resources::server_loop_context(),
                &recipes,
                &items,
                &providers,
                &mut Vec::new(),
                &|s| crate::crafting::CraftingRemainder::crafting_remainder(&items, s),
            ),
            Some(true)
        );
        assert_ne!(format!("{busy:?}"), before);
    }

    /// A furnace with `fuel` x `count` burning `test:ore` into `test:ingot` ([`data`]).
    fn burn(fuel: &str, count: u32) -> (Furnace, Vec<ItemStack>) {
        let (items, recipes, providers) =
            data(&format!("remainder-{}-{count}", fuel.replace(':', "-")));
        let mut furnace = Furnace {
            kind: FurnaceKind::Furnace,
            items: [
                Some(ItemStack::new("test:ore", 1)),
                Some(ItemStack::new(fuel, count)),
                None,
            ],
            lit_remaining: 0,
            lit_total: 0,
            cooking_timer: 0,
            cooking_total: 0,
            speed: 1.0,
            recipes_used: HashMap::new(),
        };
        let mut drops = Vec::new();
        let lit = furnace.tick(
            crate::test_resources::server_loop_context(),
            &recipes,
            &items,
            &providers,
            &mut drops,
            &|s| crate::crafting::CraftingRemainder::crafting_remainder(&items, s),
        );
        assert_eq!(lit, Some(true), "the fuel lit the furnace");
        (furnace, drops)
    }

    fn fuel_slot(furnace: &Furnace) -> Option<(&str, u32)> {
        furnace.items[1].as_ref().map(|s| (&*s.item, s.count))
    }

    /// `AbstractFurnaceBlockEntity.consumeFuel`: the last of a fuel with a remainder
    /// leaves it in the fuel slot.
    #[test]
    fn the_last_fuel_leaves_its_remainder_in_the_slot() {
        let (furnace, drops) = burn("test:cell", 1);
        assert_eq!(fuel_slot(&furnace), Some(("test:husk", 1)));
        assert!(drops.is_empty());
    }

    /// With more of the fuel left, the remainder is dropped at the furnace.
    #[test]
    fn a_fuel_still_in_the_stack_drops_its_remainder() {
        let (furnace, drops) = burn("test:cell", 3);
        assert_eq!(fuel_slot(&furnace), Some(("test:cell", 2)));
        assert_eq!(drops, vec![ItemStack::new("test:husk", 1)]);
    }

    /// A fuel without a remainder leaves nothing.
    #[test]
    fn a_fuel_without_a_remainder_leaves_nothing() {
        let (furnace, drops) = burn("test:coal", 1);
        assert_eq!(fuel_slot(&furnace), None);
        assert!(drops.is_empty());
        let (furnace, drops) = burn("test:coal", 2);
        assert_eq!(fuel_slot(&furnace), Some(("test:coal", 1)));
        assert!(drops.is_empty());
    }
}

#[cfg(test)]
mod crafting_remainder_tests {
    use super::*;
    // A five-use tool: using it at damage four breaks it.
    fn worn(stack: &ItemStack) -> Option<ItemStack> {
        (stack.damage < 4).then(|| ItemStack {
            count: 1,
            damage: stack.damage + 1,
            ..stack.clone()
        })
    }
    #[test]
    fn crafting_remainder_preserves_cell_and_uses_current_damage() {
        let (_, recipes, _) = super::tests::data("stack-remainder");
        for (size, cell) in [(3, 4), (2, 3)] {
            let mut grid = vec![None; size * size];
            grid[cell] = Some(ItemStack {
                damage: 2,
                ..ItemStack::new("test:cell", 1)
            });
            let first = recipes.remainders("missing", &grid, size, &worn);
            assert_eq!(
                first[cell].as_ref().map(|s| (s.damage, s.count)),
                Some((3, 1))
            );
            assert_eq!(first.iter().flatten().count(), 1);
            let second = recipes.remainders("missing", &first, size, &worn);
            assert_eq!(
                second[cell].as_ref().map(|s| (s.damage, s.count)),
                Some((4, 1))
            );
            assert!(
                recipes
                    .remainders("missing", &second, size, &worn)
                    .iter()
                    .all(Option::is_none)
            );
        }
    }
    #[test]
    fn crafting_remainder_fuel_and_crafting_agree() {
        let (items, recipes, providers) = super::tests::data("stack-remainder-fuel");
        let stack = ItemStack {
            damage: 2,
            ..ItemStack::new("test:cell", 1)
        };
        let grid = [Some(stack.clone()), None, None, None];
        let crafted = recipes.remainders("missing", &grid, 2, &worn);
        let mut furnace = crate::containers::Furnace {
            kind: crate::containers::FurnaceKind::Furnace,
            items: [Some(ItemStack::new("test:ore", 1)), Some(stack), None],
            lit_remaining: 0,
            lit_total: 0,
            cooking_timer: 0,
            cooking_total: 0,
            speed: 1.0,
            recipes_used: Default::default(),
        };
        let mut drops = Vec::new();
        furnace.tick(
            crate::test_resources::server_loop_context(),
            &recipes,
            &items,
            &providers,
            &mut drops,
            &worn,
        );
        assert_eq!(furnace.items[1], crafted[0]);
        assert_eq!(
            furnace.items[1].as_ref().map(|s| (s.damage, s.count)),
            Some((3, 1))
        );
        assert!(drops.is_empty());
    }
}
